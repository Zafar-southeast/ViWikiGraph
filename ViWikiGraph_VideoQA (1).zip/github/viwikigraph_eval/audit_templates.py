from __future__ import annotations
import random
from typing import Any, Iterable, Mapping


def make_qa_audit_template(rows: Iterable[Mapping[str, Any]], sample_size: int = 200, seed: int = 42) -> list[dict[str, Any]]:
    pool = list(rows)
    random.Random(seed).shuffle(pool)
    return [{
        "audit_type": "qa", "dataset": r.get("dataset"), "question_id": r.get("question_id"),
        "condition": r.get("condition", "principal"),
        "gold_section_ids": [], "gold_triple_ids": [], "gold_link_ids": [],
        "gold_evidence_ids": [], "gold_subtitle_ids": [], "gold_intervals": [],
        "gate_label": None, "annotator_labels": {}, "adjudicated_label": None,
        "reviewer_ids": [], "sampling_stratum": r.get("question_type"),
    } for r in pool[:sample_size]]


def make_package_audit_template(items: Iterable[Mapping[str, Any]]) -> list[dict[str, Any]]:
    return [{
        "audit_type": "package", "item_id": x.get("item_id"), "item_kind": x.get("item_type"),
        "phase": x.get("phase", "post"), "evidence_shown": x.get("source_ids", []),
        "annotator_labels": {}, "adjudicated_label": None, "reviewer_ids": [],
        "sampling_stratum": x.get("item_type"),
    } for x in items]
