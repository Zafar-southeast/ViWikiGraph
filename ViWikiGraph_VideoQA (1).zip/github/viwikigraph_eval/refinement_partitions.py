from __future__ import annotations
import hashlib
from collections import defaultdict
from typing import Any, Iterable, Mapping


def make_video_grouped_partitions(rows: Iterable[Mapping[str, Any]], n_partitions: int = 5, seed: int = 42) -> list[dict[str, Any]]:
    """Create deterministic video-disjoint QA/QB folds.

    Each video is assigned to one partition. Within that partition, questions are
    deterministically split into QA (trigger/refinement) and QB (future evaluation).
    """
    if n_partitions < 2:
        raise ValueError("n_partitions must be >= 2")
    by_video: dict[str, list[Mapping[str, Any]]] = defaultdict(list)
    for row in rows:
        by_video[str(row["video_id"])].append(row)
    output: list[dict[str, Any]] = []
    for video_id, questions in sorted(by_video.items()):
        digest = hashlib.sha256(f"{seed}:{video_id}".encode()).hexdigest()
        partition = int(digest[:8], 16) % n_partitions
        ordered = sorted(questions, key=lambda r: hashlib.sha256(f"{seed}:{r['question_id']}".encode()).hexdigest())
        split_at = max(1, len(ordered) // 2)
        for i, row in enumerate(ordered):
            output.append({**dict(row), "partition": partition, "set": "QA" if i < split_at else "QB"})
    return output


def build_refinement_eval_row(*, partition: int, set_name: str, question_id: str, video_id: str,
                              pre_correct: bool, post_correct: bool) -> dict[str, Any]:
    return {
        "audit_type": "refinement_eval", "partition": partition, "set": set_name,
        "question_id": question_id, "video_id": video_id,
        "pre_correct": bool(pre_correct), "post_correct": bool(post_correct),
    }
