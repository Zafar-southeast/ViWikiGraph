from __future__ import annotations
import math
from typing import Any, Mapping, Sequence


def softmax(values: Sequence[float]) -> list[float]:
    if not values:
        return []
    m = max(values)
    exps = [math.exp(v - m) for v in values]
    total = sum(exps)
    return [v / total for v in exps]


def build_prediction_log_row(
    *, question_id: str, option_token_log_likelihoods: Sequence[float] | Mapping[str, float] | None,
    draft_answer: str | None, final_answer: str | None, confidence_score: float | None,
    cited_evidence_ids: Sequence[str], correctness: bool | None,
    calibrated_probabilities: Sequence[float] | Mapping[str, float] | None = None,
    calibration_temperature: float | None = None,
) -> dict[str, Any]:
    """Call inside the decoder while token log-likelihoods and draft answer still exist."""
    ll = option_token_log_likelihoods
    if calibrated_probabilities is None and isinstance(ll, Sequence) and not isinstance(ll, (str, bytes)):
        t = calibration_temperature or 1.0
        calibrated_probabilities = softmax([float(x) / t for x in ll])
    return {
        "question_id": str(question_id),
        "option_token_log_likelihoods": ll,
        "calibrated_probabilities": calibrated_probabilities,
        "draft_answer": draft_answer,
        "final_answer": final_answer,
        "confidence_score": confidence_score,
        "cited_evidence_ids": [str(x) for x in cited_evidence_ids],
        "correctness": correctness,
    }
