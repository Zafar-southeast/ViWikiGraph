from __future__ import annotations
import copy
import random
from typing import Any, Mapping, Sequence


def _n(total: int, severity: float) -> int:
    if not 0 <= severity <= 1:
        raise ValueError("severity must be in [0, 1]")
    return min(total, max(0, round(total * severity)))


def corrupt_links(links: Sequence[Mapping[str, Any]], severity: float, seed: int) -> list[dict[str, Any]]:
    """Corrupt selected links by swapping targets while preserving schema."""
    rng = random.Random(seed)
    out = [copy.deepcopy(dict(x)) for x in links]
    if len(out) < 2:
        return out
    idx = rng.sample(range(len(out)), _n(len(out), severity))
    targets = [(out[i].get("target_id"), out[i].get("target_type")) for i in idx]
    rng.shuffle(targets)
    for i, target in zip(idx, targets):
        out[i]["original_target_id"] = out[i].get("target_id")
        out[i]["original_target_type"] = out[i].get("target_type")
        out[i]["target_id"], out[i]["target_type"] = target
        out[i]["corruption_type"] = "link"
        out[i]["corruption_severity"] = severity
        out[i]["corruption_seed"] = seed
    return out


def corrupt_provenance(items: Sequence[Mapping[str, Any]], severity: float, seed: int) -> list[dict[str, Any]]:
    """Corrupt provenance by swapping source IDs/provenance among selected records."""
    rng = random.Random(seed)
    out = [copy.deepcopy(dict(x)) for x in items]
    if len(out) < 2:
        return out
    idx = rng.sample(range(len(out)), _n(len(out), severity))
    provenance = [(out[i].get("provenance"), out[i].get("source_ids")) for i in idx]
    rng.shuffle(provenance)
    for i, values in zip(idx, provenance):
        out[i]["original_provenance"] = out[i].get("provenance")
        out[i]["original_source_ids"] = out[i].get("source_ids")
        out[i]["provenance"], out[i]["source_ids"] = values
        out[i]["corruption_type"] = "provenance"
        out[i]["corruption_severity"] = severity
        out[i]["corruption_seed"] = seed
    return out
