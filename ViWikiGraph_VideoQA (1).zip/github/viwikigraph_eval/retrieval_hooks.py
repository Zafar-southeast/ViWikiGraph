from __future__ import annotations
from typing import Any, Iterable, Mapping, Sequence


def _get(obj: Any, key: str, default: Any = None) -> Any:
    if isinstance(obj, Mapping):
        return obj.get(key, default)
    return getattr(obj, key, default)


def build_retrieval_log_row(
    *, question_id: str, router_evidence_vector: Mapping[str, float] | Sequence[float] | None,
    raw_text_required: bool, reserved_text_budget: int | None,
    ranked_candidates: Iterable[Any], link_expansion_path: Sequence[Any] | None = None,
    deduplication_decisions: Sequence[Mapping[str, Any]] | None = None,
) -> dict[str, Any]:
    """Call immediately after retrieval, before candidate fields are discarded."""
    ranked_ids, components, final_order = [], {}, []
    for rank, candidate in enumerate(ranked_candidates, 1):
        eid = str(_get(candidate, "evidence_id", _get(candidate, "id", _get(candidate, "unit_id", ""))))
        if not eid:
            continue
        ranked_ids.append(eid)
        final_order.append({"rank": rank, "evidence_id": eid})
        components[eid] = dict(_get(candidate, "score_components", {}) or {})
        if not components[eid]:
            for name in ("score", "semantic_score", "lexical_score", "link_score", "temporal_score", "router_score"):
                value = _get(candidate, name)
                if value is not None:
                    components[eid][name] = value
    return {
        "question_id": str(question_id),
        "router_evidence_vector": router_evidence_vector,
        "raw_text_required": bool(raw_text_required),
        "reserved_text_budget": reserved_text_budget,
        "ranked_evidence_ids": ranked_ids,
        "score_components": components,
        "link_expansion_path": list(link_expansion_path or []),
        "deduplication_decisions": list(deduplication_decisions or []),
        "final_ranking_order": final_order,
    }
