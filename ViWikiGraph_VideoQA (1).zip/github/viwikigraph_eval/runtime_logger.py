from __future__ import annotations

import json
import os
import platform
import subprocess
import time
from contextlib import AbstractContextManager
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping


def _cuda_sync() -> None:
    try:
        import torch
        if torch.cuda.is_available():
            torch.cuda.synchronize()
    except Exception:
        pass


def hardware_snapshot() -> dict[str, Any]:
    out: dict[str, Any] = {
        "platform": platform.platform(),
        "python": platform.python_version(),
        "processor": platform.processor(),
        "cpu_count": os.cpu_count(),
    }
    try:
        import psutil
        vm = psutil.virtual_memory()
        out["ram_total_bytes"] = int(vm.total)
    except Exception:
        out["ram_total_bytes"] = None
    try:
        import torch
        out["torch_version"] = torch.__version__
        out["cuda_available"] = bool(torch.cuda.is_available())
        if torch.cuda.is_available():
            out["cuda_version"] = torch.version.cuda
            out["gpu_name"] = torch.cuda.get_device_name(0)
            out["gpu_count"] = torch.cuda.device_count()
    except Exception:
        out["cuda_available"] = False
    try:
        out["nvidia_smi"] = subprocess.check_output(
            ["nvidia-smi", "--query-gpu=name,driver_version,memory.total", "--format=csv,noheader"],
            text=True, timeout=5,
        ).strip()
    except Exception:
        out["nvidia_smi"] = None
    return out


class JsonlLogger:
    """Append stable-ID records to a JSONL file."""
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def write(self, row: Mapping[str, Any]) -> None:
        with self.path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(dict(row), ensure_ascii=False, sort_keys=True, default=str) + "\n")


@dataclass
class StageTimer(AbstractContextManager):
    logger: JsonlLogger
    processing_stage: str
    dataset: str
    video_id: str | None = None
    question_id: str | None = None
    batch_size: int | None = None
    warmup_status: bool = False
    video_duration_seconds: float | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def __enter__(self):
        _cuda_sync()
        self._wall_start = time.perf_counter()
        self._cpu_start = time.process_time()
        self._gpu_start = None
        try:
            import torch
            if torch.cuda.is_available():
                torch.cuda.reset_peak_memory_stats()
                self._gpu_start = torch.cuda.Event(enable_timing=True)
                self._gpu_end = torch.cuda.Event(enable_timing=True)
                self._gpu_start.record()
        except Exception:
            self._gpu_start = None
        return self

    def __exit__(self, exc_type, exc, tb):
        gpu_seconds = None
        peak_gpu = None
        try:
            import torch
            if self._gpu_start is not None:
                self._gpu_end.record()
                torch.cuda.synchronize()
                gpu_seconds = float(self._gpu_start.elapsed_time(self._gpu_end) / 1000.0)
                peak_gpu = int(torch.cuda.max_memory_allocated())
        except Exception:
            pass
        wall = float(time.perf_counter() - self._wall_start)
        cpu = float(time.process_time() - self._cpu_start)
        peak_cpu = None
        try:
            import psutil
            peak_cpu = int(psutil.Process().memory_info().rss)
        except Exception:
            pass
        row = {
            "processing_stage": self.processing_stage,
            "dataset": self.dataset,
            "video_id": self.video_id,
            "question_id": self.question_id,
            "wall_clock_seconds": wall,
            "cpu_time_seconds": cpu,
            "gpu_time_seconds": gpu_seconds,
            "batch_size": self.batch_size,
            "warmup_status": self.warmup_status,
            "memory_usage_bytes": peak_cpu,
            "peak_gpu_memory_bytes": peak_gpu,
            "video_duration_seconds": self.video_duration_seconds,
            "seconds_per_video_minute": (
                wall / (self.video_duration_seconds / 60.0)
                if self.video_duration_seconds and self.video_duration_seconds > 0 else None
            ),
            "success": exc_type is None,
            "error": None if exc is None else repr(exc),
            **self.extra,
        }
        self.logger.write(row)
        return False


GpuTimer = StageTimer
