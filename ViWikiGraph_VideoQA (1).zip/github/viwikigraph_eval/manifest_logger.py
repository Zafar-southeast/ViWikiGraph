from __future__ import annotations
import hashlib
import json
import platform
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping
from .runtime_logger import hardware_snapshot


def sha256_file(path: str | Path) -> str:
    p = Path(path)
    h = hashlib.sha256()
    with p.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def git_commit(repo_root: str | Path) -> str | None:
    try:
        return subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo_root, text=True, timeout=5).strip()
    except Exception:
        return None


def build_run_manifest(*, repo_root: str | Path, dataset: str, split: str, model: str,
                       checkpoint: str | None, tokenizer: str | None,
                       prompts: Mapping[str, Any], parameter_files: Iterable[str | Path],
                       dataset_files: Iterable[str | Path], seeds: Iterable[int], execution_mode: str) -> dict[str, Any]:
    parameter_files, dataset_files = list(parameter_files), list(dataset_files)
    return {
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "code_commit": git_commit(repo_root),
        "dataset": dataset, "split": split,
        "dataset_manifest_hashes": {str(p): sha256_file(p) for p in dataset_files if Path(p).exists()},
        "model": model, "checkpoint": checkpoint, "tokenizer": tokenizer,
        "prompts": dict(prompts),
        "parameter_file_hashes": {str(p): sha256_file(p) for p in parameter_files if Path(p).exists()},
        "random_seeds": list(seeds), "hardware": hardware_snapshot(),
        "execution_mode": execution_mode,
    }
