"""Manual smoke test for the LLM client: build a text prompt, query the model,
and parse the triplet output. Run with ``python scripts/smoke_llm.py``.

``tests/test_llm_client.py`` imports this module as a drift guard, asserting the
example reuses the package's prompt builders rather than reimplementing them.
"""

from viwikigraph.llm.client import (
    LLMClient,
    normalize_triplet_output,
    prompt_for_image,
    prompt_for_text,
)


def query_gpt(prompt: str, model_name: str | None = None) -> str:
    try:
        client = LLMClient(model=model_name)
        return client.chat(prompt).text
    except Exception as exc:
        print(f"API error: {exc}")
        return ""


def main() -> None:
    prompt = prompt_for_text(
        question="What color is the door?",
        full_text="The house has a red front door and two windows.",
    )
    raw = query_gpt(prompt)
    if not raw:
        return
    print(raw)
    triplets = normalize_triplet_output(raw)
    print("Parsed triplets:", triplets)


if __name__ == "__main__":
    main()
