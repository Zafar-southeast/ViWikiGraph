"""Create paired model-comparison metrics over identical saved question IDs."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path


def read_jsonl(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def write_jsonl(path: Path, rows: list[dict]) -> None:
    path.write_text(
        "".join(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n" for row in rows),
        encoding="utf-8",
    )


def wilson(correct: int, count: int, z: float = 1.959963984540054) -> list[float]:
    if not count:
        return [0.0, 0.0]
    p = correct / count
    denom = 1 + z * z / count
    center = (p + z * z / (2 * count)) / denom
    margin = z * math.sqrt((p * (1 - p) + z * z / (4 * count)) / count) / denom
    return [max(0.0, center - margin), min(1.0, center + margin)]


def exact_paired_p_value(a_only: int, b_only: int) -> float:
    discordant = a_only + b_only
    if discordant == 0:
        return 1.0
    lower = min(a_only, b_only)
    tail = sum(math.comb(discordant, k) for k in range(lower + 1)) / (2**discordant)
    return min(1.0, 2 * tail)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--baseline-predictions", required=True)
    parser.add_argument("--baseline-eval", required=True)
    parser.add_argument("--candidate-predictions", required=True)
    parser.add_argument("--candidate-eval", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--baseline-name", default="baseline")
    parser.add_argument("--candidate-name", default="candidate")
    args = parser.parse_args()

    baseline_predictions = {
        row["question_id"]: row for row in read_jsonl(Path(args.baseline_predictions))
    }
    baseline_eval = {row["question_id"]: row for row in read_jsonl(Path(args.baseline_eval))}
    candidate_predictions = read_jsonl(Path(args.candidate_predictions))
    candidate_eval = {row["question_id"]: row for row in read_jsonl(Path(args.candidate_eval))}
    candidate_ids = [row["question_id"] for row in candidate_predictions]

    if len(candidate_ids) != len(set(candidate_ids)):
        raise ValueError("Candidate predictions contain duplicate question IDs")
    missing = [
        qid
        for qid in candidate_ids
        if qid not in baseline_predictions or qid not in baseline_eval or qid not in candidate_eval
    ]
    if missing:
        raise ValueError(f"Missing paired baseline/evaluation rows for {len(missing)} IDs")

    paired = []
    both_correct = both_wrong = baseline_only = candidate_only = agreements = 0
    for candidate in candidate_predictions:
        qid = candidate["question_id"]
        baseline = baseline_predictions[qid]
        a_correct = bool(baseline_eval[qid].get("correct"))
        b_correct = bool(candidate_eval[qid].get("correct"))
        agree = baseline.get("predicted_index") == candidate.get("predicted_index")
        agreements += int(agree)
        both_correct += int(a_correct and b_correct)
        both_wrong += int(not a_correct and not b_correct)
        baseline_only += int(a_correct and not b_correct)
        candidate_only += int(not a_correct and b_correct)
        paired.append(
            {
                "question_id": qid,
                "video_id": candidate.get("video_id"),
                "baseline_predicted_index": baseline.get("predicted_index"),
                "candidate_predicted_index": candidate.get("predicted_index"),
                "baseline_correct": a_correct,
                "candidate_correct": b_correct,
                "answers_agree": agree,
                "baseline_method": baseline.get("scoring_method"),
                "candidate_method": candidate.get("scoring_method"),
            }
        )

    count = len(paired)
    baseline_correct = both_correct + baseline_only
    candidate_correct = both_correct + candidate_only
    summary = {
        "baseline": {
            "name": args.baseline_name,
            "correct": baseline_correct,
            "count": count,
            "accuracy": baseline_correct / count,
            "accuracy_ci_95": wilson(baseline_correct, count),
        },
        "candidate": {
            "name": args.candidate_name,
            "correct": candidate_correct,
            "count": count,
            "accuracy": candidate_correct / count,
            "accuracy_ci_95": wilson(candidate_correct, count),
        },
        "paired": {
            "same_question_ids": True,
            "accuracy_difference_candidate_minus_baseline": (
                candidate_correct - baseline_correct
            )
            / count,
            "answer_agreement": agreements / count,
            "both_correct": both_correct,
            "both_wrong": both_wrong,
            "baseline_only_correct": baseline_only,
            "candidate_only_correct": candidate_only,
            "mcnemar_exact_two_sided_p": exact_paired_p_value(baseline_only, candidate_only),
        },
    }

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "paired_comparison.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2, sort_keys=True),
        encoding="utf-8",
    )
    write_jsonl(output_dir / "paired_per_question.jsonl", paired)
    print(json.dumps(summary, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
