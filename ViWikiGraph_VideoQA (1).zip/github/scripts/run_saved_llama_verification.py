"""Force a local Llama verifier pass over saved QA predictions and evidence packets."""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

from viwikigraph.config import load_config
from viwikigraph.core.schemas import EvidencePacket
from viwikigraph.cli import make_adapter
from viwikigraph.llm.local_llama import LocalLlamaClient
from viwikigraph.llm.prompts import verification_prompt
from viwikigraph.qa.answering import serialize_evidence_packet


def read_jsonl(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/datasets.yaml")
    parser.add_argument("--dataset", default="nextqa")
    parser.add_argument("--split", default="val")
    parser.add_argument("--predictions", required=True)
    parser.add_argument("--packets", required=True)
    parser.add_argument("--model-path", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--max-new-tokens", type=int, default=192)
    args = parser.parse_args()

    config = load_config(args.config)
    dataset = config.datasets[args.dataset]
    adapter = make_adapter(dataset)
    qas = {qa.question_id: qa for qa in adapter.iter_qa_instances(args.split)}
    predictions = read_jsonl(Path(args.predictions))
    packets = {
        row["question_id"]: EvidencePacket.from_dict(row) for row in read_jsonl(Path(args.packets))
    }
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    completed = {
        row["question_id"] for row in read_jsonl(output)
    } if output.exists() else set()

    llm = LocalLlamaClient(
        model_path=args.model_path,
        cache_dir=output.parent / "verifier_cache",
        max_new_tokens=args.max_new_tokens,
    )
    for index, prediction in enumerate(predictions, 1):
        qid = prediction["question_id"]
        if qid in completed:
            continue
        qa = qas[qid]
        packet = packets[qid]
        answer = str(prediction.get("answer", ""))
        claims = [f"The answer to '{qa.question}' is '{answer}'."]
        prompt = verification_prompt(
            qa.question,
            answer,
            claims,
            serialize_evidence_packet(qa, packet),
        )
        started = time.perf_counter()
        error = None
        response = None
        try:
            response = llm.strict_json(
                prompt,
                cache_version="forced_llama_verify_v1",
                tolerant=True,
            )
        except Exception as exc:
            error = repr(exc)
        row = {
            "question_id": qid,
            "video_id": prediction.get("video_id"),
            "draft_predicted_index": prediction.get("predicted_index"),
            "draft_answer": answer,
            "verifier_model": llm.model,
            "forced_verification": True,
            "verification": response,
            "success": response is not None,
            "error": error,
            "wall_clock_seconds": time.perf_counter() - started,
        }
        with output.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")
        print(f"[{index}/{len(predictions)}] {qid} success={row['success']}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
