# Data Setup

ViWikiGraph runs **RAG-only with a text-only LLM** and uses **dataset-provided features only**
(no ffmpeg frame extraction, no VLM). Everything below reflects what you must download for each
dataset and what is optional. `data/` is gitignored.

Expected layout (matches `configs/datasets.yaml`):

```
data/
  KnowIT/   knowit_data_{train,val,test}.csv        # have ✓ (TSV despite .csv)
            captions/knowit_captions.csv            # optional
            faces/knowit_knn_cnn_th060.tsv          # optional
  tvqa/     tvqa_plus_subtitles.json                # have ✓
            det_visual_concepts_hq.pickle           # have ✓
            tvqa_plus_annotations_with_test/*.json  # have ✓
  NExT-QA/  {train,val,test}.csv                   # have ✓ (flat layout)
            map_vid_vidorID.json                    # have ✓
            captions/nextqa_captions.jsonl          # optional (you generate)
            videos/                                  # optional (raw clips)
```

---

## KnowIT VQA — ✅ ready (2 optional enrichments)
You already have the QA TSVs with inline subtitles. Splits 19,569 / 2,352 / 2,361.

- `idxCorrect` is **1-based** → the adapter normalizes to 0-based.
- `reason`, `kg_type`, and test-split `QType` are **gold annotations** → used only as labels, never
  as answer-time evidence. The knowledge-RAG corpus is built from **train-split `reason`** only.

**Optional** (text-form, joinable by `scene`, no VLM needed) — improves visual/knowledge grounding:
- Captions (21 MB): `https://knowit-vqa.s3-ap-northeast-1.amazonaws.com/ROCK/knowit_captions.csv`
  → `data/KnowIT/captions/knowit_captions.csv`
- Faces / character presence (240 MB):
  `https://knowit-vqa.s3-ap-northeast-1.amazonaws.com/ROCK/knowit_knn_cnn_th060.tsv`
  → `data/KnowIT/faces/knowit_knn_cnn_th060.tsv`
- (Skip the 77 GB visual-concepts TSV — not worth it for a text LLM.)

## TVQA+ — ✅ ready, nothing to download
You have subtitles + `det_visual_concepts_hq.pickle` (per-frame objects @3fps, the object-detector
substitute; **no OCR needed**) + bbox **character labels** + preprocessed annotations.
- `answer_idx` is **0-based** over `a0..a4`. Splits 23,545 / 3,017 / 2,821.
- The **test split (`_no_anno`) has no gold answers** → we score on **val**; test produces
  predictions only (official scoring is via the UNC eval server).

## NExT-QA — ⬇️ PRIMARY dataset (v1)
Repo: `https://github.com/doc-doc/NExT-QA`. MC splits 34,132 / 4,996 / 8,564; also a sampled
open-ended split. NExT-QA is the v1 primary benchmark (temporal/causal/explanatory web-video QA).

### What to download from the NExT-QA Google Drive — exact per-file decision
The Drive "Data Preparation" folder lists nine items. For THIS pipeline (RAG-only, text-LLM,
dataset-features-only, **no training**), classify them as:

| File | Size | Decision | Why |
| --- | --- | --- | --- |
| `nextqa.zip` | 9.8 MB | **MUST** | MC annotations (`{train,val,test}.csv`) — the questions/options/answers. |
| `map_vid_vidorID.json` | 324 KB | **MUST** | Maps `video` id → VidOR folder id, needed to locate raw videos. |
| `NExTVideo.zip` | 22.6 GB | **MUST (if using `--use-vlm`)** | Raw videos. Two ways to use them: (a) `--use-vlm` makes the pipeline sample frames (ffmpeg) and read them with the vision LLM directly; or (b) generate the caption/visual sidecars below on your VM. Extract to `data/NExT-QA/NExTVideo/` (layout `<group>/<id>.mp4`); the adapter resolves each path via `map_vid_vidorID.json`. |
| `vid_feat.zip` | 983 MB | **SKIP** | Appearance+motion ResNet/ResNeXt **feature tensors** — not human-readable text, unusable by a text LLM (no feature→text adapter here). |
| `relation_annotation_nextqa.zip` | 31 MB | SKIP | VidOR relation annotations for the original supervised models; not used. |
| `models.zip`, `pytorch-pretrained-BERT.zip`, `qas_bert.zip`, `test-data-nextqa.zip` | 44 MB–10 GB | SKIP | Training-era checkpoints / BERT reps / pre-tokenized QAs — irrelevant to RAG-only. |

So the **minimum download is just `nextqa.zip` + `map_vid_vidorID.json` (~10 MB total)**. Add
`NExTVideo.zip` only if you will generate sidecars from the raw video on the VM.

Unzip CSVs + map **flat under `data/NExT-QA/`**: `data/NExT-QA/{train,val,test}.csv` +
`data/NExT-QA/map_vid_vidorID.json`. CSV columns:
`video,frame_count,width,height,question,answer,qid,type,a0..a4` (`answer` 0-based; `type` ∈
CW/CH/TC/TN/TP/DC/DL/DB/DO).

### Giving NExT-QA real multimodal evidence — two routes
**⚠️ NExT-QA ships NO subtitles/ASR/captions/labels.** Without evidence, QA is a language-prior
baseline (logged as such). There are two ways to give it real evidence:

**Route A — `--use-vlm` (read the video with the vision LLM, in-pipeline).** With `NExTVideo` present
and `ffmpeg` on PATH, `python -m viwikigraph build --dataset nextqa --split val --experiment-id exp
--use-vlm` samples `budgets.Bframes` frames per video and sends them to the SAME configured (vision-
capable) Claude model via `LLMClient.chat_vision`, producing caption / visual-concept / OCR
`EvidenceUnit`s with timestamps and saved-frame media paths (under the package `media/frames/`). These
frames also become `MediaItem`s → cross-modal links (ENTITY_IMAGE / CLAIM_MEDIA) + q_media validation.
Inference only, no training. Degrades to a no-op if ffmpeg / the video / the API key is missing.

**Route B — pre-generate sidecars (offline, no in-pipeline VLM).** The pipeline also consumes two
OPTIONAL externally-generated sidecars (produced on your VM from `NExTVideo`):

1. **Caption/ASR sidecar** → the text stream (`e_text`). JSONL, one line per video:
   `{"video_id": "4010069381", "captions": [{"text": "...", "start": 0.0, "end": 2.0}, ...]}`
   Point `configs/datasets.yaml: nextqa.captions_path` at it.
2. **Visual-concept sidecar** → visual grounding (`e_vis`) + entity evidence, exactly like TVQA's
   concepts/bbox. JSONL, one line per video:
   `{"video_id": "4010069381", "visual_concepts": [["woman","couch"], ["man","door"]],
     "bbox_labels": {"0": ["Penny"]}}`  (`bbox_labels` optional). A bare
   `{"video_id": [["woman","couch"], ...]}` mapping also works.
   Point `configs/datasets.yaml: nextqa.visual_concepts_path` at it.

The "model that does the visual features" you mentioned (the NExT-QA repo's feature extractor) emits
the `vid_feat.zip`-style dense tensors — those are NOT what this pipeline consumes. To use that signal
you'd dump per-frame **concept/label strings** (object tags, OCR text, captions) into the
visual-concept sidecar above. Dense embeddings are skipped.

---

## Quick download helper (NExT-QA annotations)
On the VM (needs `gdown` or the Drive UI):
```bash
pip install gdown
mkdir -p data/NExT-QA
gdown 1Mrf8vd7T2avfaaM4ht82ZLgoRGpCtayC -O data/NExT-QA/nextqa.zip
unzip -o data/NExT-QA/nextqa.zip -d data/NExT-QA/
# Extract the CSVs and map flat: cp data/NExT-QA/nextqa/*.csv data/NExT-QA/ && cp data/NExT-QA/nextqa/map_vid_vidorID.json data/NExT-QA/
# → data/NExT-QA/{train,val,test}.csv, data/NExT-QA/map_vid_vidorID.json
```
