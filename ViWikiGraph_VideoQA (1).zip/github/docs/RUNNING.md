# Running ViWikiGraph

End-to-end instructions for each dataset. All three follow the same four-stage pipeline:
**build → qa → eval → report**.

## Prerequisites

```bash
pip install -e ".[dev]"        # installs the package + pytest
cp .env.example .env           # add your AIGCBEST_API_KEY
```

Datasets must already be on disk — see [DATA_SETUP.md](DATA_SETUP.md) for what to download.

## Common flags

| Flag | Description |
|------|-------------|
| `--experiment-id EXP` | Names the run; outputs go to `outputs/EXP/{dataset}/{split}/` |
| `--split {train,val,test}` | Which annotation split to use |
| `--limit N` | Sample N questions (omit for the full split) |
| `--sample-seed S` | Seed for deterministic sampling (default 13) |
| `--stratify-by KEY` | Stratify sample by a QA metadata field |
| `--use-llm` | Use the configured LLM (default: deterministic offline path) |
| `--no-llm` | Force the offline path even if an API key is set |
| `--resume` | Skip videos whose package already exists (`build` only) |

---

## TVQA+

**Splits available:** train (23,545), val (3,017), test (2,821 — no gold answers)

Score on **val**. The test split (`_no_anno`) produces predictions only; gold scoring requires the
UNC eval server.

```bash
EXP=tvqa_run1

# 1. Build knowledge packages
python -m viwikigraph build  --dataset tvqa --split val --experiment-id $EXP --use-llm

# 2. Answer questions
python -m viwikigraph qa     --dataset tvqa --split val --experiment-id $EXP --mode mcq --use-llm

# 3. Score
python -m viwikigraph eval   --dataset tvqa --split val --experiment-id $EXP

# 4. Report
python -m viwikigraph report --dataset tvqa --split val --experiment-id $EXP
```

Quick smoke test (50 questions):
```bash
python -m viwikigraph build  --dataset tvqa --split val --experiment-id tvqa_smoke --limit 50
python -m viwikigraph qa     --dataset tvqa --split val --experiment-id tvqa_smoke --limit 50
python -m viwikigraph eval   --dataset tvqa --split val --experiment-id tvqa_smoke --limit 50
python -m viwikigraph report --dataset tvqa --split val --experiment-id tvqa_smoke --limit 50
```

Stratify by question type (using timestamp-localized questions as a proxy):
```bash
python -m viwikigraph build --dataset tvqa --split val --experiment-id $EXP --limit 200 \
  --stratify-by question_type
```

Test-split predictions (no gold eval):
```bash
python -m viwikigraph build --dataset tvqa --split test --experiment-id $EXP
python -m viwikigraph qa    --dataset tvqa --split test --experiment-id $EXP --mode mcq
# predictions at outputs/$EXP/tvqa/test/qa/predictions.jsonl
```

---

## KnowIT

**Splits available:** train (19,569), val (2,352), test (2,361)

KnowIT uses an **external knowledge corpus** built from train-split `reason` sentences. It is
constructed automatically on the first `qa` run and cached at
`outputs/{EXP}/knowit/knowledge_corpus.jsonl`. Subsequent runs load from cache.

```bash
EXP=knowit_run1

# 1. Build knowledge packages
python -m viwikigraph build  --dataset knowit --split val --experiment-id $EXP --use-llm

# 2. Answer (corpus is auto-built from train on first call)
python -m viwikigraph qa     --dataset knowit --split val --experiment-id $EXP --mode mcq --use-llm

# 3. Score
python -m viwikigraph eval   --dataset knowit --split val --experiment-id $EXP

# 4. Report
python -m viwikigraph report --dataset knowit --split val --experiment-id $EXP
```

Quick smoke test (50 questions):
```bash
python -m viwikigraph build  --dataset knowit --split val --experiment-id knowit_smoke --limit 50
python -m viwikigraph qa     --dataset knowit --split val --experiment-id knowit_smoke --limit 50
python -m viwikigraph eval   --dataset knowit --split val --experiment-id knowit_smoke --limit 50
python -m viwikigraph report --dataset knowit --split val --experiment-id knowit_smoke --limit 50
```

Stratify by knowledge type (`episode-specific` vs `recurrent`):
```bash
python -m viwikigraph build --dataset knowit --split val --experiment-id $EXP --limit 200 \
  --stratify-by kg_type
```

Test split (has gold answers, unlike TVQA test):
```bash
python -m viwikigraph build  --dataset knowit --split test --experiment-id $EXP
python -m viwikigraph qa     --dataset knowit --split test --experiment-id $EXP
python -m viwikigraph eval   --dataset knowit --split test --experiment-id $EXP
python -m viwikigraph report --dataset knowit --split test --experiment-id $EXP
```

---

## NExT-QA

**Splits available:** train (34,132), val (4,996), test (8,564)

NExT-QA ships no subtitles or ASR. Without a caption sidecar or VLM processing,
the pipeline degrades to a question-and-options language-prior baseline.

Video-grounded evidence can be supplied through either:

1. A caption/visual-concept sidecar.
2. In-pipeline VLM frame processing with `--use-vlm`.

**Language-prior baseline (no captions — what we have now):**

```bash
EXP=nextqa_run1
python -m viwikigraph build --dataset nextqa --split val --experiment-id $EXP --use-llm  --use-vlm

#  Build
python -m viwikigraph build  --dataset nextqa --split val --experiment-id $EXP --use-llm

# Answer
python -m viwikigraph qa     --dataset nextqa --split val --experiment-id $EXP --mode mcq

#  Score
python -m viwikigraph eval   --dataset nextqa --split val --experiment-id $EXP

#  Report
python -m viwikigraph report --dataset nextqa --split val --experiment-id $EXP
```

Quick smoke test (50 questions):
```bash
python -m viwikigraph build  --dataset nextqa --split val --experiment-id nextqa_smoke --limit 50
python -m viwikigraph qa     --dataset nextqa --split val --experiment-id nextqa_smoke --limit 50
python -m viwikigraph eval   --dataset nextqa --split val --experiment-id nextqa_smoke --limit 50
python -m viwikigraph report --dataset nextqa --split val --experiment-id nextqa_smoke --limit 50
```

Stratify by question type (`CW/CH/TC/TN/TP/DC/DL/DB/DO`):
```bash
python -m viwikigraph build --dataset nextqa --split val --experiment-id $EXP --limit 200 \
  --stratify-by question_type
```

**With caption sidecar (optional — requires generating captions first):**

Once you have `data/NExT-QA/captions/nextqa_captions.jsonl`, uncomment `captions_path` in
`configs/datasets.yaml`, then re-run the pipeline above. The adapter will populate
`VideoRecord.subtitles` from the sidecar and evidence retrieval will have textual grounding.

---

## Ablations

Run after `build` completes. Ablations reuse the built packages and produce their own
`predictions.jsonl` + `metrics.json` under `outputs/{EXP}/{dataset}/{split}/ablations/{variant}/`.

```bash
# Variants: no_kg | no_narrative | no_media | no_provenance | flat_markdown
python -m viwikigraph ablate --dataset tvqa --split val --experiment-id $EXP --variant no_kg --use-llm
python -m viwikigraph ablate --dataset tvqa --split val --experiment-id $EXP --variant no_narrative --use-llm
python -m viwikigraph ablate --dataset tvqa --split val --experiment-id $EXP --variant flat_markdown --use-llm
```

The `no_pre_storage_validation` condition is a build-time ablation because validation occurs before
the retrieval index is persisted. Build it under a separate experiment ID, then run QA and evaluation
with the same question selection and model settings as the full baseline:

```bash
python -m viwikigraph build --dataset nextqa --split val \
  --experiment-id ${EXP}_no_pre_storage_validation \
  --no-pre-storage-validation --use-llm --use-vlm
python -m viwikigraph qa --dataset nextqa --split val \
  --experiment-id ${EXP}_no_pre_storage_validation --use-llm
python -m viwikigraph eval --dataset nextqa --split val \
  --experiment-id ${EXP}_no_pre_storage_validation
```

---

## Stress tests

Degrade evidence quality at a controlled level and measure robustness. Results land under
`outputs/{EXP}/{dataset}/{split}/stress/{setting}/{level}/`.

```bash
# Settings: subtitle_distractors | kg_distractors | provenance_corruption
# Level: float 0.0–1.0 (fraction of evidence degraded)
python -m viwikigraph stress --dataset tvqa --split val --experiment-id $EXP \
  --setting subtitle_distractors --level 0.3
python -m viwikigraph stress --dataset knowit --split val --experiment-id $EXP \
  --setting kg_distractors --level 0.5
```

---

## Output layout

```
outputs/
  {experiment_id}/
    {dataset}/
      knowledge_corpus.jsonl          # KnowIT only; cached external-knowledge corpus

      {split}/
        build_manifest.json
        vision_health.json            # present for VLM builds
        report.md
        run_config.json

        packages/
          {video_id}/
            manifest.json

            evidence/
              evidence_units.jsonl

            media/
              frames/                 # sampled VLM frames, when enabled
              snapshots/
              clips/
              entities/

            wiki/
              narrative_sections.jsonl
              narrative_wiki.md
              kg_items.jsonl
              kg_wiki.md

            validation/
              claim_support.jsonl
              media_links.jsonl
              cross_modal_links.jsonl
              conflicts.jsonl

            index/
              retrieval_index.json

        qa/
          predictions.jsonl
          evidence_packets.jsonl
          traces.jsonl
          refinement.jsonl            # present when refinement runs
          run_manifest.json

        eval/
          metrics.json
          per_question.jsonl

        ablations/
          {variant}/
            predictions.jsonl
            evidence_packets.jsonl
            traces.jsonl
            latency.jsonl
            metrics.json
            per_question.jsonl
            run_manifest.json
            ablation_manifest.json

        stress/
          {setting}/
            {level}/
              predictions.jsonl
              metrics.json

        complete_eval/                 # extended evaluator output, when run
          execution_summary.json
          completeness_report.json
          metrics_complete.json
          run_manifest.json
          logs/
          metrics/
```
