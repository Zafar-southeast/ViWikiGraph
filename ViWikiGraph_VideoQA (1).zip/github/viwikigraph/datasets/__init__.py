"""Dataset adapters that normalize TVQA, KnowIT, and NExT-QA into the common
:class:`~viwikigraph.core.schemas.VideoRecord` / ``QAInstance`` schema."""

from viwikigraph.datasets.adapters import (
    KnowITAdapter,
    NextQAAdapter,
    TVQAAdapter,
    clean_html_subtitle,
    parse_knowit_scene_id,
)

__all__ = [
    "KnowITAdapter",
    "NextQAAdapter",
    "TVQAAdapter",
    "clean_html_subtitle",
    "parse_knowit_scene_id",
]
