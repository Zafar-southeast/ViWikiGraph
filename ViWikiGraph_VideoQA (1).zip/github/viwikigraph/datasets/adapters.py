"""Dataset adapters for the three ViWikiGraph benchmarks (spec §11).

Each adapter yields frozen :class:`~viwikigraph.core.schemas.VideoRecord` / ``QAInstance`` objects from the
raw dataset files. Gold annotations that would leak the answer (KnowIT ``reason``/``kg_type``/
``QType``, gold ``answer_index``) are kept ONLY in ``QAInstance.metadata`` and are never written into
``VideoRecord.metadata`` (the build-time evidence stream) — the leakage guard lives downstream in
``knowledge.py`` / ``retrieval.py``.

Conventions enforced here:
  - KnowIT ``idxCorrect`` is 1-based in the TSV; we normalize it to a 0-based ``answer_index``.
  - TVQA per-question bbox annotations are aggregated per video into
    ``VideoRecord.metadata["bbox_labels"]`` (``{frame_id: [labels]}``) for visual-concept ingestion.
  - NExT-QA MC ``answer`` is already 0-based; an optional caption sidecar populates subtitles.
"""

from __future__ import annotations

import csv
import html
import json
import pickle
import re
from collections import OrderedDict
from pathlib import Path
from typing import Any, Iterator

from viwikigraph.core.schemas import QAInstance, VideoRecord
from viwikigraph.core.text import optional_float as _optional_float


_BR_RE = re.compile(r"<br\s*/?>", re.IGNORECASE)
_TAG_RE = re.compile(r"<[^>]+>")
_SCENE_RE = re.compile(r"^(?P<show_id>s\d+e\d+)_(?P<scene_id>scene\d+)_(?P<start>\d+)_(?P<end>\d+)$")


def clean_html_subtitle(text: str) -> str:
    """Strip speaker markup / ``<br>`` tags and collapse whitespace in a subtitle line."""
    text = html.unescape(text or "")
    text = _BR_RE.sub(" ", text)
    text = _TAG_RE.sub("", text)
    return " ".join(text.split())


def parse_knowit_scene_id(scene_id: str) -> dict[str, float | str | None]:
    """Parse a KnowIT scene id (``s01e16_scene002_0450_0470``) into show/scene/start/end."""
    match = _SCENE_RE.match(scene_id)
    if not match:
        return {"show_id": scene_id, "scene_id": scene_id, "start": None, "end": None}
    return {
        "show_id": match.group("show_id"),
        "scene_id": match.group("scene_id"),
        "start": float(match.group("start")),
        "end": float(match.group("end")),
    }


class KnowITAdapter:
    """KnowIT VQA TSV adapter (knowledge-intensive, knowledge-RAG)."""

    dataset = "knowit"

    def __init__(self, annotation_paths: dict[str, str | Path], video_root: str | Path):
        self.annotation_paths = {key: Path(value) for key, value in annotation_paths.items()}
        self.video_root = Path(video_root)

    def iter_video_records(self, split: str) -> Iterator[VideoRecord]:
        seen: OrderedDict[str, VideoRecord] = OrderedDict()
        for row in self._rows(split):
            scene = row["scene"]
            if scene in seen:
                continue
            parsed = parse_knowit_scene_id(scene)
            subtitle = clean_html_subtitle(row.get("subtitle", ""))
            start = parsed.get("start")
            end = parsed.get("end")
            seen[scene] = VideoRecord(
                dataset=self.dataset,
                split=split,
                video_id=scene,
                video_path=str(self.video_root / f"{scene}.mp4"),
                subtitles=(
                    [{"text": subtitle, "start": start, "end": end, "source": "knowit_subtitle"}]
                    if subtitle
                    else []
                ),
                metadata={
                    "show_id": parsed.get("show_id"),
                    "scene_id": parsed.get("scene_id"),
                },
            )
        yield from seen.values()

    def iter_qa_instances(self, split: str) -> Iterator[QAInstance]:
        for index, row in enumerate(self._rows(split)):
            scene = row["scene"]
            options = [row.get(f"answer{i}", "") for i in range(1, 5)]
            answer_index = _knowit_answer_index(row.get("idxCorrect"))
            metadata: dict[str, Any] = {
                "reason": row.get("reason", ""),
                "kg_type": row.get("kg_type", ""),
                "scene": scene,
            }
            qtype = row.get("QType")
            if qtype is not None:
                metadata["QType"] = qtype
            yield QAInstance(
                question_id=f"{split}_{index}",
                video_id=scene,
                question=row.get("question", ""),
                options=options,
                answer_index=answer_index,
                metadata=metadata,
            )

    def iter_train_reasons(self, split: str = "train") -> Iterator[dict[str, str]]:
        """Yield ``{text, scene, source}`` knowledge rows from gold ``reason`` sentences.

        Used by :func:`viwikigraph.knowledge.corpus.build_knowledge_corpus` to seed the KnowIT
        knowledge-RAG corpus from the train split. The per-row leakage guard downstream ensures a
        queried row never retrieves its own ``reason``.
        """
        for row in self._rows(split):
            reason = (row.get("reason", "") or "").strip()
            if not reason:
                continue
            yield {"text": reason, "scene": row.get("scene", ""), "source": "knowit_reason"}

    def _rows(self, split: str) -> Iterator[dict[str, str]]:
        path = self.annotation_paths[split]
        with path.open(newline="", encoding="utf-8") as handle:
            yield from csv.DictReader(handle, delimiter="\t")


class TVQAAdapter:
    """TVQA+ adapter with subtitles, per-frame visual concepts, and bbox character labels."""

    dataset = "tvqa"

    def __init__(
        self,
        annotation_paths: dict[str, str | Path],
        subtitles_path: str | Path,
        visual_concepts_path: str | Path | None,
        video_root: str | Path,
    ):
        self.annotation_paths = {key: Path(value) for key, value in annotation_paths.items()}
        self.subtitles_path = Path(subtitles_path)
        self.visual_concepts_path = Path(visual_concepts_path) if visual_concepts_path else None
        self.video_root = Path(video_root)
        self._subtitles: dict | None = None
        self._visual_concepts: dict | None = None

    def iter_video_records(self, split: str) -> Iterator[VideoRecord]:
        seen: OrderedDict[str, VideoRecord] = OrderedDict()
        bbox_by_video: dict[str, dict[str, list[str]]] = {}
        for row in self._rows(split):
            video_id = row["vid_name"]
            _merge_bbox_labels(bbox_by_video.setdefault(video_id, {}), row.get("bbox"))
            if video_id in seen:
                continue
            subtitles = self._subtitle_spans(video_id)
            concepts = self._load_visual_concepts().get(video_id, [])
            seen[video_id] = VideoRecord(
                dataset=self.dataset,
                split=split,
                video_id=video_id,
                video_path=str(self.video_root / f"{video_id}.mp4"),
                subtitles=subtitles,
                metadata={"visual_concepts": concepts},
            )
        for video_id, record in seen.items():
            labels = {fid: lbls for fid, lbls in sorted(bbox_by_video.get(video_id, {}).items()) if lbls}
            if labels:
                record.metadata["bbox_labels"] = labels
            yield record

    def iter_qa_instances(self, split: str) -> Iterator[QAInstance]:
        for row in self._rows(split):
            qid = str(row.get("qid", ""))
            options = [row.get(f"a{i}", "") for i in range(5)]
            yield QAInstance(
                question_id=qid,
                video_id=row["vid_name"],
                question=row.get("q", ""),
                options=options,
                answer_index=_bounded_index(row.get("answer_idx"), len(options)),
                metadata={"ts": row.get("ts"), "bbox": row.get("bbox", {})},
            )

    def _rows(self, split: str) -> list[dict]:
        return json.loads(self.annotation_paths[split].read_text(encoding="utf-8"))

    def _load_subtitles(self) -> dict:
        if self._subtitles is None:
            self._subtitles = json.loads(self.subtitles_path.read_text(encoding="utf-8"))
        return self._subtitles

    def _load_visual_concepts(self) -> dict:
        if self._visual_concepts is not None:
            return self._visual_concepts
        if not self.visual_concepts_path or not self.visual_concepts_path.exists():
            self._visual_concepts = {}
        else:
            with self.visual_concepts_path.open("rb") as handle:
                self._visual_concepts = pickle.load(handle)
        return self._visual_concepts

    def _subtitle_spans(self, video_id: str) -> list[dict]:
        subtitle = self._load_subtitles().get(video_id, {})
        text = subtitle.get("sub_text", "")
        times = subtitle.get("sub_time", [])
        parts = [part.strip() for part in text.split("<eos>") if part.strip()]
        spans = []
        for index, part in enumerate(parts):
            start = times[index] if index < len(times) else None
            end = times[index + 1] if index + 1 < len(times) else start
            spans.append(
                {
                    "text": clean_html_subtitle(part),
                    "start": start,
                    "end": end,
                    "source": "tvqa_subtitle",
                    "index": index,
                }
            )
        return spans


class NextQAAdapter:
    """NExT-QA MC adapter (CSV: ``video,frame_count,width,height,question,answer,qid,type,a0..a4``).

    ``answer`` is already 0-based; ``type`` is surfaced as ``metadata["question_type"]``. NExT-QA
    ships no subtitles or visual labels, so two OPTIONAL externally-generated sidecars (produced on the
    user's cloud VM — never inside this code) provide the multimodal evidence streams:
      * ``captions_path`` — caption/ASR JSONL → ``VideoRecord.subtitles`` (text stream, e_text).
      * ``visual_concepts_path`` — per-frame concept JSONL → ``metadata["visual_concepts"]``
        (+ optional ``bbox_labels``), feeding the visual-grounding signal e_vis exactly like TVQA.
    """

    dataset = "nextqa"

    def __init__(
        self,
        annotation_paths: dict[str, str | Path],
        vidor_map_path: str | Path | None,
        video_root: str | Path,
        captions_path: str | Path | None = None,
        visual_concepts_path: str | Path | None = None,
    ):
        self.annotation_paths = {key: Path(value) for key, value in annotation_paths.items()}
        self.vidor_map_path = Path(vidor_map_path) if vidor_map_path else None
        self.video_root = Path(video_root)
        self.captions_path = Path(captions_path) if captions_path else None
        self.visual_concepts_path = Path(visual_concepts_path) if visual_concepts_path else None
        self._vidor_map: dict[str, str] | None = None
        self._captions: dict[str, list[dict[str, Any]]] | None = None
        self._visual: dict[str, dict[str, Any]] | None = None

    def iter_video_records(self, split: str) -> Iterator[VideoRecord]:
        seen: OrderedDict[str, VideoRecord] = OrderedDict()
        vidor_map = self._load_vidor_map()
        captions = self._load_captions()
        visual = self._load_visual_concepts()
        for row in self._rows(split):
            video_id = str(row.get("video", row.get("video_id", "")))
            if video_id in seen:
                continue
            vidor_id = vidor_map.get(video_id)
            metadata: dict[str, Any] = {"vidor_id": vidor_id, "source": "nextqa"}
            sidecar = visual.get(video_id)
            if sidecar:
                if sidecar.get("visual_concepts"):
                    metadata["visual_concepts"] = sidecar["visual_concepts"]
                if sidecar.get("bbox_labels"):
                    metadata["bbox_labels"] = sidecar["bbox_labels"]
            seen[video_id] = VideoRecord(
                dataset=self.dataset,
                split=split,
                video_id=video_id,
                # NExTVideo lays videos out as <group>/<id>.mp4 (the vidorID, e.g. "0101/2909445186"),
                # so resolve the path via the vidor map; fall back to a flat <id>.mp4 when unmapped.
                video_path=str(self.video_root / f"{vidor_id}.mp4") if vidor_id else str(self.video_root / f"{video_id}.mp4"),
                subtitles=_caption_spans(captions.get(video_id, [])),
                metadata=metadata,
            )
        yield from seen.values()

    def iter_qa_instances(self, split: str) -> Iterator[QAInstance]:
        for index, row in enumerate(self._rows(split)):
            video_id = str(row.get("video", row.get("video_id", "")))
            # Keep all five options positionally so the 0-based ``answer`` index stays aligned even if
            # a candidate string is empty (filtering would shift indices and mislabel the gold answer).
            options = [str(row.get(key, "")) for key in ("a0", "a1", "a2", "a3", "a4")]
            answer = row.get("answer", row.get("answer_idx", ""))
            # NExT-QA's ``qid`` is per-video (only ~15 distinct values across an entire split), so it
            # is NOT a unique key. Namespace it by ``video_id`` to get a split-unique question id —
            # otherwise predictions collide in ``evaluate_predictions`` (which keys by ``question_id``)
            # and the reported metrics become meaningless.
            raw_qid = row.get("qid", row.get("question_id", f"{split}_{index}"))
            yield QAInstance(
                question_id=f"{video_id}_{raw_qid}",
                video_id=video_id,
                question=row.get("question", row.get("q", "")),
                options=options,
                answer_index=_bounded_index(answer, len(options)),
                answer_text=row.get("answer_text"),
                metadata={"question_type": row.get("type", row.get("qtype", ""))},
            )

    def _rows(self, split: str) -> Iterator[dict[str, str]]:
        with self.annotation_paths[split].open(newline="", encoding="utf-8") as handle:
            yield from csv.DictReader(handle)

    def _load_vidor_map(self) -> dict[str, str]:
        if self._vidor_map is None:
            if self.vidor_map_path and self.vidor_map_path.exists():
                self._vidor_map = json.loads(self.vidor_map_path.read_text(encoding="utf-8"))
            else:
                self._vidor_map = {}
        return self._vidor_map

    def _load_captions(self) -> dict[str, list[dict[str, Any]]]:
        """Load the optional caption sidecar mapping ``video_id -> [{text,start,end}]``.

        Accepts either a single JSON object/array or line-delimited JSON. Each line/element may be a
        mapping ``{video_id -> [captions]}`` or a record ``{video_id, captions: [...]}``.
        """
        if self._captions is not None:
            return self._captions
        captions: dict[str, list[dict[str, Any]]] = {}
        if self.captions_path and self.captions_path.exists():
            for payload in _iter_json_payloads(self.captions_path):
                _accumulate_captions(captions, payload)
        self._captions = captions
        return self._captions

    def _load_visual_concepts(self) -> dict[str, dict[str, Any]]:
        """Load the optional visual-concept sidecar ``{video_id -> {visual_concepts:[...], bbox_labels:{}}}``.

        Accepts a single JSON object/array or line-delimited JSON. Each entry maps a video id to either
        a bare list of per-frame concept strings/lists (``visual_concepts``) or a record
        ``{video_id, visual_concepts:[...], bbox_labels:{frame_id:[labels]}}``."""
        if self._visual is not None:
            return self._visual
        visual: dict[str, dict[str, Any]] = {}
        if self.visual_concepts_path and self.visual_concepts_path.exists():
            for payload in _iter_json_payloads(self.visual_concepts_path):
                _accumulate_visual(visual, payload)
        self._visual = visual
        return self._visual


def _knowit_answer_index(value: Any) -> int | None:
    """Normalize KnowIT 1-based ``idxCorrect`` to a 0-based ``answer_index`` (1..4 → 0..3).

    Out-of-range or unparseable values yield ``None`` rather than a corrupt index, so malformed rows
    are simply unanswerable instead of silently misaligning evaluation.
    """
    parsed = _safe_int(value)
    if parsed is None or not (1 <= parsed <= 4):
        return None
    return parsed - 1


def _bounded_index(value: Any, n_options: int) -> int | None:
    """0-based answer index validated against ``n_options``; out-of-range/unparseable → ``None``."""
    parsed = _safe_int(value)
    if parsed is None or n_options <= 0 or not (0 <= parsed < n_options):
        return None
    return parsed


def _merge_bbox_labels(target: dict[str, list[str]], bbox: Any) -> None:
    """Merge a per-QA TVQA ``bbox`` mapping into ``{frame_id(str): [labels]}`` (de-duplicated)."""
    if not isinstance(bbox, dict):
        return
    for frame_id, boxes in bbox.items():
        frame_key = str(frame_id)
        existing = target.setdefault(frame_key, [])
        for box in _coerce_boxes(boxes):
            label = box.get("label") if isinstance(box, dict) else box
            label = str(label).strip() if label is not None else ""
            if label and label not in existing:
                existing.append(label)


def _coerce_boxes(boxes: Any) -> list[Any]:
    if isinstance(boxes, list):
        return boxes
    if isinstance(boxes, dict):
        return [boxes]
    return []


def _caption_spans(captions: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Convert sidecar caption entries into subtitle spans tagged ``source="nextqa_caption"``."""
    spans: list[dict[str, Any]] = []
    for index, caption in enumerate(captions):
        if not isinstance(caption, dict):
            text = str(caption).strip()
            start = end = None
        else:
            text = str(caption.get("text", "")).strip()
            start = _optional_float(caption.get("start"))
            end = _optional_float(caption.get("end"))
        if not text:
            continue
        spans.append({"text": text, "start": start, "end": end, "source": "nextqa_caption", "index": index})
    return spans


def _iter_json_payloads(path: Path) -> Iterator[Any]:
    """Yield JSON payloads from a sidecar that is either one JSON document or line-delimited JSON."""
    raw = path.read_text(encoding="utf-8").strip()
    if not raw:
        return
    try:
        yield json.loads(raw)
        return
    except json.JSONDecodeError:
        pass
    for line in raw.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            yield json.loads(line)
        except json.JSONDecodeError:
            continue


def _accumulate_captions(target: dict[str, list[dict[str, Any]]], payload: Any) -> None:
    """Fold one caption payload into ``target`` (``video_id -> [{text,start,end}]``)."""
    if isinstance(payload, list):
        for item in payload:
            _accumulate_captions(target, item)
        return
    if not isinstance(payload, dict):
        return
    if "video_id" in payload or "video" in payload:
        video_id = str(payload.get("video_id", payload.get("video", "")))
        if video_id:
            target.setdefault(video_id, []).extend(_coerce_caption_list(payload.get("captions")))
        return
    for video_id, captions in payload.items():
        target.setdefault(str(video_id), []).extend(_coerce_caption_list(captions))


def _coerce_caption_list(captions: Any) -> list[dict[str, Any]]:
    if isinstance(captions, list):
        return [item for item in captions if isinstance(item, (dict, str))]
    if isinstance(captions, (dict, str)):
        return [captions]
    return []


def _accumulate_visual(target: dict[str, dict[str, Any]], payload: Any) -> None:
    """Fold one visual-concept payload into ``target`` (``video_id -> {visual_concepts, bbox_labels}``)."""
    if isinstance(payload, list):
        for item in payload:
            _accumulate_visual(target, item)
        return
    if not isinstance(payload, dict):
        return
    if "video_id" in payload or "video" in payload:
        video_id = str(payload.get("video_id", payload.get("video", "")))
        if video_id:
            entry = target.setdefault(video_id, {})
            concepts = payload.get("visual_concepts", payload.get("concepts", payload.get("frames")))
            if isinstance(concepts, list):
                entry.setdefault("visual_concepts", []).extend(concepts)
            bbox = payload.get("bbox_labels")
            if isinstance(bbox, dict):
                entry.setdefault("bbox_labels", {}).update({str(k): v for k, v in bbox.items()})
        return
    for video_id, value in payload.items():
        entry = target.setdefault(str(video_id), {})
        if isinstance(value, list):
            entry.setdefault("visual_concepts", []).extend(value)
        elif isinstance(value, dict):
            concepts = value.get("visual_concepts", value.get("concepts", value.get("frames")))
            if isinstance(concepts, list):
                entry.setdefault("visual_concepts", []).extend(concepts)
            bbox = value.get("bbox_labels")
            if isinstance(bbox, dict):
                entry.setdefault("bbox_labels", {}).update({str(k): v for k, v in bbox.items()})


def _safe_int(value: str | int | None) -> int | None:
    """Coerce to int; ``None``/empty/unparseable values become ``None`` (tolerates malformed rows)."""
    if value in (None, ""):
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None
