"""Shared text/coercion helpers used across pipeline stages.

These were previously duplicated across several modules; consolidating them keeps tokenization,
float coercion, and timestamp formatting identical everywhere (and gives float coercion a single,
robust None-on-failure contract). This module imports nothing from the package, so it can be used by
``schemas`` and every stage without creating an import cycle.
"""

from __future__ import annotations

import re
from typing import Any

_TOKEN_RE = re.compile(r"[A-Za-z0-9]+")


def tokens(text: str) -> set[str]:
    """Set of lowercase alphanumeric tokens of length > 1 (for overlap/Jaccard scoring)."""
    return {token for token in _TOKEN_RE.findall((text or "").lower()) if len(token) > 1}


def tokenize(text: str) -> list[str]:
    """Ordered lowercase alphanumeric tokens of length > 1 (for term counts / BM25)."""
    return [token for token in _TOKEN_RE.findall((text or "").lower()) if len(token) > 1]


def words(text: str) -> list[str]:
    """All ordered lowercase alphanumeric tokens (no length filter; preserves order)."""
    return _TOKEN_RE.findall((text or "").lower())


def optional_float(value: Any) -> float | None:
    """Coerce ``value`` to ``float``; ``None``/empty/uncoercible values become ``None``."""
    if value in (None, ""):
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def fmt_time(value: float | None) -> str:
    """Format a timestamp in seconds (``12.34s``), or ``'?'`` when unknown."""
    return "?" if value is None else f"{value:.2f}s"
