from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any

from viwikigraph.core.text import optional_float as _optional_float


class Modality(str, Enum):
    SUBTITLE = "subtitle"
    ASR = "asr"
    OCR = "ocr"
    FRAME = "frame"
    SNAPSHOT = "snapshot"
    CLIP = "clip"
    CAPTION = "caption"
    VISUAL_CONCEPT = "visual_concept"
    QA_CONTEXT = "qa_context"


class LinkType(str, Enum):
    """Typed cross-modal evidence link relation ρ_λ (paper v1 eq. 20, §III-C)."""

    CLAIM_TEXT = "claim_text"          # narrative claim ↔ subtitle/ASR/OCR span
    CLAIM_MEDIA = "claim_media"        # narrative claim ↔ snapshot/clip
    TRIPLE_EVIDENCE = "triple_evidence"  # KG triple ↔ supporting evidence unit
    ENTITY_IMAGE = "entity_image"      # entity ↔ representative image
    EVENT_CLIP = "event_clip"          # event ↔ event clip
    SECTION_TRIPLE = "section_triple"  # narrative section ↔ KG triple
    TIME_ALIGN = "time_align"          # any two items sharing a timestamp/range


def _enum_value(value: Any) -> Any:
    if isinstance(value, Enum):
        return value.value
    if isinstance(value, list):
        return [_enum_value(item) for item in value]
    if isinstance(value, tuple):
        return [_enum_value(item) for item in value]
    if isinstance(value, dict):
        return {key: _enum_value(item) for key, item in value.items()}
    return value


class JsonDataclass:
    def to_dict(self) -> dict[str, Any]:
        return _enum_value(asdict(self))

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False, sort_keys=True)


@dataclass(slots=True)
class VideoRecord(JsonDataclass):
    dataset: str
    split: str
    video_id: str
    video_path: str
    subtitles: list[dict[str, Any]] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "VideoRecord":
        return cls(
            dataset=str(data["dataset"]),
            split=str(data["split"]),
            video_id=str(data["video_id"]),
            video_path=str(data.get("video_path", "")),
            subtitles=list(data.get("subtitles", [])),
            metadata=dict(data.get("metadata", {})),
        )


@dataclass(slots=True)
class QAInstance(JsonDataclass):
    question_id: str
    video_id: str
    question: str
    options: list[str] = field(default_factory=list)
    answer_index: int | None = None
    answer_text: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "QAInstance":
        answer_index = data.get("answer_index")
        return cls(
            question_id=str(data["question_id"]),
            video_id=str(data["video_id"]),
            question=str(data["question"]),
            options=list(data.get("options", [])),
            answer_index=None if answer_index in (None, "") else int(answer_index),
            answer_text=data.get("answer_text"),
            metadata=dict(data.get("metadata", {})),
        )


@dataclass(slots=True)
class EvidenceUnit(JsonDataclass):
    evidence_id: str
    video_id: str
    modality: Modality
    text: str = ""
    start: float | None = None
    end: float | None = None
    confidence: float = 1.0
    provenance: dict[str, Any] = field(default_factory=dict)
    entities: list[str] = field(default_factory=list)
    objects: list[str] = field(default_factory=list)
    actions: list[str] = field(default_factory=list)
    events: list[str] = field(default_factory=list)
    facts: list[tuple[str, str, str]] = field(default_factory=list)
    media_paths: list[str] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "EvidenceUnit":
        facts = [tuple(item) for item in data.get("facts", [])]
        return cls(
            evidence_id=str(data["evidence_id"]),
            video_id=str(data["video_id"]),
            modality=Modality(data["modality"]),
            text=str(data.get("text", "")),
            start=_optional_float(data.get("start")),
            end=_optional_float(data.get("end")),
            confidence=float(data.get("confidence", 1.0)),
            provenance=dict(data.get("provenance", {})),
            entities=[str(item) for item in data.get("entities", [])],
            objects=[str(item) for item in data.get("objects", [])],
            actions=[str(item) for item in data.get("actions", [])],
            events=[str(item) for item in data.get("events", [])],
            facts=[(str(h), str(r), str(o)) for h, r, o in facts],
            media_paths=[str(item) for item in data.get("media_paths", [])],
        )


@dataclass(slots=True)
class MediaItem(JsonDataclass):
    media_id: str
    video_id: str
    media_type: str
    path: str
    start: float | None = None
    end: float | None = None
    linked_item_id: str | None = None
    confidence: float = 1.0
    provenance: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "MediaItem":
        return cls(
            media_id=str(data["media_id"]),
            video_id=str(data["video_id"]),
            media_type=str(data["media_type"]),
            path=str(data["path"]),
            start=_optional_float(data.get("start")),
            end=_optional_float(data.get("end")),
            linked_item_id=data.get("linked_item_id"),
            confidence=float(data.get("confidence", 1.0)),
            provenance=dict(data.get("provenance", {})),
        )


@dataclass(slots=True)
class CrossModalLink(JsonDataclass):
    """Typed cross-modal evidence link λ = (a_i, a_j, ρ_λ, τ_λ, γ_λ, ξ_λ) (paper v1 eq. 20, §III-C).

    ``source_id``/``target_id`` reference existing item ids by string: a ``WikiSection.section_id``,
    ``KGItem.item_id``, ``EvidenceUnit.evidence_id`` (subtitle/OCR span), or ``MediaItem.media_id``.
    ``start``/``end`` encode the shared/supporting temporal range τ_λ (``None`` when not time-bound).
    """

    link_id: str
    video_id: str
    source_id: str
    target_id: str
    link_type: LinkType
    start: float | None = None
    end: float | None = None
    confidence: float = 1.0
    provenance: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "CrossModalLink":
        return cls(
            link_id=str(data["link_id"]),
            video_id=str(data["video_id"]),
            source_id=str(data["source_id"]),
            target_id=str(data["target_id"]),
            link_type=LinkType(data["link_type"]),
            start=_optional_float(data.get("start")),
            end=_optional_float(data.get("end")),
            confidence=float(data.get("confidence", 1.0)),
            provenance=dict(data.get("provenance", {})),
        )


@dataclass(slots=True)
class WikiSection(JsonDataclass):
    section_id: str
    video_id: str
    section_type: str
    heading: str
    content: str
    claims: list[str] = field(default_factory=list)
    evidence_ids: list[str] = field(default_factory=list)
    start: float | None = None
    end: float | None = None
    confidence: float = 1.0
    provenance: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "WikiSection":
        return cls(
            section_id=str(data["section_id"]),
            video_id=str(data["video_id"]),
            section_type=str(data["section_type"]),
            heading=str(data["heading"]),
            content=str(data.get("content", "")),
            claims=list(data.get("claims", [])),
            evidence_ids=list(data.get("evidence_ids", [])),
            start=_optional_float(data.get("start")),
            end=_optional_float(data.get("end")),
            confidence=float(data.get("confidence", 1.0)),
            provenance=dict(data.get("provenance", {})),
        )


@dataclass(slots=True)
class RelationTriple(JsonDataclass):
    subject: str
    relation: str
    object: str
    start: float | None = None
    end: float | None = None
    confidence: float = 1.0
    evidence_ids: list[str] = field(default_factory=list)
    provenance: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "RelationTriple":
        return cls(
            subject=str(data["subject"]),
            relation=str(data["relation"]),
            object=str(data["object"]),
            start=_optional_float(data.get("start")),
            end=_optional_float(data.get("end")),
            confidence=float(data.get("confidence", 1.0)),
            evidence_ids=list(data.get("evidence_ids", [])),
            provenance=dict(data.get("provenance", {})),
        )


@dataclass(slots=True)
class KGItem(JsonDataclass):
    item_id: str
    video_id: str
    item_type: str
    label: str
    description: str = ""
    triples: list[RelationTriple] = field(default_factory=list)
    evidence_ids: list[str] = field(default_factory=list)
    start: float | None = None
    end: float | None = None
    confidence: float = 1.0
    provenance: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = JsonDataclass.to_dict(self)
        data["triples"] = [triple.to_dict() for triple in self.triples]
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "KGItem":
        return cls(
            item_id=str(data["item_id"]),
            video_id=str(data["video_id"]),
            item_type=str(data["item_type"]),
            label=str(data["label"]),
            description=str(data.get("description", "")),
            triples=[RelationTriple.from_dict(item) for item in data.get("triples", [])],
            evidence_ids=list(data.get("evidence_ids", [])),
            start=_optional_float(data.get("start")),
            end=_optional_float(data.get("end")),
            confidence=float(data.get("confidence", 1.0)),
            provenance=dict(data.get("provenance", {})),
        )


@dataclass(slots=True)
class ValidationResult(JsonDataclass):
    """Six-dimension validation vector q(z) (paper v1 eq. 22-23): support, provenance, consistency,
    coverage, media, link. ``link`` (q_link, eq. 22) defaults to ``1.0`` — vacuously satisfied when an
    item has no incident cross-modal link, mirroring ``media``'s no-media convention. ``support_signals``
    persists the eq. 11 sub-signals (``e_text``/``e_ent``/``e_time``/``e_vis``/``e_ocr``).
    ``link`` is positioned AFTER ``decision`` (with a default) so existing positional constructors
    ``ValidationResult(id, type, sup, prov, cons, cov, media, decision)`` keep binding ``decision``.
    """

    item_id: str
    item_type: str
    support: float
    provenance: float
    consistency: float
    coverage: float
    media: float
    decision: str
    link: float = 1.0
    evidence_ids: list[str] = field(default_factory=list)
    notes: str = ""
    support_signals: dict[str, float] = field(default_factory=dict)
    unsupported_span: str = ""

    @property
    def score(self) -> float:
        # Fixed weights w_j (eq. 23, Σ w_j = 1). NOT learned — RAG-only / no-training constraint.
        weighted = (
            0.35 * self.support
            + 0.20 * self.provenance
            + 0.18 * self.consistency
            + 0.12 * self.coverage
            + 0.08 * self.media
            + 0.07 * self.link
        )
        return round(weighted, 2)

    def to_dict(self) -> dict[str, Any]:
        data = JsonDataclass.to_dict(self)
        data["score"] = self.score
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ValidationResult":
        return cls(
            item_id=str(data["item_id"]),
            item_type=str(data["item_type"]),
            support=float(data.get("support", 0.0)),
            provenance=float(data.get("provenance", 0.0)),
            consistency=float(data.get("consistency", 0.0)),
            coverage=float(data.get("coverage", 0.0)),
            media=float(data.get("media", 0.0)),
            decision=str(data.get("decision", "flag")),
            link=float(data.get("link", 1.0)),
            evidence_ids=list(data.get("evidence_ids", [])),
            notes=str(data.get("notes", "")),
            support_signals={str(k): float(v) for k, v in (data.get("support_signals") or {}).items()},
            unsupported_span=str(data.get("unsupported_span", "")),
        )


@dataclass(slots=True)
class EvidencePacket(JsonDataclass):
    """Retrieved per-question packet E_q = (R_nar, R_kg, R_media, R_link) (paper v1 eq. 31), plus an
    optional external-knowledge stream (not part of eq. 31). ``cross_modal_links`` carries R_link."""

    question_id: str
    video_id: str
    narrative_sections: list[WikiSection] = field(default_factory=list)
    kg_items: list[KGItem] = field(default_factory=list)
    media_items: list[MediaItem] = field(default_factory=list)
    subtitle_spans: list[EvidenceUnit] = field(default_factory=list)
    cross_modal_links: list[CrossModalLink] = field(default_factory=list)
    knowledge: list[dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "question_id": self.question_id,
            "video_id": self.video_id,
            "narrative_sections": [item.to_dict() for item in self.narrative_sections],
            "kg_items": [item.to_dict() for item in self.kg_items],
            "media_items": [item.to_dict() for item in self.media_items],
            "subtitle_spans": [item.to_dict() for item in self.subtitle_spans],
            "cross_modal_links": [item.to_dict() for item in self.cross_modal_links],
            "knowledge": [dict(item) for item in self.knowledge],
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "EvidencePacket":
        return cls(
            question_id=str(data["question_id"]),
            video_id=str(data["video_id"]),
            narrative_sections=[WikiSection.from_dict(item) for item in data.get("narrative_sections", [])],
            kg_items=[KGItem.from_dict(item) for item in data.get("kg_items", [])],
            media_items=[MediaItem.from_dict(item) for item in data.get("media_items", [])],
            subtitle_spans=[EvidenceUnit.from_dict(item) for item in data.get("subtitle_spans", [])],
            cross_modal_links=[CrossModalLink.from_dict(item) for item in data.get("cross_modal_links", [])],
            knowledge=[dict(item) for item in data.get("knowledge", [])],
        )


@dataclass(slots=True)
class QAPrediction(JsonDataclass):
    question_id: str
    video_id: str
    answer: str
    confidence: float = 0.0
    evidence_trace: list[dict[str, Any]] = field(default_factory=list)
    scoring_method: str = "unknown"
    predicted_index: int | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "QAPrediction":
        predicted_index = data.get("predicted_index")
        return cls(
            question_id=str(data["question_id"]),
            video_id=str(data["video_id"]),
            answer=str(data.get("answer", "")),
            confidence=float(data.get("confidence", 0.0)),
            evidence_trace=list(data.get("evidence_trace", [])),
            scoring_method=str(data.get("scoring_method", "unknown")),
            predicted_index=None if predicted_index in (None, "") else int(predicted_index),
        )

    def claim_traces(self) -> list["ClaimTrace"]:
        """Parse the claim-level entries of ``evidence_trace`` into :class:`ClaimTrace` objects.

        Skips the optional trailing ``{"verification": {...}}`` meta entry. Provides a typed view of
        the eq. 39 trace T_q for consumers (refinement, reporting) without changing the stored shape.
        """
        out: list[ClaimTrace] = []
        for entry in self.evidence_trace:
            if isinstance(entry, dict) and "claim" in entry and "verification" not in entry:
                out.append(ClaimTrace.from_dict(entry))
        return out


@dataclass(slots=True)
class ClaimTrace(JsonDataclass):
    """Claim-level evidence trace entry (c_m, S_m) of T_q (paper v1 eq. 39).

    Maps one atomic answer claim ``c_m`` to its support set ``S_m`` drawn across every evidence kind
    the paper enumerates: narrative sections, KG entries/triples, subtitle/ASR/OCR spans, supporting
    timestamps, snapshots/clips, cross-modal links, and provenance records. ``label`` carries the
    per-claim conditional-verification verdict (``sup``/``unsup``/``contr``, eq. 35-38).
    """

    claim: str
    section_ids: list[str] = field(default_factory=list)
    kg_item_ids: list[str] = field(default_factory=list)
    triple_ids: list[str] = field(default_factory=list)
    subtitle_ids: list[str] = field(default_factory=list)
    timestamps: list[tuple[float | None, float | None]] = field(default_factory=list)
    media_paths: list[str] = field(default_factory=list)
    link_ids: list[str] = field(default_factory=list)
    provenance: list[str] = field(default_factory=list)
    label: str = ""

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ClaimTrace":
        return cls(
            claim=str(data.get("claim", "")),
            section_ids=[str(x) for x in data.get("section_ids", [])],
            kg_item_ids=[str(x) for x in data.get("kg_item_ids", [])],
            triple_ids=[str(x) for x in data.get("triple_ids", [])],
            subtitle_ids=[str(x) for x in data.get("subtitle_ids", [])],
            timestamps=[(_optional_float(pair[0]), _optional_float(pair[1])) for pair in data.get("timestamps", []) if len(pair) == 2],
            media_paths=[str(x) for x in data.get("media_paths", [])],
            link_ids=[str(x) for x in data.get("link_ids", [])],
            provenance=[str(x) for x in data.get("provenance", [])],
            label=str(data.get("label", "")),
        )


@dataclass(slots=True)
class WikiPatch(JsonDataclass):
    """An evidence-gated wiki patch ΔW_q (paper v1 eq. 3, 40).

    ``op``/``target_type``/``target_id``/``content`` describe an add/revise/remove over a claim,
    triple, timestamp, provenance record, media link, or cross-modal link. ``validation`` holds the
    SAME 6-dim :class:`ValidationResult` gate applied before storage; ``accepted`` records whether
    Valid(ΔW_q)=1 (write-back). ``evidence_ids`` are the verified evidence the patch is derived from —
    never the question or gold answer.
    """

    patch_id: str
    video_id: str
    op: str  # 'add' | 'revise' | 'remove'
    target_type: str  # 'claim'|'section'|'triple'|'kg_item'|'timestamp'|'provenance'|'media_link'|'cross_modal_link'
    target_id: str | None = None
    content: dict[str, Any] = field(default_factory=dict)
    evidence_ids: list[str] = field(default_factory=list)
    validation: "ValidationResult | None" = None
    accepted: bool = False
    rationale: str = ""
    provenance: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = JsonDataclass.to_dict(self)
        data["validation"] = self.validation.to_dict() if self.validation else None
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "WikiPatch":
        validation = data.get("validation")
        return cls(
            patch_id=str(data["patch_id"]),
            video_id=str(data["video_id"]),
            op=str(data.get("op", "add")),
            target_type=str(data.get("target_type", "")),
            target_id=data.get("target_id"),
            content=dict(data.get("content", {})),
            evidence_ids=[str(x) for x in data.get("evidence_ids", [])],
            validation=ValidationResult.from_dict(validation) if validation else None,
            accepted=bool(data.get("accepted", False)),
            rationale=str(data.get("rationale", "")),
            provenance=dict(data.get("provenance", {})),
        )


#: Closed set of patch operations / target kinds for evidence-gated refinement (eq. 40).
PATCH_OPS = frozenset({"add", "revise", "remove"})
PATCH_TARGET_TYPES = frozenset(
    {"claim", "section", "triple", "kg_item", "timestamp", "provenance", "media_link", "cross_modal_link"}
)
