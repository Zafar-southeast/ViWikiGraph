"""Foundations: data models (:mod:`~viwikigraph.core.schemas`), JSON/JSONL IO
(:mod:`~viwikigraph.core.io`), and text helpers (:mod:`~viwikigraph.core.text`)."""

from viwikigraph.core.io import (
    Serializable,
    ensure_dir,
    read_json,
    read_jsonl,
    write_json,
    write_jsonl,
)
from viwikigraph.core.schemas import (
    ClaimTrace,
    CrossModalLink,
    EvidencePacket,
    EvidenceUnit,
    JsonDataclass,
    KGItem,
    LinkType,
    MediaItem,
    Modality,
    QAInstance,
    QAPrediction,
    RelationTriple,
    ValidationResult,
    VideoRecord,
    WikiPatch,
    WikiSection,
)
from viwikigraph.core.text import fmt_time, optional_float, tokenize, tokens, words

__all__ = [
    # schemas
    "ClaimTrace",
    "CrossModalLink",
    "EvidencePacket",
    "EvidenceUnit",
    "JsonDataclass",
    "KGItem",
    "LinkType",
    "MediaItem",
    "Modality",
    "QAInstance",
    "QAPrediction",
    "RelationTriple",
    "ValidationResult",
    "VideoRecord",
    "WikiPatch",
    "WikiSection",
    # io
    "Serializable",
    "ensure_dir",
    "read_json",
    "read_jsonl",
    "write_json",
    "write_jsonl",
    # text
    "fmt_time",
    "optional_float",
    "tokenize",
    "tokens",
    "words",
]
