"""Downstream retrieval for wiki-grounded VideoQA (paper §IV-G, eq. 29-33).

This module turns a per-video knowledge package (:class:`RetrievalIndex`) into a per-question
:class:`EvidencePacket`. It is deterministic and dependency-free:

  - :func:`route_query` (eq. 30) derives an :class:`EvidenceNeed` flag vector. The default path is
    rule-based (wh-word / question-type heuristics); an optional ``llm`` uses
    :func:`viwikigraph.llm.prompts.router_prompt`.
  - :func:`retrieve_evidence` (eq. 29, 31-33) scores narrative sections by ``s_nar``, KG items by
    ``s_kg``, selects subtitle spans (windowed by ``qa.metadata["ts"]`` when present), links media
    paths, and pulls external knowledge when ``need.needs_knowledge`` is set.

Scoring blends a lexical Jaccard overlap, a small local Okapi BM25 (implemented here — no heavy
deps), section-type / metadata compatibility derived from the routed :class:`EvidenceNeed`, and the
stored validation/confidence signal. ``KnowledgeCorpus`` is duck-typed (lazy / structural) so this
module never imports :mod:`viwikigraph.knowledge.corpus` at module load and avoids an import cycle.
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable

from viwikigraph.core.schemas import (
    CrossModalLink,
    EvidencePacket,
    EvidenceUnit,
    KGItem,
    LinkType,
    MediaItem,
    Modality,
    QAInstance,
    WikiSection,
)
from viwikigraph.core.text import tokenize as _tokenize
from viwikigraph.core.text import tokens as _tokens

# Subtitle/ASR modalities eligible for the windowed subtitle-span budget.
_SUBTITLE_MODALITIES = (Modality.SUBTITLE, Modality.ASR, Modality.CAPTION)

# wh-words / cue tokens → evidence-need flags (eq. 30 rule-based router).
_TEMPORAL_CUES = (
    "when",
    "before",
    "after",
    "first",
    "last",
    "next",
    "then",
    "begin",
    "start",
    "end",
    "during",
    "order",
    "while",
)
_VISUAL_CUES = (
    "color",
    "colour",
    "wear",
    "wearing",
    "see",
    "look",
    "holding",
    "hold",
    "object",
    "where",
    "scene",
    "appear",
    "show",
    "screen",
    "doing",
    "hand",
    "behind",
    "left",
    "right",
)
_KNOWLEDGE_CUES = (
    "why",
    "because",
    "reason",
    "know",
    "mean",
    "meaning",
    "refer",
    "relationship",
    "related",
    "based on",
)
_VERIFY_CUES = ("not", "never", "except", "false", "incorrect", "wrong", "really", "actually")


@dataclass(slots=True)
class EvidenceNeed:
    """Routed evidence-need vector for one question (router output, eq. 30)."""

    needs_narrative: bool = True
    needs_kg: bool = True
    needs_temporal: bool = False
    needs_visual: bool = False
    needs_knowledge: bool = False
    needs_verification: bool = False
    source: str = "rule"

    def to_dict(self) -> dict[str, Any]:
        return {
            "needs_narrative": self.needs_narrative,
            "needs_kg": self.needs_kg,
            "needs_temporal": self.needs_temporal,
            "needs_visual": self.needs_visual,
            "needs_knowledge": self.needs_knowledge,
            "needs_verification": self.needs_verification,
            "source": self.source,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "EvidenceNeed":
        return cls(
            needs_narrative=bool(data.get("needs_narrative", True)),
            needs_kg=bool(data.get("needs_kg", True)),
            needs_temporal=bool(data.get("needs_temporal", False)),
            needs_visual=bool(data.get("needs_visual", False)),
            needs_knowledge=bool(data.get("needs_knowledge", False)),
            needs_verification=bool(data.get("needs_verification", False)),
            source=str(data.get("source", "rule")),
        )


@runtime_checkable
class KnowledgeLike(Protocol):
    """Structural type for :class:`viwikigraph.knowledge.corpus.KnowledgeCorpus` (duck-typed)."""

    def retrieve(self, question: str, options: list[str], k: int) -> list[dict[str, Any]]:
        ...


@dataclass(slots=True)
class RetrievalIndex:
    """Per-video knowledge package indexed for question-time retrieval.

    ``evidence_units`` carries the raw subtitle/ASR/caption spans so the subtitle-span budget
    (``Bsub``, eq. 33) can be served directly. It is optional/back-compatible: when empty,
    :func:`_rank_subtitle_spans` falls back to reconstructing spans from section provenance.
    """

    narrative_sections: list[WikiSection]
    kg_items: list[KGItem]
    media_items: list[MediaItem]
    evidence_units: list[EvidenceUnit] = field(default_factory=list)
    cross_modal_links: list[CrossModalLink] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "narrative_sections": [item.to_dict() for item in self.narrative_sections],
            "kg_items": [item.to_dict() for item in self.kg_items],
            "media_items": [item.to_dict() for item in self.media_items],
            "evidence_units": [item.to_dict() for item in self.evidence_units],
            "cross_modal_links": [item.to_dict() for item in self.cross_modal_links],
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "RetrievalIndex":
        return cls(
            narrative_sections=[WikiSection.from_dict(item) for item in data.get("narrative_sections", [])],
            kg_items=[KGItem.from_dict(item) for item in data.get("kg_items", [])],
            media_items=[MediaItem.from_dict(item) for item in data.get("media_items", [])],
            evidence_units=[EvidenceUnit.from_dict(item) for item in data.get("evidence_units", [])],
            cross_modal_links=[CrossModalLink.from_dict(item) for item in data.get("cross_modal_links", [])],
        )


def build_retrieval_index(
    narrative_sections: list[WikiSection],
    kg_items: list[KGItem],
    media_items: list[MediaItem],
    evidence_units: list[EvidenceUnit] | None = None,
    cross_modal_links: list[CrossModalLink] | None = None,
) -> RetrievalIndex:
    """Bundle narrative sections, KG items, media, subtitle spans, and cross-modal links into a
    queryable index (eq. 27-31)."""
    return RetrievalIndex(
        narrative_sections=narrative_sections,
        kg_items=kg_items,
        media_items=media_items,
        evidence_units=list(evidence_units or []),
        cross_modal_links=list(cross_modal_links or []),
    )


def route_query(question: str, options: list[str] | None = None, llm: Any = None) -> EvidenceNeed:
    """Derive the evidence-need vector for a question (eq. 30).

    Rule-based by default (wh-word / cue heuristics). When ``llm`` is provided and available, uses
    :func:`viwikigraph.llm.prompts.router_prompt`; any error or no-key situation falls back to the rules.
    """
    options = list(options or [])
    if llm is not None and getattr(llm, "available", False):
        routed = _route_with_llm(question, options, llm)
        if routed is not None:
            return routed
    return _route_rule_based(question, options)


def _route_rule_based(question: str, options: list[str]) -> EvidenceNeed:
    """Heuristic router: map wh-words and cue tokens to evidence-need flags."""
    text = question.lower()
    tokens = set(_tokens(question))

    def has(cues: tuple[str, ...]) -> bool:
        return any(cue in text for cue in cues)

    needs_temporal = has(_TEMPORAL_CUES)
    needs_visual = has(_VISUAL_CUES) or "what" in tokens
    needs_knowledge = has(_KNOWLEDGE_CUES)
    needs_verification = has(_VERIFY_CUES)
    # "who" questions lean on entity/relation (KG) evidence; everything keeps narrative + KG on.
    needs_kg = True
    needs_narrative = True
    return EvidenceNeed(
        needs_narrative=needs_narrative,
        needs_kg=needs_kg,
        needs_temporal=needs_temporal,
        needs_visual=needs_visual,
        needs_knowledge=needs_knowledge,
        needs_verification=needs_verification,
        source="rule",
    )


def _route_with_llm(question: str, options: list[str], llm: Any) -> EvidenceNeed | None:
    """Run the LLM router; return ``None`` on any failure so the caller can fall back."""
    try:
        from viwikigraph.llm.prompts import parse_json, router_prompt

        response = llm.chat(router_prompt(question, options), response_format="json", cache_version="router_v1")
        data = parse_json(response.text)
        if not data:
            return None
        rules = _route_rule_based(question, options)
        return EvidenceNeed(
            needs_narrative=bool(data.get("needs_narrative", rules.needs_narrative)),
            needs_kg=bool(data.get("needs_kg", rules.needs_kg)),
            needs_temporal=bool(data.get("needs_temporal", rules.needs_temporal)),
            needs_visual=bool(data.get("needs_visual", rules.needs_visual)),
            needs_knowledge=bool(data.get("needs_knowledge", rules.needs_knowledge)),
            needs_verification=bool(data.get("needs_verification", rules.needs_verification)),
            source="llm",
        )
    except Exception:
        return None


def retrieve_evidence(
    *args: Any,
    need: EvidenceNeed | None = None,
    knowledge: KnowledgeLike | None = None,
    **kwargs: Any,
) -> EvidencePacket:
    """Retrieve a per-question :class:`EvidencePacket` from ``index`` (eq. 29, 31-33).

    Two calling conventions are supported (the legacy one is kept for existing callers/tests), each
    usable positionally or by keyword:

      - new:    ``retrieve_evidence(qa, index, budgets, *, need=None, knowledge=None)``
      - legacy: ``retrieve_evidence(question_id, video_id, question, index, budgets)``

    ``budgets`` keys: ``narrative``/``Bnar``, ``kg``/``Bkg``, ``subtitle``/``Bsub``,
    ``media``/``Bmedia``, ``knowledge``/``Bknow``.
    """
    qa, index, budgets = _normalize_call(args, kwargs)
    options = list(qa.options or [])
    need = need or route_query(qa.question, options)

    b_nar = _budget(budgets, "narrative", "Bnar", 4)
    b_kg = _budget(budgets, "kg", "Bkg", 8)
    b_sub = _budget(budgets, "subtitle", "Bsub", 4)
    b_media = _budget(budgets, "media", "Bmedia", 2)
    b_link = _budget(budgets, "link", "Blink", 4)
    b_know = _budget(budgets, "knowledge", "Bknow", 4)
    if need.needs_temporal:
        # Temporal before/after questions need ordered context more than a tiny lexical top-k. Keep
        # the default budgets for non-temporal queries, but give temporal QA enough timestamped
        # visual-caption spans to reconstruct a local event sequence.
        b_sub = max(b_sub, 12)
        b_nar = max(b_nar, 6)

    query = qa.question if not options else qa.question + " " + " ".join(options)
    query_tokens = _tokens(query)

    sections = _rank_sections(query_tokens, index.narrative_sections, qa.video_id, need)[:b_nar]
    kg_items = _rank_kg_items(query_tokens, index.kg_items, qa.video_id, need)[:b_kg]
    subtitle_spans = _rank_subtitle_spans(
        query_tokens, index.evidence_units, index.narrative_sections, qa, b_sub, temporal=need.needs_temporal
    )
    media_items = _link_media(sections, kg_items, index.media_items, qa.video_id, b_media)
    # Link expansion (eq. 31): surface cross-modal links incident on the already-retrieved
    # high-confidence items, filtered by the routed evidence need, then add any linked subtitle/media
    # items not yet present (within budget).
    cross_modal_links = _expand_links(index, sections, kg_items, media_items, subtitle_spans, need, b_link)
    subtitle_spans, media_items = _augment_from_links(
        index, cross_modal_links, subtitle_spans, media_items, qa.video_id, b_sub, b_media
    )
    knowledge_snippets = _retrieve_knowledge(qa, options, need, knowledge, b_know)

    return EvidencePacket(
        question_id=qa.question_id,
        video_id=qa.video_id,
        narrative_sections=sections,
        kg_items=kg_items,
        media_items=media_items,
        subtitle_spans=subtitle_spans,
        cross_modal_links=cross_modal_links,
        knowledge=knowledge_snippets,
    )


def _normalize_call(
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
) -> tuple[QAInstance, RetrievalIndex, dict[str, int]]:
    """Resolve both supported call conventions into ``(qa, index, budgets)``.

    Accepts the new ``(qa, index, budgets)`` and the legacy
    ``(question_id, video_id, question, index, budgets)`` layouts, positionally or by keyword.
    """
    first = args[0] if args else kwargs.get("qa")
    if isinstance(first, QAInstance):
        # new layout: (qa, index, budgets)
        qa = first
        index = args[1] if len(args) > 1 else kwargs.get("index")
        budgets = args[2] if len(args) > 2 else kwargs.get("budgets")
    else:
        # legacy layout: (question_id, video_id, question, index, budgets)
        question_id = args[0] if len(args) > 0 else kwargs.get("question_id")
        video_id = args[1] if len(args) > 1 else kwargs.get("video_id")
        question = args[2] if len(args) > 2 else kwargs.get("question")
        index = args[3] if len(args) > 3 else kwargs.get("index")
        budgets = args[4] if len(args) > 4 else kwargs.get("budgets")
        qa = QAInstance(
            question_id=str(question_id),
            video_id=str(video_id),
            question=str(question),
        )
    if not isinstance(index, RetrievalIndex):
        raise TypeError("retrieve_evidence requires a RetrievalIndex.")
    return qa, index, dict(budgets or {})


def _rank_sections(
    query_tokens: set[str],
    sections: list[WikiSection],
    video_id: str,
    need: EvidenceNeed,
) -> list[WikiSection]:
    """Score narrative sections by ``s_nar`` (eq. 31) and return them best-first."""
    if not need.needs_narrative:
        return []
    candidates = [section for section in sections if section.video_id == video_id]
    bm25 = _BM25([_section_text(section) for section in candidates])
    scored: list[tuple[float, int, WikiSection]] = []
    for idx, section in enumerate(candidates):
        text = _section_text(section)
        lexical = _jaccard(query_tokens, _tokens(text))
        bm = bm25.score(query_tokens, idx)
        compat = _section_type_compat(section.section_type, need)
        validation = _validation_signal(section.content, section.confidence)
        score = lexical + 0.5 * bm + 0.25 * compat + 0.15 * validation
        scored.append((score, idx, section))
    scored.sort(key=lambda triple: (-triple[0], triple[1]))
    return [section for _, _, section in scored]


def _rank_kg_items(
    query_tokens: set[str],
    kg_items: list[KGItem],
    video_id: str,
    need: EvidenceNeed,
) -> list[KGItem]:
    """Score KG items by ``s_kg`` (eq. 32) and return them best-first."""
    if not need.needs_kg:
        return []
    candidates = [item for item in kg_items if item.video_id == video_id]
    bm25 = _BM25([_kg_text(item) for item in candidates])
    scored: list[tuple[float, int, KGItem]] = []
    for idx, item in enumerate(candidates):
        text = _kg_text(item)
        lexical = _jaccard(query_tokens, _tokens(text))
        bm = bm25.score(query_tokens, idx)
        compat = _kg_type_compat(item.item_type, need)
        validation = _validation_signal(item.description or item.label, item.confidence)
        score = lexical + 0.5 * bm + 0.25 * compat + 0.15 * validation
        scored.append((score, idx, item))
    scored.sort(key=lambda triple: (-triple[0], triple[1]))
    return [item for _, _, item in scored]


def _rank_subtitle_spans(
    query_tokens: set[str],
    evidence_units: list[EvidenceUnit],
    sections: list[WikiSection],
    qa: QAInstance,
    budget: int,
    *,
    temporal: bool = False,
) -> list[EvidenceUnit]:
    """Top-``budget`` subtitle/ASR spans, windowed by ``qa.metadata["ts"]`` when present (eq. 33).

    Prefers the index's raw ``evidence_units`` (populated by the build phase); if none are present
    it reconstructs spans from any ``subtitle_units`` cached on a section's provenance. When neither
    source has spans the list is empty — the expected NExT-QA evidence-free case.
    """
    if budget <= 0:
        return []
    window = _parse_window(qa.metadata.get("ts")) if qa.metadata else None
    units: list[EvidenceUnit] = []
    seen: set[str] = set()
    for unit in evidence_units:
        if unit.video_id != qa.video_id or unit.modality not in _SUBTITLE_MODALITIES:
            continue
        if unit.evidence_id in seen:
            continue
        seen.add(unit.evidence_id)
        units.append(unit)
    if not units:
        for section in sections:
            if section.video_id != qa.video_id:
                continue
            for raw in section.provenance.get("subtitle_units", []):
                try:
                    unit = EvidenceUnit.from_dict(raw)
                except (KeyError, TypeError, ValueError):
                    continue
                if unit.modality not in _SUBTITLE_MODALITIES or unit.evidence_id in seen:
                    continue
                seen.add(unit.evidence_id)
                units.append(unit)
    if window is not None:
        windowed = [unit for unit in units if _overlaps_window(unit, window)]
        units = windowed or units
    if temporal:
        scored = sorted(
            units,
            key=lambda unit: (
                -(0.6 * _jaccard(query_tokens, _tokens(unit.text)) + 0.4 * _temporal_action_overlap(qa, unit)),
                unit.start if unit.start is not None else float("inf"),
            ),
        )
        top = scored[:budget]
        return sorted(top, key=lambda unit: unit.start if unit.start is not None else float("inf"))

    scored = sorted(
        units,
        key=lambda unit: (-_jaccard(query_tokens, _tokens(unit.text)), unit.start or 0.0),
    )
    return scored[:budget]


def _link_media(
    sections: list[WikiSection],
    kg_items: list[KGItem],
    media_items: list[MediaItem],
    video_id: str,
    budget: int,
) -> list[MediaItem]:
    """Collect media paths linked from the selected sections / KG items; top-``budget`` (eq. 33)."""
    if budget <= 0:
        return []
    ordered_paths: list[str] = []
    for section in sections:
        ordered_paths.extend(section.provenance.get("media_paths", []))
    for item in kg_items:
        ordered_paths.extend(item.provenance.get("media_paths", []))
    # De-duplicate while preserving link order.
    deduped: list[str] = []
    for path in ordered_paths:
        if path and path not in deduped:
            deduped.append(path)

    by_path = {item.path: item for item in media_items if item.video_id == video_id}
    linked: list[MediaItem] = []
    for idx, path in enumerate(deduped):
        if path in by_path:
            linked.append(by_path[path])
        else:
            linked.append(
                MediaItem(
                    media_id=f"linked_{idx}",
                    video_id=video_id,
                    media_type="linked",
                    path=path,
                    linked_item_id=None,
                    confidence=1.0,
                    provenance={"source": "retrieval_link"},
                )
            )
    return linked[:budget]


# Link types whose relevance is gated by a specific routed need (eq. 31 "matches the evidence need").
_VISUAL_LINK_TYPES = (LinkType.CLAIM_MEDIA, LinkType.ENTITY_IMAGE, LinkType.EVENT_CLIP)


def _link_matches_need(link: CrossModalLink, need: EvidenceNeed) -> bool:
    """Whether a cross-modal link matches the routed evidence need r_q (eq. 31 link expansion)."""
    if link.link_type in _VISUAL_LINK_TYPES:
        return need.needs_visual
    if link.link_type == LinkType.TIME_ALIGN:
        return need.needs_temporal or need.needs_visual
    # CLAIM_TEXT / TRIPLE_EVIDENCE / SECTION_TRIPLE serve narrative/KG needs, which are on by default.
    return need.needs_narrative or need.needs_kg


def _expand_links(
    index: "RetrievalIndex",
    sections: list[WikiSection],
    kg_items: list[KGItem],
    media_items: list[MediaItem],
    subtitle_spans: list[EvidenceUnit],
    need: EvidenceNeed,
    budget: int,
) -> list[CrossModalLink]:
    """Select R_link (eq. 31): links incident on already-retrieved items, matching r_q, best-first.

    Only links touching a retrieved item are expanded ("expand evidence only from already retrieved
    high-confidence items"); ranked by link confidence and capped at ``budget``.
    """
    if budget <= 0 or not index.cross_modal_links:
        return []
    retrieved = (
        {s.section_id for s in sections}
        | {k.item_id for k in kg_items}
        | {m.media_id for m in media_items}
        | {u.evidence_id for u in subtitle_spans}
    )
    candidates = [
        link
        for link in index.cross_modal_links
        if (link.source_id in retrieved or link.target_id in retrieved) and _link_matches_need(link, need)
    ]
    candidates.sort(key=lambda link: (-link.confidence, link.link_id))
    return candidates[:budget]


def _augment_from_links(
    index: "RetrievalIndex",
    links: list[CrossModalLink],
    subtitle_spans: list[EvidenceUnit],
    media_items: list[MediaItem],
    video_id: str,
    b_sub: int,
    b_media: int,
) -> tuple[list[EvidenceUnit], list[MediaItem]]:
    """Add linked subtitle/media items referenced by ``links`` but not yet retrieved (within budget)."""
    sub_by_id = {u.evidence_id: u for u in index.evidence_units if u.modality in _SUBTITLE_MODALITIES}
    media_by_id = {m.media_id: m for m in index.media_items if m.video_id == video_id}
    have_sub = {u.evidence_id for u in subtitle_spans}
    have_media = {m.media_id for m in media_items}
    subtitle_spans = list(subtitle_spans)
    media_items = list(media_items)
    for link in links:
        for endpoint in (link.source_id, link.target_id):
            if endpoint in sub_by_id and endpoint not in have_sub and len(subtitle_spans) < b_sub:
                have_sub.add(endpoint)
                subtitle_spans.append(sub_by_id[endpoint])
            elif endpoint in media_by_id and endpoint not in have_media and len(media_items) < b_media:
                have_media.add(endpoint)
                media_items.append(media_by_id[endpoint])
    return subtitle_spans, media_items


def _retrieve_knowledge(
    qa: QAInstance,
    options: list[str],
    need: EvidenceNeed,
    knowledge: KnowledgeLike | None,
    budget: int,
) -> list[dict[str, Any]]:
    """External-knowledge snippets via the duck-typed corpus when ``need.needs_knowledge`` (§6)."""
    if not need.needs_knowledge or knowledge is None or budget <= 0:
        return []
    retrieve = getattr(knowledge, "retrieve", None)
    if not callable(retrieve):
        return []
    # Leakage guard: never let a row retrieve its own gold knowledge. KnowIT's scene id IS the
    # video id, so exclude_scene=qa.video_id drops the queried row's own reason even when the corpus
    # was (mis)built to include the queried split. Corpora without the kwarg fall back gracefully.
    try:
        snippets = retrieve(qa.question, options, budget, exclude_scene=qa.video_id)
    except TypeError:
        try:
            snippets = retrieve(qa.question, options, budget)
        except Exception:
            return []
    except Exception:
        return []
    return [dict(item) for item in (snippets or [])][:budget]


# --------------------------------------------------------------------------------------------------
# Scoring helpers
# --------------------------------------------------------------------------------------------------


class _BM25:
    """Minimal Okapi BM25 over a small in-memory corpus (no external dependencies)."""

    __slots__ = ("_docs", "_df", "_avg_len", "_n", "_k1", "_b")

    def __init__(self, documents: list[str], k1: float = 1.5, b: float = 0.75) -> None:
        self._docs = [_term_counts(doc) for doc in documents]
        self._n = len(self._docs)
        self._k1 = k1
        self._b = b
        self._df: dict[str, int] = {}
        for counts in self._docs:
            for term in counts:
                self._df[term] = self._df.get(term, 0) + 1
        lengths = [sum(counts.values()) for counts in self._docs]
        self._avg_len = (sum(lengths) / self._n) if self._n else 0.0

    def score(self, query_terms: set[str], doc_index: int) -> float:
        if self._n == 0 or not query_terms or doc_index >= self._n:
            return 0.0
        counts = self._docs[doc_index]
        doc_len = sum(counts.values())
        if doc_len == 0:
            return 0.0
        total = 0.0
        for term in query_terms:
            freq = counts.get(term, 0)
            if freq == 0:
                continue
            df = self._df.get(term, 0)
            idf = math.log(1.0 + (self._n - df + 0.5) / (df + 0.5))
            denom = freq + self._k1 * (1.0 - self._b + self._b * doc_len / (self._avg_len or 1.0))
            total += idf * (freq * (self._k1 + 1.0)) / (denom or 1.0)
        return total


def _validation_signal(text: str, confidence: float) -> float:
    """Validation/confidence signal for ranking; uses ``validation.support_score`` if available.

    The validation module owns ``support_score`` (spec §7); it may be absent in some builds, so it is
    imported lazily and the stored item confidence is used as the deterministic fallback.
    """
    try:  # pragma: no cover - exercised only when validation.support_score exists
        from viwikigraph.knowledge.validation import support_score  # type: ignore[attr-defined]

        score, _ = support_score(text, [])
        return float(max(0.0, min(1.0, score)))
    except Exception:
        return float(max(0.0, min(1.0, confidence)))


def _section_type_compat(section_type: str, need: EvidenceNeed) -> float:
    """Section-type / metadata compatibility derived from the routed need (eq. 31)."""
    section_type = (section_type or "").lower()
    score = 0.0
    if need.needs_temporal and section_type in {"event", "scene"}:
        score += 1.0
    if need.needs_visual and section_type in {"object", "scene", "location"}:
        score += 1.0
    if need.needs_kg and section_type in {"entity", "object", "location"}:
        score += 0.5
    if section_type == "summary":
        score += 0.25
    return min(2.0, score)


def _kg_type_compat(item_type: str, need: EvidenceNeed) -> float:
    """KG item-type compatibility derived from the routed need (eq. 32)."""
    item_type = (item_type or "").lower()
    score = 0.0
    if need.needs_temporal and item_type in {"temporal_link", "event"}:
        score += 1.0
    if need.needs_visual and item_type in {"object", "location"}:
        score += 1.0
    if need.needs_kg and item_type in {"entity", "triple", "event"}:
        score += 0.5
    if item_type == "contradiction_link" and need.needs_verification:
        score += 0.5
    return min(2.0, score)


def _section_text(section: WikiSection) -> str:
    return " ".join([section.heading, section.content, *section.claims])


def _kg_text(item: KGItem) -> str:
    parts = [item.label, item.description]
    for triple in item.triples:
        parts.extend([triple.subject, triple.relation, triple.object])
    return " ".join(parts)


def _parse_window(ts: Any) -> tuple[float, float] | None:
    """Parse a TVQA-style timestamp window into ``(start, end)`` seconds."""
    if ts is None:
        return None
    if isinstance(ts, (list, tuple)) and len(ts) == 2:
        try:
            return float(ts[0]), float(ts[1])
        except (TypeError, ValueError):
            return None
    if isinstance(ts, str):
        match = re.findall(r"-?\d+(?:\.\d+)?", ts)
        if len(match) >= 2:
            return float(match[0]), float(match[1])
    return None


def _overlaps_window(unit: EvidenceUnit, window: tuple[float, float]) -> bool:
    """True when a unit's [start, end] overlaps the query window (units without times pass)."""
    start, end = window
    if unit.start is None and unit.end is None:
        return True
    u_start = unit.start if unit.start is not None else unit.end
    u_end = unit.end if unit.end is not None else unit.start
    return u_start <= end and u_end >= start


def _temporal_action_overlap(qa: QAInstance, unit: EvidenceUnit) -> float:
    """Option/action-aware score for temporal captions.

    TP/TN options are often short verbs ("jump", "bow", "clap"). A pure question-token score can
    miss the actual candidate action because the question names the target event, not the answer
    event. This adds a small option-token signal while staying gold-free.
    """
    option_tokens = set()
    for option in qa.options or []:
        option_tokens.update(_tokens(option))
    if not option_tokens:
        return 0.0
    unit_tokens = _tokens(" ".join([unit.text, *unit.actions, *unit.events]))
    return _jaccard(option_tokens, unit_tokens)


def _budget(budgets: dict[str, int], primary: str, alias: str, default: int) -> int:
    value = budgets.get(primary, budgets.get(alias, default))
    try:
        return max(0, int(value))
    except (TypeError, ValueError):
        return default


def _jaccard(query_tokens: set[str], doc_tokens: set[str]) -> float:
    if not query_tokens or not doc_tokens:
        return 0.0
    intersection = len(query_tokens & doc_tokens)
    return intersection / len(query_tokens)


def _term_counts(text: str) -> dict[str, int]:
    counts: dict[str, int] = {}
    for token in _tokenize(text):
        counts[token] = counts.get(token, 0) + 1
    return counts
