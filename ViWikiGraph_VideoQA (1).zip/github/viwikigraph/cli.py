"""Command-line entry point for the ViWikiGraph RAG-only pipeline.

Subcommands (all dataset commands take ``--dataset`` / ``--split``; package-producing and
report-producing commands take ``--experiment-id``):

  - ``build``  — build per-video knowledge packages (Phases 1-3 + validation).
  - ``qa``     — route + retrieve + answer each question over the built packages (eq. 29-41).
  - ``eval``   — score predictions (accuracy, EM/F1) against gold labels.
  - ``report`` — assemble ``report.md`` + ``run_config.json`` for the experiment/dataset/split.
  - ``ablate`` / ``stress`` — controlled ablations and degraded-evidence stress tests.

Everything is written under ``{output_root}/{experiment_id}/{dataset}/{split}/``. Sampling
(``--limit`` / ``--video-limit`` / ``--video-id`` / ``--question-id`` / ``--sample-seed`` /
``--stratify-by``) is deterministic, so passing the same flags to ``build``, ``qa``, ``eval`` and
``report`` selects the same questions/videos for a coherent run.
"""

from __future__ import annotations

import argparse
import json
import random
import sys
import time
from collections import defaultdict
from pathlib import Path

from viwikigraph.config import AppConfig, DatasetConfig, config_hash, load_config
from viwikigraph.datasets.adapters import KnowITAdapter, NextQAAdapter, TVQAAdapter
from viwikigraph.qa.evaluation import evaluate_predictions
from viwikigraph.core.io import ensure_dir, read_jsonl, write_json, write_jsonl
from viwikigraph.knowledge.corpus import build_knowledge_corpus, load_corpus, save_corpus
from viwikigraph.llm.client import LLMClient, resolve_model
from viwikigraph.knowledge.refinement import refine_after_qa
from viwikigraph.pipeline import build_video_package, package_root
from viwikigraph.qa.answering import answer_question
from viwikigraph.qa.reporting import collect_package_stats, write_report
from viwikigraph.retrieval.index import (
    RetrievalIndex,
    build_retrieval_index,
    retrieve_evidence,
    route_query,
)
from viwikigraph.core.schemas import (
    CrossModalLink,
    KGItem,
    MediaItem,
    QAInstance,
    QAPrediction,
    ValidationResult,
    WikiSection,
)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="python -m viwikigraph")
    parser.add_argument("--config", default="configs/datasets.yaml")
    subparsers = parser.add_subparsers(dest="command", required=True)

    build = subparsers.add_parser("build", help="build per-video knowledge packages")
    _dataset_args(build)
    _experiment_arg(build)
    _sampling_args(build)
    _llm_args(build)
    build.add_argument("--dry-run", action="store_true")
    build.add_argument("--resume", action="store_true")
    build.add_argument("--use-vlm", action="store_true",
                       help="read video frames with a vision LLM for visual evidence (needs ffmpeg + a vision model)")
    build.add_argument("--frame-budget", type=int,
                       help="override budgets.Bframes for this build (useful for denser temporal coverage)")
    build.add_argument("--retry-failed-vision", action="store_true",
                       help="only rebuild sampled packages whose VLM manifest status is missing or not ok")
    build.add_argument(
        "--no-pre-storage-validation",
        action="store_true",
        help="ablation: persist generated wiki/KG/link items without running the pre-storage validation stage",
    )

    index = subparsers.add_parser("index", help="rebuild retrieval indexes from existing packages")
    _dataset_args(index)
    _experiment_arg(index)
    _sampling_args(index)

    qa = subparsers.add_parser("qa", help="answer questions over the built packages")
    _dataset_args(qa)
    _experiment_arg(qa)
    _sampling_args(qa)
    _llm_args(qa)
    qa.add_argument("--mode", choices=["mcq", "open"], default="mcq")
    qa.add_argument("--scorer", choices=["choice", "logprob"], default="choice")
    qa.add_argument("--no-verify", action="store_true", help="disable conditional verification")
    qa.add_argument("--require-llm", action="store_true")
    qa.add_argument("--refine", action="store_true", help="evidence-gated write-back of validated wiki patches (eq. 40)")
    qa.add_argument("--refine-dry-run", action="store_true", help="compute patch decisions without writing back")
    qa.add_argument("--no-link-validation", action="store_true", help="ablation: skip link validation on patches")
    qa.add_argument(
        "--refresh-question-type",
        action="append",
        help=(
            "only recompute answers for this question type (e.g. TC) and preserve existing saved "
            "QA predictions for all other selected questions; can be repeated"
        ),
    )

    refine = subparsers.add_parser("refine", help="evidence-gated refinement over saved QA outputs (eq. 40)")
    _dataset_args(refine)
    _experiment_arg(refine)
    _sampling_args(refine)
    _llm_args(refine)
    refine.add_argument("--refine-dry-run", action="store_true")
    refine.add_argument("--no-link-validation", action="store_true")

    eval_cmd = subparsers.add_parser("eval", help="score predictions against gold labels")
    _dataset_args(eval_cmd)
    _experiment_arg(eval_cmd)
    _sampling_args(eval_cmd)

    report = subparsers.add_parser("report", help="assemble report.md + run_config.json")
    _dataset_args(report)
    _experiment_arg(report)
    _sampling_args(report)

    ablate = subparsers.add_parser("ablate", help="ablation study over a built experiment")
    _dataset_args(ablate)
    _experiment_arg(ablate)
    _sampling_args(ablate)
    _llm_args(ablate)
    ablate.add_argument("--variant", required=True)
    ablate.add_argument("--output-name", help="output directory name; defaults to the ablation variant")
    ablate.add_argument("--mode", choices=["mcq", "open"], default="mcq")
    ablate.add_argument("--scorer", choices=["choice", "logprob"], default="choice")
    ablate.add_argument("--no-verify", action="store_true", help="disable conditional verification")
    ablate.add_argument("--require-llm", action="store_true")

    stress = subparsers.add_parser("stress", help="degraded-evidence stress test")
    _dataset_args(stress)
    _experiment_arg(stress)
    _sampling_args(stress)
    stress.add_argument("--setting", required=True)
    stress.add_argument("--level", type=float, required=True)
    stress.add_argument("--stress-seed", type=int, default=7)

    args = parser.parse_args(argv)
    config = load_config(args.config)
    dispatch = {
        "build": command_build,
        "index": command_index,
        "qa": command_qa,
        "refine": command_refine,
        "eval": command_eval,
        "report": command_report,
        "ablate": command_ablate,
        "stress": command_stress,
    }
    handler = dispatch.get(args.command)
    return handler(config, args) if handler else 2


# --------------------------------------------------------------------------------------------- #
# Commands
# --------------------------------------------------------------------------------------------- #
class _BuildProgress:
    """Live per-stage build progress for one video, streamed to stderr (callable as ``on_stage``).

    Prints a single growing line ``[i/N] <video_id>  ingest=8.1s narrative=3.2s … done=18.0s`` so a
    long, otherwise-silent ``build`` (especially ``--use-vlm``, which makes ~4 sequential model calls
    plus ffmpeg per video) shows it is making progress. A ``resume`` skip prints ``skipped (cached)``
    instead. Progress goes to stderr to keep the stdout ``built_packages=`` result line clean.
    """

    def __init__(self, index: int, total: int, video_id: str):
        self.start = self.last = time.perf_counter()
        self.skipped = False
        print(f"[{index:>{len(str(total))}}/{total}] {video_id}  ", end="", flush=True, file=sys.stderr)

    def __call__(self, stage: str) -> None:
        now = time.perf_counter()
        if stage == "skipped":
            self.skipped = True
            print("skipped (cached)", file=sys.stderr)
        else:
            print(f"{stage}={now - self.last:.1f}s ", end="", flush=True, file=sys.stderr)
            self.last = now

    def finish(self) -> None:
        if not self.skipped:
            print(f"done={time.perf_counter() - self.start:.1f}s", file=sys.stderr)


class _QAProgress:
    """Live per-question QA progress, streamed to stderr while keeping stdout machine-readable."""

    def __init__(self, index: int, total: int, qa: QAInstance):
        self.start = self.last = time.perf_counter()
        print(
            f"[{index:>{len(str(total))}}/{total}] {qa.question_id} video={qa.video_id}  ",
            end="",
            flush=True,
            file=sys.stderr,
        )

    def __call__(self, stage: str) -> None:
        now = time.perf_counter()
        print(f"{stage}={now - self.last:.1f}s ", end="", flush=True, file=sys.stderr)
        self.last = now

    def finish(self, prediction: QAPrediction, *, missing_package: bool = False) -> None:
        missing = "missing_package=1 " if missing_package else ""
        print(
            f"{missing}method={prediction.scoring_method} done={time.perf_counter() - self.start:.1f}s",
            file=sys.stderr,
        )


def command_build(config: AppConfig, args: argparse.Namespace) -> int:
    dataset = config.datasets[args.dataset]
    adapter = make_adapter(dataset)
    sampled = _select_qas(list(adapter.iter_qa_instances(args.split)), args)
    target_videos = {qa.video_id for qa in sampled}
    qas_by_video = _qas_by_video(sampled)
    llm = _make_llm(config, args)
    budgets = _effective_build_budgets(config, args)

    all_targets = [
        record for record in adapter.iter_video_records(args.split)
        if not target_videos or record.video_id in target_videos
    ]
    targets = [
        record for record in all_targets
        if not getattr(args, "retry_failed_vision", False) or _vision_retry_needed(dataset, args, record.video_id)
    ]
    total = len(targets)
    built = skipped = 0
    rebuilt_videos: set[str] = set()
    skipped_videos: set[str] = set()
    vision_failed: list[str] = []
    started = time.perf_counter()
    for index, record in enumerate(targets, 1):
        progress = _BuildProgress(index, total, record.video_id)
        build_video_package(
            record=record,
            qa_instances=qas_by_video.get(record.video_id, []),
            output_root=dataset.output_root,
            budgets=budgets,
            experiment_id=args.experiment_id,
            llm=llm,
            dry_run=args.dry_run,
            resume=args.resume,
            use_vlm=getattr(args, "use_vlm", False),
            validate_before_storage=not getattr(args, "no_pre_storage_validation", False),
            raw_config=config.raw,
            on_stage=progress,
        )
        progress.finish()
        if progress.skipped:
            skipped += 1
            skipped_videos.add(record.video_id)
        else:
            built += 1
            rebuilt_videos.add(record.video_id)
            # A VLM build that sampled frames but extracted little/no visual evidence should be visible:
            # empty/error/no_frames are blind packages, while partial packages may need retrying.
            if record.metadata.get("vision_status") in ("empty", "error", "no_frames", "partial"):
                vision_failed.append(record.video_id)
    health = None
    if getattr(args, "use_vlm", False) or getattr(args, "retry_failed_vision", False):
        health = _write_vision_health(dataset, args, all_targets, rebuilt_videos, skipped_videos)
        vision_failed = [row["video_id"] for row in health["records"] if row.get("vision_status") != "ok"]
    vlm = " vlm=on" if getattr(args, "use_vlm", False) and llm else ""
    skip_note = f" skipped={skipped}" if skipped else ""
    retry_note = " retry_failed_vision=on" if getattr(args, "retry_failed_vision", False) else ""
    elapsed = time.perf_counter() - started
    _write_build_manifest(
        dataset,
        args,
        budgets,
        all_targets,
        rebuilt_videos,
        skipped_videos,
        built=built,
        skipped=skipped,
        elapsed=elapsed,
        vision_health=health,
    )
    if vision_failed:
        sample = ", ".join(vision_failed[:5]) + (" …" if len(vision_failed) > 5 else "")
        print(
            f"WARNING: {len(vision_failed)}/{len(all_targets)} sampled VLM packages have non-ok vision_status "
            f"(vision_status partial/empty/error/no_frames) — these may have weak or missing visual evidence. "
            f"Affected: {sample}",
            file=sys.stderr,
        )
    print(f"built_packages={built}{skip_note}{retry_note} experiment={args.experiment_id} "
          f"llm={'on' if llm else 'off'}{vlm} elapsed={elapsed:.1f}s")
    return 0


def command_index(config: AppConfig, args: argparse.Namespace) -> int:
    dataset = config.datasets[args.dataset]
    adapter = make_adapter(dataset)
    sampled = _select_qas(list(adapter.iter_qa_instances(args.split)), args)
    target_videos = {qa.video_id for qa in sampled}
    count = 0
    for video_id in target_videos:
        root = package_root(dataset.output_root, args.experiment_id, dataset.name, args.split, video_id)
        index = _load_index_from_package(root)
        if index is None:
            continue
        write_json(root / "index" / "retrieval_index.json", index.to_dict())
        count += 1
    print(f"indexed_packages={count}")
    return 0


def command_qa(config: AppConfig, args: argparse.Namespace) -> int:
    dataset = config.datasets[args.dataset]
    adapter = make_adapter(dataset)
    qas = _select_qas(list(adapter.iter_qa_instances(args.split)), args)
    llm = _make_llm(config, args)
    corpus = _knowledge_corpus(dataset, adapter, args)
    budgets = config.budgets

    qa_dir = ensure_dir(_split_dir(dataset, args) / "qa")
    refresh_types = {str(item).upper() for item in (getattr(args, "refresh_question_type", None) or [])}
    saved_predictions = {
        row.get("question_id"): row for row in _read_optional(qa_dir / "predictions.jsonl")
    } if refresh_types else {}
    saved_packets = {
        row.get("question_id"): row for row in _read_optional(qa_dir / "evidence_packets.jsonl")
    } if refresh_types else {}
    saved_traces = {
        row.get("question_id"): row for row in _read_optional(qa_dir / "traces.jsonl")
    } if refresh_types else {}
    packets, predictions, traces, refinements = [], [], [], []
    missing_packages = reused_predictions = refreshed_predictions = 0
    total = len(qas)
    for qa_index, qa in enumerate(qas, 1):
        progress = _QAProgress(qa_index, total, qa)
        if refresh_types and _qa_question_type(qa) not in refresh_types and qa.question_id in saved_predictions:
            prediction = QAPrediction.from_dict(saved_predictions[qa.question_id])
            packets.append(saved_packets.get(qa.question_id, {
                "question_id": qa.question_id,
                "video_id": qa.video_id,
                "narrative_sections": [],
                "kg_items": [],
                "media_items": [],
                "subtitle_spans": [],
                "cross_modal_links": [],
                "knowledge": [],
            }))
            predictions.append(prediction)
            traces.append(saved_traces.get(qa.question_id, {
                "question_id": qa.question_id,
                "trace": prediction.evidence_trace,
            }))
            reused_predictions += 1
            progress("cached")
            progress.finish(prediction)
            continue

        root = package_root(dataset.output_root, args.experiment_id, dataset.name, args.split, qa.video_id)
        retrieval_index = _load_index_from_package(root)
        missing_package = retrieval_index is None
        if retrieval_index is None:
            missing_packages += 1
            retrieval_index = build_retrieval_index([], [], [])
        need = route_query(qa.question, qa.options, llm)
        packet = retrieve_evidence(qa, retrieval_index, budgets, need=need, knowledge=corpus)
        progress("retrieve")
        prediction = answer_question(
            qa,
            packet,
            llm=llm,
            mode=args.mode,
            scorer=args.scorer,
            verify=not args.no_verify,
            require_llm=args.require_llm,
        )
        progress("answer")
        packets.append(packet)
        predictions.append(prediction)
        traces.append({"question_id": qa.question_id, "trace": prediction.evidence_trace})
        refreshed_predictions += 1

        if getattr(args, "refine", False):
            result = refine_after_qa(
                qa,
                packet,
                prediction,
                root,
                llm=llm,
                dry_run=getattr(args, "refine_dry_run", False),
                validate_links=not getattr(args, "no_link_validation", False),
            )
            refinements.append(result)
            progress("refine")
        progress.finish(prediction, missing_package=missing_package)

    write_jsonl(qa_dir / "evidence_packets.jsonl", packets)
    write_jsonl(qa_dir / "predictions.jsonl", predictions)
    write_jsonl(qa_dir / "traces.jsonl", traces)
    _write_qa_run_manifest(qa_dir, dataset, args, qas, llm=llm)
    note = f" missing_packages={missing_packages}" if missing_packages else ""
    if refresh_types:
        note += f" refreshed={refreshed_predictions} reused={reused_predictions}"
    if getattr(args, "refine", False):
        write_jsonl(qa_dir / "refinement.jsonl", refinements)
        applied = sum(r.applied for r in refinements)
        note += f" patches_applied={applied}"
    print(f"qa_predictions={len(predictions)} experiment={args.experiment_id}{note}")
    return 0


def command_refine(config: AppConfig, args: argparse.Namespace) -> int:
    """Evidence-gated refinement over already-saved QA outputs (eq. 40), decoupled from answering.

    Reconstructs each question's packet + prediction from ``qa/evidence_packets.jsonl`` and
    ``qa/predictions.jsonl`` and runs :func:`refine_after_qa` — so refinement is fully optional and
    can be re-run without re-querying the model."""
    dataset = config.datasets[args.dataset]
    adapter = make_adapter(dataset)
    qas = {qa.question_id: qa for qa in _select_qas(list(adapter.iter_qa_instances(args.split)), args)}
    llm = _make_llm(config, args)
    qa_dir = _split_dir(dataset, args) / "qa"

    from viwikigraph.core.schemas import EvidencePacket

    packets = {EvidencePacket.from_dict(r).question_id: EvidencePacket.from_dict(r)
               for r in _read_optional(qa_dir / "evidence_packets.jsonl")}
    predictions = {p["question_id"]: QAPrediction.from_dict(p)
                   for p in _read_optional(qa_dir / "predictions.jsonl")}

    refinements = []
    for question_id, prediction in predictions.items():
        qa = qas.get(question_id)
        packet = packets.get(question_id)
        if qa is None or packet is None:
            continue
        root = package_root(dataset.output_root, args.experiment_id, dataset.name, args.split, qa.video_id)
        refinements.append(
            refine_after_qa(
                qa, packet, prediction, root, llm=llm,
                dry_run=args.refine_dry_run, validate_links=not args.no_link_validation,
            )
        )
    write_jsonl(ensure_dir(qa_dir) / "refinement.jsonl", refinements)
    applied = sum(r.applied for r in refinements)
    print(f"refined_questions={len(refinements)} patches_applied={applied} experiment={args.experiment_id}")
    return 0


def command_eval(config: AppConfig, args: argparse.Namespace) -> int:
    dataset = config.datasets[args.dataset]
    adapter = make_adapter(dataset)
    split_dir = _split_dir(dataset, args)
    predictions = [QAPrediction.from_dict(row) for row in read_jsonl(split_dir / "qa" / "predictions.jsonl")]
    qas, _ = _qas_for_saved_predictions(dataset, adapter, args, predictions)
    metrics, rows = evaluate_predictions(qas, predictions)
    eval_dir = ensure_dir(split_dir / "eval")
    write_json(eval_dir / "metrics.json", metrics)
    write_jsonl(eval_dir / "per_question.jsonl", rows)
    print(json.dumps(metrics, sort_keys=True))
    return 0


def command_report(config: AppConfig, args: argparse.Namespace) -> int:
    dataset = config.datasets[args.dataset]
    adapter = make_adapter(dataset)
    split_dir = _split_dir(dataset, args)
    predictions = [QAPrediction.from_dict(row) for row in read_jsonl(split_dir / "qa" / "predictions.jsonl")]
    qas, sampling = _qas_for_saved_predictions(dataset, adapter, args, predictions)

    video_ids = list(dict.fromkeys(qa.video_id for qa in qas))
    sections, kg_items, validations, media_paths = _aggregate_packages(dataset, args, video_ids)
    link_validations = [v for v in validations if v.item_type == "cross_modal_link"]
    stats = collect_package_stats(
        sections,
        kg_items,
        validations,
        media_paths=media_paths,
        num_links=len(link_validations),
        link_validations=link_validations,
        video_count=sum(1 for vid in video_ids if _package_exists(dataset, args, vid)),
    )
    refine_rows = _read_optional(_split_dir(dataset, args) / "qa" / "refinement.jsonl")
    if refine_rows:
        stats.extra["refinement"] = {
            "proposed": sum(len(r.get("patches", [])) for r in refine_rows),
            "accepted": sum(1 for r in refine_rows for p in r.get("patches", []) if p.get("accepted")),
            "applied": sum(int(r.get("applied", 0)) for r in refine_rows),
        }
    report_path = write_report(
        split_dir,
        experiment_id=args.experiment_id,
        dataset=dataset.name,
        split=args.split,
        model=_report_model(dataset, args, predictions, video_ids),
        sample_info={
            "limit": sampling.get("limit"),
            "sample_seed": sampling.get("sample_seed"),
            "stratify_by": sampling.get("stratify_by"),
            "budgets": _report_budgets(config, dataset, args, video_ids),
            "config": args.config,
            "config_hash": config_hash(config.raw),
        },
        qas=qas,
        predictions=predictions,
        validations=validations,
        package_stats=stats,
    )
    print(f"report={report_path}")
    return 0


def command_ablate(config: AppConfig, args: argparse.Namespace) -> int:
    dataset = config.datasets[args.dataset]
    adapter = make_adapter(dataset)
    qas = list(adapter.iter_qa_instances(args.split))
    llm = _make_llm(config, args)
    # Ablations must be paired with the baseline experiment.  The annotation file may
    # contain more questions than were used by the saved run (for example, after a
    # sampled/partial build), so reuse the baseline prediction IDs and ordering.
    split_dir = _split_dir(dataset, args)
    baseline_rows = _read_optional(split_dir / "qa" / "predictions.jsonl")
    if baseline_rows:
        qa_by_id = {qa.question_id: qa for qa in qas}
        qas = [
            qa_by_id[row["question_id"]]
            for row in baseline_rows
            if row.get("question_id") in qa_by_id
        ]
    # Apply sampling only after pairing to the saved baseline IDs. This guarantees that a
    # `--limit 200` model comparison is drawn from the exact baseline run rather than from the
    # complete annotation file and then accidentally reduced to its intersection.
    qas = _select_qas(qas, args)
    out_dir = ensure_dir(split_dir / "ablations" / (args.output_name or args.variant))
    predictions, packets, traces, latency_rows = [], [], [], []
    total = len(qas)
    for qa_index, qa in enumerate(qas, 1):
        progress = _QAProgress(qa_index, total, qa)
        started = time.perf_counter()
        root = package_root(dataset.output_root, args.experiment_id, dataset.name, args.split, qa.video_id)
        base = _load_index_from_package(root) or build_retrieval_index([], [], [])
        index = _ablate_index(base, args.variant)
        need = route_query(qa.question, qa.options, llm)
        packet = retrieve_evidence(qa, index, config.budgets, need=need)
        progress("retrieve")
        prediction = answer_question(
            qa,
            packet,
            llm=llm,
            mode=args.mode,
            scorer=args.scorer,
            verify=not args.no_verify,
            require_llm=args.require_llm,
        )
        progress("answer")
        predictions.append(prediction)
        packets.append(packet)
        traces.append({"question_id": qa.question_id, "trace": prediction.evidence_trace})
        latency_rows.append(
            {
                "processing_stage": "ablation_retrieval_and_qa",
                "dataset": dataset.name,
                "video_id": qa.video_id,
                "question_id": qa.question_id,
                "variant": args.variant,
                "wall_clock_seconds": time.perf_counter() - started,
                "success": True,
            }
        )
        progress.finish(prediction)
    write_jsonl(out_dir / "predictions.jsonl", predictions)
    write_jsonl(out_dir / "evidence_packets.jsonl", packets)
    write_jsonl(out_dir / "traces.jsonl", traces)
    write_jsonl(out_dir / "latency.jsonl", latency_rows)
    metrics, rows = evaluate_predictions(qas, predictions)
    write_json(out_dir / "metrics.json", metrics)
    write_jsonl(out_dir / "per_question.jsonl", rows)
    _write_qa_run_manifest(out_dir, dataset, args, qas, llm=llm)
    write_json(
        out_dir / "ablation_manifest.json",
        {
            "baseline_experiment_id": args.experiment_id,
            "baseline_metrics_path": str(split_dir / "eval" / "metrics.json"),
            "variant": args.variant,
            "dataset": dataset.name,
            "split": args.split,
            "question_count": len(qas),
            "question_ids": [qa.question_id for qa in qas],
            "model": getattr(llm, "model", None) if llm is not None else "deterministic",
            "use_llm": llm is not None,
            "mode": args.mode,
            "scorer": args.scorer,
            "verify": not args.no_verify,
            "budgets": dict(config.budgets),
            "metrics": metrics,
        },
    )
    print(f"ablation_predictions={len(predictions)} variant={args.variant}")
    return 0


def command_stress(config: AppConfig, args: argparse.Namespace) -> int:
    rng = random.Random(args.stress_seed)
    dataset = config.datasets[args.dataset]
    adapter = make_adapter(dataset)
    qas = _select_qas(list(adapter.iter_qa_instances(args.split)), args)
    out_dir = ensure_dir(_split_dir(dataset, args) / "stress" / args.setting / str(args.level))
    predictions = []
    for qa in qas:
        root = package_root(dataset.output_root, args.experiment_id, dataset.name, args.split, qa.video_id)
        base = _load_index_from_package(root) or build_retrieval_index([], [], [])
        index = _stress_index(base, args.setting, args.level, rng)
        packet = retrieve_evidence(qa, index, config.budgets)
        predictions.append(answer_question(qa, packet))
    write_jsonl(out_dir / "predictions.jsonl", predictions)
    metrics, rows = evaluate_predictions(qas, predictions)
    write_json(out_dir / "metrics.json", metrics)
    write_jsonl(out_dir / "per_question.jsonl", rows)
    print(f"stress_predictions={len(predictions)} setting={args.setting} level={args.level}")
    return 0


# --------------------------------------------------------------------------------------------- #
# Adapters / LLM / knowledge corpus
# --------------------------------------------------------------------------------------------- #
def make_adapter(dataset: DatasetConfig):
    if dataset.name == "tvqa":
        if dataset.subtitles_path is None:
            raise ValueError("tvqa requires subtitles_path")
        return TVQAAdapter(dataset.annotations, dataset.subtitles_path, dataset.visual_concepts_path, dataset.video_root)
    if dataset.name == "knowit":
        return KnowITAdapter(dataset.annotations, dataset.video_root)
    if dataset.name == "nextqa":
        return NextQAAdapter(
            dataset.annotations,
            dataset.vidor_map_path,
            dataset.video_root,
            dataset.captions_path,
            dataset.visual_concepts_path,
        )
    raise ValueError(f"Unsupported dataset: {dataset.name}")


def _make_llm(config: AppConfig, args: argparse.Namespace) -> LLMClient | None:
    if getattr(args, "no_llm", False):
        return None
    local_model_path = getattr(args, "local_model_path", None)
    if local_model_path:
        from viwikigraph.llm.local_llama import LocalLlamaClient

        return LocalLlamaClient(
            model_path=local_model_path,
            cache_dir=getattr(args, "local_cache_dir", None),
            max_new_tokens=getattr(args, "local_max_new_tokens", 512),
        )
    # --use-vlm needs the LLM even if --use-llm was not passed (vision IS the LLM call).
    if getattr(args, "use_llm", False) or getattr(args, "require_llm", False) or getattr(args, "use_vlm", False):
        return LLMClient(**config.llm)
    return None


def _knowledge_corpus(dataset: DatasetConfig, adapter, args: argparse.Namespace):
    """KnowIT external-knowledge corpus, built once from the TRAIN split (leakage-safe) and cached."""
    if dataset.name != "knowit":
        return None
    path = _experiment_dataset_dir(dataset, args) / "knowledge_corpus.jsonl"
    if path.exists():
        return load_corpus(path, "knowit")
    corpus = build_knowledge_corpus(adapter, split="train")
    save_corpus(corpus, path)
    return corpus


# --------------------------------------------------------------------------------------------- #
# Argument groups
# --------------------------------------------------------------------------------------------- #
def _dataset_args(parser: argparse.ArgumentParser) -> None:
    # NExT-QA is the v1 primary dataset; TVQA is secondary; KnowIT is retained for schema-transfer.
    parser.add_argument("--dataset", default="nextqa", choices=["nextqa", "tvqa", "knowit"])
    parser.add_argument("--split", required=True)


def _experiment_arg(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--experiment-id", required=True, help="experiment id → outputs/{id}/{dataset}/{split}/")


def _sampling_args(parser: argparse.ArgumentParser) -> None:
    sample_size = parser.add_mutually_exclusive_group()
    sample_size.add_argument("--limit", type=int, help="sample N questions (omit for the full split)")
    sample_size.add_argument("--video-limit", type=int, help="sample N unique videos and include all of their questions")
    parser.add_argument(
        "--video-id",
        action="append",
        help="restrict to one video id; repeat the flag for multiple videos",
    )
    parser.add_argument(
        "--question-id",
        action="append",
        help="restrict to one full question id such as 9213637099_0; repeat the flag for multiple questions",
    )
    parser.add_argument("--sample-seed", type=int, default=13)
    parser.add_argument("--stratify-by", help="QA metadata key to stratify the sample by (e.g. question_type)")


def _llm_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--use-llm", action="store_true", help="use the configured LLM for generation/QA")
    parser.add_argument("--no-llm", action="store_true", help="force the deterministic offline path")
    parser.add_argument("--local-model-path", help="run a local Hugging Face causal LM instead of the configured API")
    parser.add_argument("--local-cache-dir", help="cache directory for local-model completions")
    parser.add_argument("--local-max-new-tokens", type=int, default=512)


# --------------------------------------------------------------------------------------------- #
# Paths / sampling / package loading
# --------------------------------------------------------------------------------------------- #
def _experiment_dataset_dir(dataset: DatasetConfig, args: argparse.Namespace) -> Path:
    return Path(dataset.output_root) / args.experiment_id / dataset.name


def _split_dir(dataset: DatasetConfig, args: argparse.Namespace) -> Path:
    return _experiment_dataset_dir(dataset, args) / args.split


def _qas_by_video(qas: list[QAInstance]) -> dict[str, list[QAInstance]]:
    grouped: dict[str, list[QAInstance]] = defaultdict(list)
    for qa in qas:
        grouped[qa.video_id].append(qa)
    return grouped


def _effective_build_budgets(config: AppConfig, args: argparse.Namespace) -> dict[str, int]:
    budgets = dict(config.budgets)
    frame_budget = getattr(args, "frame_budget", None)
    if frame_budget is not None:
        if frame_budget <= 0:
            raise ValueError("--frame-budget must be a positive integer")
        budgets["Bframes"] = int(frame_budget)
    return budgets


def _select_qas(qas: list[QAInstance], args: argparse.Namespace) -> list[QAInstance]:
    """Deterministically sample questions or complete video groups for a reproducible run."""
    video_ids = {str(video_id) for video_id in (getattr(args, "video_id", None) or [])}
    question_ids = {str(question_id) for question_id in (getattr(args, "question_id", None) or [])}
    if video_ids:
        qas = [qa for qa in qas if qa.video_id in video_ids]
    if question_ids:
        qas = [qa for qa in qas if qa.question_id in question_ids]

    limit = getattr(args, "limit", None)
    video_limit = getattr(args, "video_limit", None)
    seed = getattr(args, "sample_seed", 13)
    if not limit or limit <= 0 or limit >= len(qas):
        if not video_limit or video_limit <= 0:
            return qas

        if getattr(args, "stratify_by", None):
            raise ValueError("--stratify-by cannot be used with --video-limit")
        video_ids = list(dict.fromkeys(qa.video_id for qa in qas))
        if video_limit >= len(video_ids):
            return qas
        rng = random.Random(seed)
        selected_video_ids = {video_ids[index] for index in rng.sample(range(len(video_ids)), video_limit)}
        return [qa for qa in qas if qa.video_id in selected_video_ids]

    stratify_by = getattr(args, "stratify_by", None)
    order = {id(qa): i for i, qa in enumerate(qas)}

    if stratify_by:
        groups: dict[str, list[QAInstance]] = defaultdict(list)
        for qa in qas:
            groups[str(qa.metadata.get(stratify_by, ""))].append(qa)
        selected: list[QAInstance] = []
        for key in sorted(groups):
            items = groups[key]
            quota = max(1, round(limit * len(items) / len(qas)))
            rng = random.Random(f"{seed}:{key}")
            picks = sorted(rng.sample(range(len(items)), min(quota, len(items))))
            selected.extend(items[i] for i in picks)
        selected.sort(key=lambda qa: order[id(qa)])
        return selected[:limit]

    rng = random.Random(seed)
    picks = sorted(rng.sample(range(len(qas)), limit))
    return [qas[i] for i in picks]


def _sampling_from_args(args: argparse.Namespace) -> dict:
    sampling = {
        "limit": getattr(args, "limit", None),
        "sample_seed": getattr(args, "sample_seed", None),
        "stratify_by": getattr(args, "stratify_by", None),
    }
    video_limit = getattr(args, "video_limit", None)
    if video_limit is not None:
        sampling["video_limit"] = video_limit
    video_id = getattr(args, "video_id", None)
    if video_id:
        sampling["video_id"] = list(video_id)
    question_id = getattr(args, "question_id", None)
    if question_id:
        sampling["question_id"] = list(question_id)
    return sampling


def _write_qa_run_manifest(
    qa_dir: Path,
    dataset: DatasetConfig,
    args: argparse.Namespace,
    qas: list[QAInstance],
    *,
    llm: LLMClient | None = None,
) -> None:
    """Persist the exact QA selection so eval/report cannot drift to a different sample."""
    model = getattr(llm, "model", None) if llm is not None else None
    write_json(
        qa_dir / "run_manifest.json",
        {
            "dataset": dataset.name,
            "split": args.split,
            "experiment_id": args.experiment_id,
            "model": model or "deterministic",
            "use_llm": llm is not None,
            "qa": {
                "mode": getattr(args, "mode", None),
                "scorer": getattr(args, "scorer", None),
                "verify": not getattr(args, "no_verify", False),
                "refine": bool(getattr(args, "refine", False)),
                "refresh_question_type": list(getattr(args, "refresh_question_type", None) or []),
            },
            "question_count": len(qas),
            "question_ids": [qa.question_id for qa in qas],
            "video_ids": list(dict.fromkeys(qa.video_id for qa in qas)),
            "sampling": _sampling_from_args(args),
        },
    )


def _qa_question_type(qa: QAInstance) -> str:
    for key in ("question_type", "QType", "qtype", "kg_type", "type"):
        value = (qa.metadata or {}).get(key)
        if value not in (None, ""):
            return str(value).upper()
    return "UNK"


def _qas_for_saved_predictions(
    dataset: DatasetConfig,
    adapter,
    args: argparse.Namespace,
    predictions: list[QAPrediction],
) -> tuple[list[QAInstance], dict]:
    """Return the gold QA rows that match saved predictions.

    The QA command owns the selected question set. Eval/report must reuse that set instead of
    independently interpreting today's CLI flags, or a later command can accidentally score a 20-row
    prediction file against the full split. For older runs that predate ``qa/run_manifest.json``, infer
    the selection from the prediction IDs when the current sampling flags do not match them.
    """
    all_qas = list(adapter.iter_qa_instances(args.split))
    manifest = _read_qa_run_manifest(_split_dir(dataset, args))
    if manifest is not None:
        sampling = dict(manifest.get("sampling") or _sampling_from_args(args))
        return _qas_by_question_ids(all_qas, list(manifest.get("question_ids") or [])), sampling

    selected = _select_qas(all_qas, args)
    predicted_ids = [prediction.question_id for prediction in predictions]
    if not predicted_ids:
        return selected, _sampling_from_args(args)

    selected_ids = {qa.question_id for qa in selected}
    predicted_id_set = set(predicted_ids)
    if selected_ids == predicted_id_set:
        return selected, _sampling_from_args(args)

    # Legacy compatibility: old runs have predictions but no selection manifest. Score exactly the
    # prediction rows rather than silently counting every unpredicted split row as unanswered.
    inferred = _qas_by_question_ids(all_qas, predicted_ids)
    print(
        "WARNING: qa/run_manifest.json missing or sampling flags do not match saved predictions; "
        f"evaluating {len(inferred)} predicted question ids only.",
        file=sys.stderr,
    )
    sampling = _sampling_from_args(args)
    if sampling.get("limit") in (None, ""):
        sampling["limit"] = len(inferred)
    return inferred, sampling


def _read_qa_run_manifest(split_dir: Path) -> dict | None:
    path = split_dir / "qa" / "run_manifest.json"
    if not path.exists():
        return None
    return json.loads(path.read_text(encoding="utf-8"))


def _qas_by_question_ids(all_qas: list[QAInstance], question_ids: list[str]) -> list[QAInstance]:
    by_id = {qa.question_id: qa for qa in all_qas}
    missing = [question_id for question_id in question_ids if question_id not in by_id]
    if missing:
        sample = ", ".join(missing[:5]) + (" ..." if len(missing) > 5 else "")
        raise ValueError(f"Saved QA selection references unknown question_id(s): {sample}")
    return [by_id[question_id] for question_id in question_ids]


def _package_exists(dataset: DatasetConfig, args: argparse.Namespace, video_id: str) -> bool:
    root = package_root(dataset.output_root, args.experiment_id, dataset.name, args.split, video_id)
    return (root / "manifest.json").exists()


def _vision_retry_needed(dataset: DatasetConfig, args: argparse.Namespace, video_id: str) -> bool:
    manifest = _package_manifest(dataset, args, video_id)
    if manifest is None:
        return True
    return manifest.get("vision_status") != "ok"


def _write_vision_health(
    dataset: DatasetConfig,
    args: argparse.Namespace,
    records: list,
    rebuilt_videos: set[str],
    skipped_videos: set[str],
) -> dict:
    rows = [
        _vision_health_row(dataset, args, record.video_id, rebuilt_videos, skipped_videos)
        for record in records
    ]
    summary = {
        "total": len(rows),
        "ok": sum(1 for row in rows if row.get("vision_status") == "ok"),
        "failed": sum(1 for row in rows if row.get("vision_status") != "ok"),
        "rebuilt": sum(1 for row in rows if row.get("rebuilt")),
        "skipped": sum(1 for row in rows if row.get("skipped")),
    }
    payload = {
        "experiment_id": args.experiment_id,
        "dataset": dataset.name,
        "split": args.split,
        "sampling": _sampling_from_args(args),
        "summary": summary,
        "records": rows,
    }
    write_json(_split_dir(dataset, args) / "vision_health.json", payload)
    return payload


def _write_build_manifest(
    dataset: DatasetConfig,
    args: argparse.Namespace,
    budgets: dict[str, int],
    records: list,
    rebuilt_videos: set[str],
    skipped_videos: set[str],
    *,
    built: int,
    skipped: int,
    elapsed: float,
    vision_health: dict | None = None,
) -> None:
    payload = {
        "experiment_id": args.experiment_id,
        "dataset": dataset.name,
        "split": args.split,
        "sampling": _sampling_from_args(args),
        "budgets": dict(budgets),
        "use_vlm": bool(getattr(args, "use_vlm", False)),
        "pre_storage_validation": not bool(getattr(args, "no_pre_storage_validation", False)),
        "retry_failed_vision": bool(getattr(args, "retry_failed_vision", False)),
        "built": built,
        "skipped": skipped,
        "elapsed_seconds": elapsed,
        "video_ids": [record.video_id for record in records],
        "rebuilt_video_ids": sorted(rebuilt_videos),
        "skipped_video_ids": sorted(skipped_videos),
    }
    if vision_health is not None:
        payload["vision_summary"] = dict(vision_health.get("summary", {}))
    write_json(_split_dir(dataset, args) / "build_manifest.json", payload)


def _report_budgets(
    config: AppConfig,
    dataset: DatasetConfig,
    args: argparse.Namespace,
    video_ids: list[str],
) -> dict[str, int]:
    budgets = dict(config.budgets)
    build_manifest = _read_build_manifest(_split_dir(dataset, args))
    manifest_budgets = build_manifest.get("budgets") if build_manifest else None
    if isinstance(manifest_budgets, dict):
        budgets.update({str(key): int(value) for key, value in manifest_budgets.items()})
        return budgets
    _overlay_vision_frame_budget_from_health(budgets, dataset, args, video_ids)
    return budgets


def _read_build_manifest(split_dir: Path) -> dict | None:
    path = split_dir / "build_manifest.json"
    if not path.exists():
        return None
    return json.loads(path.read_text(encoding="utf-8"))


def _report_model(
    dataset: DatasetConfig,
    args: argparse.Namespace,
    predictions: list[QAPrediction],
    video_ids: list[str],
) -> str:
    if getattr(args, "use_llm", False):
        return resolve_model()
    manifest = _read_qa_run_manifest(_split_dir(dataset, args))
    if manifest is not None:
        model = str(manifest.get("model") or "")
        if model and model not in {"none", "deterministic"}:
            return model
    if any(_prediction_used_llm(prediction) for prediction in predictions):
        return _package_llm_model(dataset, args, video_ids) or resolve_model()
    return "deterministic"


def _prediction_used_llm(prediction: QAPrediction) -> bool:
    method = (prediction.scoring_method or "").lower()
    return method.startswith("llm_") or method.startswith("logprob")


def _package_llm_model(dataset: DatasetConfig, args: argparse.Namespace, video_ids: list[str]) -> str | None:
    for video_id in video_ids:
        manifest = _package_manifest(dataset, args, video_id)
        if not manifest:
            continue
        models = manifest.get("models")
        if not isinstance(models, dict):
            continue
        model = str(models.get("llm") or "")
        if model and model not in {"none", "deterministic"}:
            return model
    return None


def _overlay_vision_frame_budget_from_health(
    budgets: dict[str, int],
    dataset: DatasetConfig,
    args: argparse.Namespace,
    video_ids: list[str],
) -> None:
    path = _split_dir(dataset, args) / "vision_health.json"
    if not path.exists():
        return
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return
    selected = set(video_ids)
    sampled: list[int] = []
    for row in payload.get("records", []):
        if not isinstance(row, dict) or row.get("video_id") not in selected:
            continue
        frames = row.get("frames_sampled")
        if isinstance(frames, int) and frames > 0:
            sampled.append(frames)
    if sampled:
        budgets["Bframes"] = max(sampled)


def _vision_health_row(
    dataset: DatasetConfig,
    args: argparse.Namespace,
    video_id: str,
    rebuilt_videos: set[str],
    skipped_videos: set[str],
) -> dict:
    manifest = _package_manifest(dataset, args, video_id)
    package_exists = manifest is not None
    manifest = manifest or {}
    return {
        "video_id": video_id,
        "package_exists": package_exists,
        "vision_status": manifest.get("vision_status", "missing" if not package_exists else "unknown"),
        "frames_sampled": manifest.get("frames_sampled"),
        "frames_described": manifest.get("frames_described"),
        "vision_detail": manifest.get("vision_detail", ""),
        "rebuilt": video_id in rebuilt_videos,
        "skipped": video_id in skipped_videos,
    }


def _package_manifest(dataset: DatasetConfig, args: argparse.Namespace, video_id: str) -> dict | None:
    path = package_root(dataset.output_root, args.experiment_id, dataset.name, args.split, video_id) / "manifest.json"
    if not path.exists():
        return None
    return json.loads(path.read_text(encoding="utf-8"))


def _load_index_from_package(root: Path) -> RetrievalIndex | None:
    """Load a package's retrieval index, reconstructing from artifacts if the cached file is absent."""
    index_path = root / "index" / "retrieval_index.json"
    if index_path.exists():
        return RetrievalIndex.from_dict(json.loads(index_path.read_text(encoding="utf-8")))
    sections_path = root / "wiki" / "narrative_sections.jsonl"
    if not sections_path.exists():
        return None
    sections = [WikiSection.from_dict(row) for row in read_jsonl(sections_path)]
    kg_items = [KGItem.from_dict(row) for row in read_jsonl(root / "wiki" / "kg_items.jsonl")]
    media_path = root / "validation" / "media_links.jsonl"
    media_items = [MediaItem.from_dict(row) for row in read_jsonl(media_path)] if media_path.exists() else []
    links_path = root / "validation" / "cross_modal_links.jsonl"
    links = [CrossModalLink.from_dict(row) for row in read_jsonl(links_path)] if links_path.exists() else []
    return build_retrieval_index(sections, kg_items, media_items, cross_modal_links=links)


def _aggregate_packages(
    dataset: DatasetConfig,
    args: argparse.Namespace,
    video_ids: list[str],
) -> tuple[list[WikiSection], list[KGItem], list[ValidationResult], list[str]]:
    """Concatenate sections / KG items / validations / media paths across the sampled videos."""
    sections: list[WikiSection] = []
    kg_items: list[KGItem] = []
    validations: list[ValidationResult] = []
    media_paths: list[str] = []
    for video_id in video_ids:
        root = package_root(dataset.output_root, args.experiment_id, dataset.name, args.split, video_id)
        if not (root / "manifest.json").exists():
            continue
        sections.extend(WikiSection.from_dict(r) for r in _read_optional(root / "wiki" / "narrative_sections.jsonl"))
        kg_items.extend(KGItem.from_dict(r) for r in _read_optional(root / "wiki" / "kg_items.jsonl"))
        validations.extend(ValidationResult.from_dict(r) for r in _read_optional(root / "validation" / "claim_support.jsonl"))
        media_paths.extend(
            _local_package_media_path(root, str(r.get("path", "")))
            for r in _read_optional(root / "validation" / "media_links.jsonl")
        )
    return sections, kg_items, validations, [p for p in media_paths if p]


def _local_package_media_path(root: Path, raw: str) -> str:
    """Resolve a media path saved on another machine back to this package root when possible."""
    if not raw:
        return ""
    path = Path(raw)
    if path.exists():
        return str(path)
    parts = path.parts
    for idx, part in enumerate(parts):
        if part != "packages" or idx + 1 >= len(parts) or parts[idx + 1] != root.name:
            continue
        suffix = Path(*parts[idx + 2:]) if idx + 2 < len(parts) else Path()
        return str(root / suffix)
    if not path.is_absolute():
        return str(root / path)
    return raw


def _read_optional(path: Path) -> list[dict]:
    return read_jsonl(path) if path.exists() else []


# --------------------------------------------------------------------------------------------- #
# Ablation / stress index transforms (paper §V ablations + stress tests)
# --------------------------------------------------------------------------------------------- #
def _ablate_index(index: RetrievalIndex, variant: str) -> RetrievalIndex:
    links = index.cross_modal_links
    if variant == "full":
        return index
    if variant == "no_pre_storage_validation":
        # Validation results are deliberately not embedded in RetrievalIndex and the current
        # storage path does not filter items by validation decision. This explicit identity
        # transform permits a controlled QA check while the build-time version is produced with
        # `build --no-pre-storage-validation`.
        return index
    if variant == "no_narrative":
        return build_retrieval_index([], index.kg_items, index.media_items, index.evidence_units, links)
    if variant == "no_kg":
        return build_retrieval_index(index.narrative_sections, [], index.media_items, index.evidence_units, links)
    if variant == "no_media":
        return build_retrieval_index(index.narrative_sections, index.kg_items, [], index.evidence_units, links)
    if variant == "no_cross_modal_links":
        # Paper ablation "w/o cross-modal links": keep all items but drop the typed link set L.
        return build_retrieval_index(index.narrative_sections, index.kg_items, index.media_items, index.evidence_units, [])
    if variant == "no_provenance":
        sections = [WikiSection.from_dict({**s.to_dict(), "provenance": {}, "evidence_ids": []}) for s in index.narrative_sections]
        kg_items = [KGItem.from_dict({**k.to_dict(), "provenance": {}, "evidence_ids": []}) for k in index.kg_items]
        return build_retrieval_index(sections, kg_items, [], index.evidence_units, links)
    if variant == "flat_markdown":
        content = "\n".join(
            [s.content for s in index.narrative_sections] + [k.description or k.label for k in index.kg_items]
        )
        video_id = index.narrative_sections[0].video_id if index.narrative_sections else ""
        section = WikiSection(
            section_id="flat_markdown",
            video_id=video_id,
            section_type="flat",
            heading="Flat Markdown Context",
            content=content,
            confidence=1.0,
        )
        # Flat context collapses item ids, so the typed link set is dropped (paper "flat Markdown").
        return build_retrieval_index([section], [], index.media_items, index.evidence_units, [])
    raise ValueError(f"Unknown ablation variant: {variant}")


def _stress_index(index: RetrievalIndex, setting: str, level: float, rng: random.Random) -> RetrievalIndex:
    if setting == "subtitle_distractors":
        sections = list(index.narrative_sections)
        count = max(1, int(len(sections) * level)) if sections else 0
        for idx in range(min(count, len(sections))):
            section = sections[idx]
            sections[idx] = WikiSection.from_dict(
                {**section.to_dict(), "content": section.content + " Distractor evidence unrelated to the answer."}
            )
        return build_retrieval_index(sections, index.kg_items, index.media_items, index.evidence_units, index.cross_modal_links)
    if setting == "kg_distractors":
        kg_items = list(index.kg_items)
        video_id = kg_items[0].video_id if kg_items else ""
        for idx in range(max(1, int(4 * level))):
            kg_items.append(
                KGItem(
                    item_id=f"false_{idx}",
                    video_id=video_id,
                    item_type="distractor",
                    label="false relation",
                    description="A type-consistent false KG item.",
                )
            )
        return build_retrieval_index(index.narrative_sections, kg_items, index.media_items, index.evidence_units, index.cross_modal_links)
    if setting == "provenance_corruption":
        sections = []
        for section in index.narrative_sections:
            data = section.to_dict()
            if rng.random() < level:
                data["evidence_ids"] = ["corrupted"]
                data["provenance"] = {"corrupted": True}
            sections.append(WikiSection.from_dict(data))
        return build_retrieval_index(sections, index.kg_items, index.media_items, index.evidence_units, index.cross_modal_links)
    return index
