"""Knowledge build phase (paper Phases 1-3):

* :mod:`~viwikigraph.knowledge.extraction` — grounded evidence units from dataset features.
* :mod:`~viwikigraph.knowledge.kg` — knowledge-graph items.
* :mod:`~viwikigraph.knowledge.wiki` — validated narrative sections.
* :mod:`~viwikigraph.knowledge.validation` — claim support / conflict checks.
* :mod:`~viwikigraph.knowledge.corpus` — the external-knowledge corpus (KnowIT).

Imported validation-first so the narrative builder's dependency is ready.
"""

from viwikigraph.knowledge.validation import (
    detect_conflicts,
    support_score,
    validate_item,
)
from viwikigraph.knowledge.extraction import (
    FFmpegMediaExtractor,
    MediaExtractionError,
    OptionalVisionExtractor,
    build_textual_evidence,
    ingest_evidence,
    select_clip_windows,
)
from viwikigraph.knowledge.kg import build_kg_items, render_kg_markdown
from viwikigraph.knowledge.wiki import build_narrative_sections, render_narrative_markdown
from viwikigraph.knowledge.corpus import (
    KnowledgeCorpus,
    KnowledgeItem,
    build_knowledge_corpus,
    load_corpus,
    save_corpus,
)

__all__ = [
    # validation
    "detect_conflicts",
    "support_score",
    "validate_item",
    # extraction
    "FFmpegMediaExtractor",
    "MediaExtractionError",
    "OptionalVisionExtractor",
    "build_textual_evidence",
    "ingest_evidence",
    "select_clip_windows",
    # kg
    "build_kg_items",
    "render_kg_markdown",
    # wiki
    "build_narrative_sections",
    "render_narrative_markdown",
    # corpus
    "KnowledgeCorpus",
    "KnowledgeItem",
    "build_knowledge_corpus",
    "load_corpus",
    "save_corpus",
]
