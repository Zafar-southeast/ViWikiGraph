"""Phase 1 — evidence ingestion (paper §IV-A, eq. 10-11).

Turns a :class:`~viwikigraph.core.schemas.VideoRecord` into a list of grounded
:class:`~viwikigraph.core.schemas.EvidenceUnit`s drawn from dataset-provided features only:

* subtitle / ASR / caption text spans (``record.subtitles``),
* TVQA per-frame visual concepts (``metadata["visual_concepts"]``), de-duplicated to a bounded
  number of salient representative frames (eq. 11 TopK over visual salience),
* TVQA bbox character/object labels (``metadata["bbox_labels"]``) as strong entity evidence,
* structured ``entities/objects/actions/events/triples`` filled either by an LLM
  (:func:`viwikigraph.llm.prompts.extraction_prompt`, batched to bound calls) or, with no LLM/key,
  by the retained deterministic regex heuristics (``--no-llm`` / ``--dry-run`` / unit tests).

The visual stream is *features-only*: ffmpeg is never invoked by default. :class:`FFmpegMediaExtractor`,
:class:`OptionalVisionExtractor` and :func:`select_clip_windows` remain available for callers that opt
in, and produce :class:`~viwikigraph.core.schemas.MediaItem` path references only when a video file exists.
"""

from __future__ import annotations

import re
import shutil
import subprocess
from pathlib import Path
from typing import Any, Iterable, Sequence

from viwikigraph.core.io import ensure_dir
from viwikigraph.llm.client import LLMClient
from viwikigraph.llm.prompts import extraction_prompt, parse_json
from viwikigraph.core.schemas import EvidenceUnit, MediaItem, Modality, VideoRecord
from viwikigraph.core.text import optional_float as _optional_float
from viwikigraph.core.text import tokens as _word_tokens

# Default budget of representative visual-concept frames per video (paper "Bimg"). Overridable per
# record via ``metadata["Bimg"]`` so callers can pass the configured budget without changing the
# public ``ingest_evidence`` signature.
DEFAULT_BIMG = 4

# Modalities whose textual content benefits from structured extraction (LLM or regex fallback).
_TEXTUAL_MODALITIES = (Modality.SUBTITLE, Modality.ASR, Modality.CAPTION, Modality.OCR)

# Map a subtitle ``source`` tag to an evidence modality.
_SOURCE_MODALITY = {
    "asr": Modality.ASR,
    "transcript": Modality.ASR,
    "caption": Modality.CAPTION,
    "captions": Modality.CAPTION,
    "ocr": Modality.OCR,
    "subtitle": Modality.SUBTITLE,
    "subtitles": Modality.SUBTITLE,
    "srt": Modality.SUBTITLE,
}


class MediaExtractionError(RuntimeError):
    pass


def ingest_evidence(
    record: VideoRecord,
    llm: LLMClient | None = None,
    *,
    question_hints: Sequence[str] | None = None,
    vision: bool = False,
    frame_budget: int = DEFAULT_BIMG,
    media_dir: str | Path | None = None,
) -> list[EvidenceUnit]:
    """Build the Phase-1 evidence units for ``record`` from dataset-provided features only.

    ``llm`` is optional: when ``None`` (or when calls fail) the deterministic regex heuristics fill
    the structured fields, so the pipeline runs end-to-end offline. ``question_hints`` are optional
    salience cues (e.g. question/option tokens) that bias which visual-concept frames survive
    de-duplication; they are never treated as evidence themselves.

    When ``vision`` is set and a vision-capable ``llm`` is available, frames are sampled from the
    video and described by the VLM (:func:`viwikigraph.knowledge.vision.extract_visual_evidence`),
    adding caption/visual-concept/OCR units with real timestamps and saved-frame media paths. This is
    opt-in and degrades to a no-op without ffmpeg / a video / an API key.
    """
    hint_tokens = _hint_tokens(question_hints)

    units: list[EvidenceUnit] = []
    units.extend(_subtitle_units(record))
    units.extend(
        _visual_concept_units(record, budget=_resolve_bimg(record), hint_tokens=hint_tokens)
    )
    units.extend(_bbox_units(record))

    # Structured-field filling applies to TEXTUAL units only; run it before adding VLM units so the
    # vision-extracted entities/objects/actions are preserved (not re-derived from the caption text).
    _fill_structured_fields(units, llm)

    if vision and llm is not None:
        from viwikigraph.knowledge.vision import extract_visual_evidence

        units.extend(
            extract_visual_evidence(
                record,
                llm,
                num_frames=frame_budget,
                output_dir=media_dir,
                question_hints=question_hints,
            )
        )
    return units


def build_textual_evidence(record: VideoRecord) -> list[EvidenceUnit]:
    """Deterministic, LLM-free ingestion (kept for callers/tests that want the no-LLM path).

    Equivalent to ``ingest_evidence(record, llm=None)``; the structured fields are filled by the
    regex heuristics. Retained as a stable name used by :mod:`viwikigraph.pipeline`.
    """
    return ingest_evidence(record, llm=None)


def _subtitle_units(record: VideoRecord) -> list[EvidenceUnit]:
    """Subtitle/ASR/caption/OCR text spans, one per non-empty ``record.subtitles`` row."""
    units: list[EvidenceUnit] = []
    for index, subtitle in enumerate(record.subtitles):
        text = str(subtitle.get("text", "")).strip()
        if not text:
            continue
        source = str(subtitle.get("source", "subtitle"))
        modality = _SOURCE_MODALITY.get(source.lower(), Modality.SUBTITLE)
        units.append(
            EvidenceUnit(
                evidence_id=f"sub_{len(units) + 1}",
                video_id=record.video_id,
                modality=modality,
                text=text,
                start=_optional_float(subtitle.get("start")),
                end=_optional_float(subtitle.get("end")),
                confidence=1.0,
                provenance={"source": source, "index": subtitle.get("index", index)},
            )
        )
    return units


def _visual_concept_units(
    record: VideoRecord,
    *,
    budget: int,
    hint_tokens: frozenset[str],
) -> list[EvidenceUnit]:
    """De-duplicate TVQA per-frame concept strings to ``budget`` salient representative frames.

    Each frame string looks like ``"woman , pink shirt , couch"``. Salience (paper eq. 11) is the
    number of distinct concepts plus an entity/action density bonus and an optional match against
    ``hint_tokens``. We greedily keep the most salient frame whose concept set is not already
    covered by a kept frame, yielding ``VISUAL_CONCEPT`` units with ``objects=[...]``.
    """
    raw_concepts = record.metadata.get("visual_concepts") or []
    frames: list[tuple[int, list[str], float]] = []
    for index, concept in enumerate(raw_concepts):
        objects = _split_concepts(concept)
        if not objects:
            continue
        frames.append((index, objects, _visual_salience(objects, hint_tokens)))

    selected = _select_representative_frames(frames, max(0, budget))

    units: list[EvidenceUnit] = []
    for unit_index, (frame_index, objects, _salience) in enumerate(selected):
        units.append(
            EvidenceUnit(
                evidence_id=f"visual_concept_{unit_index + 1}",
                video_id=record.video_id,
                modality=Modality.VISUAL_CONCEPT,
                text=" , ".join(objects),
                confidence=0.75,
                provenance={"frame_index": frame_index, "source": "tvqa_visual_concepts"},
                objects=objects,
            )
        )
    return units


def _bbox_units(record: VideoRecord) -> list[EvidenceUnit]:
    """TVQA bbox character/object labels → entity evidence.

    ``metadata["bbox_labels"]`` maps a frame id to the labels present in that frame
    (``{frame_id: [labels]}``). Labels are strong entity evidence; one unit per frame.
    """
    bbox_labels = record.metadata.get("bbox_labels")
    if not isinstance(bbox_labels, dict):
        return []
    units: list[EvidenceUnit] = []
    for frame_id in _sorted_frame_ids(bbox_labels):
        labels = _normalize_labels(bbox_labels[frame_id])
        if not labels:
            continue
        units.append(
            EvidenceUnit(
                evidence_id=f"bbox_{len(units) + 1}",
                video_id=record.video_id,
                modality=Modality.VISUAL_CONCEPT,
                text=" , ".join(labels),
                confidence=0.9,
                provenance={"frame_id": frame_id, "source": "tvqa_bbox"},
                entities=labels,
            )
        )
    return units


def _fill_structured_fields(units: list[EvidenceUnit], llm: LLMClient | None) -> None:
    """Fill ``entities/objects/actions/events/facts`` on textual units, in place.

    LLM path: one :func:`extraction_prompt` call per textual unit (batched per video — the
    caller invokes this once per video). Any failure on a unit falls back to the regex heuristics
    for that unit, so a partial outage never breaks ingestion. No-LLM path: regex heuristics for all.
    """
    textual = [unit for unit in units if unit.modality in _TEXTUAL_MODALITIES and unit.text]
    use_llm = llm is not None
    for unit in textual:
        extracted: dict[str, Any] | None = None
        if use_llm:
            extracted = _llm_extract(llm, unit)
        if extracted is None:
            _apply_regex_fallback(unit)
        else:
            _apply_extracted(unit, extracted)


def _llm_extract(llm: LLMClient, unit: EvidenceUnit) -> dict[str, Any] | None:
    """Call the extraction prompt for one unit; ``None`` on any error (caller falls back)."""
    prompt = extraction_prompt(unit.text, unit.modality.value)
    try:
        if hasattr(llm, "strict_json"):
            return llm.strict_json(prompt, cache_version="extract_v1")
        response = llm.chat(prompt, response_format="json", cache_version="extract_v1")
        return parse_json(response.text)
    except Exception:
        return None


def _apply_extracted(unit: EvidenceUnit, data: dict[str, Any]) -> None:
    """Merge an LLM extraction result into ``unit`` (grounded fields only)."""
    unit.entities = _merge(unit.entities, _string_list(data.get("entities")))
    unit.objects = _merge(unit.objects, _string_list(data.get("objects")))
    unit.actions = _merge(unit.actions, _string_list(data.get("actions")))
    unit.events = _merge(unit.events, _string_list(data.get("events")))
    unit.facts = _merge_facts(unit.facts, _triples(data.get("triples")))


def _apply_regex_fallback(unit: EvidenceUnit) -> None:
    """Fill structured fields deterministically from the unit text."""
    unit.entities = _merge(unit.entities, _guess_entities(unit.text))
    unit.actions = _merge(unit.actions, _guess_actions(unit.text))
    unit.facts = _merge_facts(unit.facts, _simple_facts(unit.text))


# --- visual-concept salience helpers ---------------------------------------------------------


def _select_representative_frames(
    frames: list[tuple[int, list[str], float]],
    budget: int,
) -> list[tuple[int, list[str], float]]:
    """Greedy TopK: highest-salience frames whose concept sets are not already covered.

    Returns the kept frames in original temporal (frame-index) order so downstream consumers see a
    chronological visual stream.
    """
    if budget <= 0 or not frames:
        return []
    ordered = sorted(frames, key=lambda item: (-item[2], item[0]))
    kept: list[tuple[int, list[str], float]] = []
    covered: set[frozenset[str]] = set()
    for frame in ordered:
        key = frozenset(token.lower() for token in frame[1])
        if key in covered:
            continue
        covered.add(key)
        kept.append(frame)
        if len(kept) >= budget:
            break
    kept.sort(key=lambda item: item[0])
    return kept


def _visual_salience(objects: list[str], hint_tokens: frozenset[str]) -> float:
    """Distinct-concept count + entity/action density + optional question-hint overlap (eq. 11)."""
    distinct = {obj.lower() for obj in objects}
    density = sum(1 for obj in objects if " " in obj.strip())  # multi-word ≈ richer concept
    hint_bonus = 0.0
    if hint_tokens:
        frame_tokens = {token for obj in objects for token in _word_tokens(obj)}
        hint_bonus = 2.0 * len(frame_tokens & hint_tokens)
    return float(len(distinct)) + 0.5 * float(density) + hint_bonus


def _split_concepts(concept: Any) -> list[str]:
    """Split one frame's concept string/list into a de-duplicated, ordered object list."""
    if isinstance(concept, (list, tuple)):
        parts = [str(item).strip() for item in concept]
    else:
        parts = [part.strip() for part in str(concept).split(",")]
    out: list[str] = []
    seen: set[str] = set()
    for part in parts:
        if not part:
            continue
        key = part.lower()
        if key not in seen:
            seen.add(key)
            out.append(part)
    return out


# --- bbox helpers ----------------------------------------------------------------------------


def _sorted_frame_ids(bbox_labels: dict[Any, Any]) -> list[Any]:
    """Sort frame ids numerically when possible, else lexicographically, for stable ids."""

    def sort_key(frame_id: Any) -> tuple[int, float | str]:
        text = str(frame_id)
        try:
            return (0, float(text))
        except ValueError:
            return (1, text)

    return sorted(bbox_labels.keys(), key=sort_key)


def _normalize_labels(value: Any) -> list[str]:
    """Coerce a bbox-label value into a de-duplicated, ordered list of label strings."""
    if isinstance(value, (list, tuple, set)):
        raw = [str(item).strip() for item in value]
    else:
        raw = [str(value).strip()]
    out: list[str] = []
    seen: set[str] = set()
    for label in raw:
        if not label:
            continue
        key = label.lower()
        if key not in seen:
            seen.add(key)
            out.append(label)
    return out


# --- media (features-only; ffmpeg NOT invoked by default) ------------------------------------


class FFmpegMediaExtractor:
    """Optional ffmpeg-backed media extractor. Not invoked by the default features-only pipeline.

    When ``dry_run`` is set or the video file is missing, it emits :class:`MediaItem` path
    references only (no subprocess), so it is safe to call offline.
    """

    def __init__(self, ffmpeg_bin: str = "ffmpeg", ffprobe_bin: str = "ffprobe"):
        self.ffmpeg_bin = ffmpeg_bin
        self.ffprobe_bin = ffprobe_bin

    def available(self) -> bool:
        return shutil.which(self.ffmpeg_bin) is not None

    def sample_snapshots(
        self,
        video_path: str | Path,
        output_dir: str | Path,
        count: int,
        *,
        dry_run: bool = False,
    ) -> list[MediaItem]:
        output_dir = ensure_dir(output_dir)
        video_path = Path(video_path)
        if dry_run or not video_path.exists():
            return [
                MediaItem(
                    media_id=f"snapshot_{idx + 1}",
                    video_id=video_path.stem,
                    media_type="snapshot",
                    path=str(output_dir / f"snapshot_{idx + 1:04d}.jpg"),
                    confidence=0.0,
                    provenance={"dry_run": True},
                )
                for idx in range(count)
            ]
        if not self.available():
            raise MediaExtractionError("ffmpeg is not available.")
        pattern = output_dir / "snapshot_%04d.jpg"
        command = [
            self.ffmpeg_bin,
            "-y",
            "-i",
            str(video_path),
            "-vf",
            f"fps=1/{max(1, count)}",
            "-frames:v",
            str(count),
            str(pattern),
        ]
        subprocess.run(command, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return [
            MediaItem(
                media_id=f"snapshot_{idx + 1}",
                video_id=video_path.stem,
                media_type="snapshot",
                path=str(path),
                confidence=1.0,
                provenance={"extractor": "ffmpeg"},
            )
            for idx, path in enumerate(sorted(output_dir.glob("snapshot_*.jpg")))
        ]

    def extract_clips(
        self,
        video_path: str | Path,
        windows: Iterable[tuple[float, float]],
        output_dir: str | Path,
        *,
        dry_run: bool = False,
    ) -> list[MediaItem]:
        output_dir = ensure_dir(output_dir)
        video_path = Path(video_path)
        items: list[MediaItem] = []
        for index, (start, end) in enumerate(windows, start=1):
            clip_path = output_dir / f"clip_{index:04d}.mp4"
            if not dry_run and video_path.exists():
                if not self.available():
                    raise MediaExtractionError("ffmpeg is not available.")
                subprocess.run(
                    [
                        self.ffmpeg_bin,
                        "-y",
                        "-ss",
                        str(start),
                        "-to",
                        str(end),
                        "-i",
                        str(video_path),
                        "-c",
                        "copy",
                        str(clip_path),
                    ],
                    check=True,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )
            items.append(
                MediaItem(
                    media_id=f"clip_{index}",
                    video_id=video_path.stem,
                    media_type="clip",
                    path=str(clip_path),
                    start=start,
                    end=end,
                    confidence=0.0 if dry_run or not video_path.exists() else 1.0,
                    provenance={"dry_run": dry_run or not video_path.exists(), "extractor": "ffmpeg"},
                )
            )
        return items


class OptionalVisionExtractor:
    """Hook for OCR, object detection, and captioning without forcing dependencies."""

    def evidence_from_media(self, video_id: str, media_items: list[MediaItem]) -> list[EvidenceUnit]:
        units: list[EvidenceUnit] = []
        for index, item in enumerate(media_items, start=1):
            text = f"Visual media item {Path(item.path).name}"
            units.append(
                EvidenceUnit(
                    evidence_id=f"media_{index}",
                    video_id=video_id,
                    modality=Modality.CAPTION,
                    text=text,
                    start=item.start,
                    end=item.end,
                    confidence=item.confidence,
                    provenance={"media_path": item.path, "extractor": "placeholder_vision"},
                    media_paths=[item.path],
                )
            )
        return units


def select_clip_windows(record: VideoRecord, budget: int) -> list[tuple[float, float]]:
    windows: list[tuple[float, float]] = []
    for subtitle in record.subtitles:
        start = _optional_float(subtitle.get("start"))
        end = _optional_float(subtitle.get("end"))
        if start is not None and end is not None and end > start:
            windows.append((start, end))
        if len(windows) >= budget:
            break
    if not windows and budget > 0:
        windows.append((0.0, 5.0))
    return windows[:budget]


# --- deterministic structured-extraction fallbacks (retained) --------------------------------


def _guess_entities(text: str) -> list[str]:
    return sorted(set(re.findall(r"\b[A-Z][a-zA-Z]+\b", text)))


def _guess_actions(text: str) -> list[str]:
    candidates = re.findall(r"\b[a-z]+(?:ing|ed|s)\b", text.lower())
    stop = {"this", "his", "hers", "things"}
    return sorted({item for item in candidates if item not in stop})[:8]


def _simple_facts(text: str) -> list[tuple[str, str, str]]:
    entities = _guess_entities(text)
    actions = _guess_actions(text)
    if len(entities) >= 2 and actions:
        return [(entities[0], actions[0], entities[1])]
    return []


# --- small generic helpers -------------------------------------------------------------------


def _resolve_bimg(record: VideoRecord) -> int:
    raw = record.metadata.get("Bimg")
    if raw is None:
        return DEFAULT_BIMG
    try:
        return max(0, int(raw))
    except (TypeError, ValueError):
        return DEFAULT_BIMG


def _hint_tokens(question_hints: Sequence[str] | None) -> frozenset[str]:
    if not question_hints:
        return frozenset()
    tokens: set[str] = set()
    for hint in question_hints:
        tokens.update(_word_tokens(hint))
    return frozenset(tokens)


def _string_list(value: Any) -> list[str]:
    if not isinstance(value, (list, tuple)):
        return []
    out: list[str] = []
    for item in value:
        text = str(item).strip()
        if text:
            out.append(text)
    return out


def _triples(value: Any) -> list[tuple[str, str, str]]:
    if not isinstance(value, (list, tuple)):
        return []
    out: list[tuple[str, str, str]] = []
    for item in value:
        if isinstance(item, dict):
            subject = str(item.get("subject", "")).strip()
            relation = str(item.get("relation", "")).strip()
            obj = str(item.get("object", "")).strip()
        elif isinstance(item, (list, tuple)) and len(item) == 3:
            subject, relation, obj = (str(part).strip() for part in item)
        else:
            continue
        if subject and relation and obj:
            out.append((subject, relation, obj))
    return out


def _merge(existing: list[str], extra: list[str]) -> list[str]:
    out = list(existing)
    seen = {item.lower() for item in out}
    for item in extra:
        key = item.lower()
        if key not in seen:
            seen.add(key)
            out.append(item)
    return out


def _merge_facts(
    existing: list[tuple[str, str, str]],
    extra: list[tuple[str, str, str]],
) -> list[tuple[str, str, str]]:
    out = list(existing)
    seen = {tuple(part.lower() for part in fact) for fact in out}
    for fact in extra:
        key = tuple(part.lower() for part in fact)
        if key not in seen:
            seen.add(key)
            out.append(fact)
    return out
