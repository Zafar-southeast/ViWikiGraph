"""Video-LLM (VLM) visual evidence extraction (v1 opt-in visual stream).

This is the optional pathway that lets ViWikiGraph *read the video* — frames are sampled from the
raw ``.mp4`` and sent to the SAME vision-capable LLM (:meth:`LLMClient.chat_vision`) used everywhere
else, which returns per-frame descriptions, grounded objects/entities/actions/events, and on-screen
text (OCR). These become :class:`EvidenceUnit`s (modalities ``caption`` / ``visual_concept`` / ``ocr``)
with timestamps and a saved-frame ``media_path``, so they flow through cross-modal linking, the visual
support signal e_vis, q_media validation, and retrieval exactly like any other evidence.

It stays opt-in and offline-safe: with no LLM, no API key, no ffmpeg, or no video file, the extractor
returns ``[]`` and the pipeline falls back to its features-only / sidecar evidence. No model is
trained — this is inference only, consistent with the RAG-only constraint.
"""

from __future__ import annotations

import shutil
import subprocess
from pathlib import Path
from typing import Any, Sequence

from viwikigraph.core.io import ensure_dir
from viwikigraph.core.schemas import EvidenceUnit, Modality, VideoRecord

DEFAULT_FRAME_BUDGET = 4
VISION_REQUEST_FRAME_LIMIT = 4
# Vision JSON grows with the frame count; the default 2000-token budget truncates multi-frame chunks
# mid-array (the exp7 partial-vision cause). Scale the budget with the chunk size, never below the
# client's configured ``max_tokens``.
_VISION_TOKENS_PER_FRAME = 700
_VISION_TOKENS_BASE = 400


def _vision_max_tokens(llm: Any, n_frames: int) -> int:
    configured = getattr(llm, "max_tokens", 0) or 0
    return max(int(configured), _VISION_TOKENS_PER_FRAME * n_frames + _VISION_TOKENS_BASE)


def extract_visual_evidence(
    record: VideoRecord,
    llm: Any | None,
    *,
    num_frames: int = DEFAULT_FRAME_BUDGET,
    output_dir: str | Path | None = None,
    question_hints: Sequence[str] | None = None,
    sampler: Any | None = None,
) -> list[EvidenceUnit]:
    """Extract visual :class:`EvidenceUnit`s from ``record``'s video via the vision LLM (opt-in).

    Returns ``[]`` (no-op) unless a usable vision LLM is available AND frames can be sampled from an
    existing video file. ``sampler`` (frames provider) defaults to :func:`sample_frames` and is
    injectable for testing.

    A failure still degrades to ``[]`` (the build never breaks), but the *reason* is recorded on
    ``record.metadata`` as ``vision_status`` (``no_llm`` / ``disabled`` / ``no_frames`` / ``error`` /
    ``partial`` / ``empty`` / ``ok``) plus ``frames_sampled`` and ``frames_described`` counts, so an
    evidence-free package is observable in the manifest instead of looking identical to a video with
    nothing in it.
    """

    def _status(status: str, *, sampled: int = 0, described: int = 0, detail: str = "") -> None:
        record.metadata["vision_status"] = status
        record.metadata["frames_sampled"] = sampled
        record.metadata["frames_described"] = described
        if detail:
            record.metadata["vision_detail"] = detail

    if llm is None or not getattr(llm, "available", False) or not hasattr(llm, "strict_json_vision"):
        _status("no_llm")
        return []
    if num_frames <= 0:
        _status("disabled")
        return []
    video_path = Path(record.video_path)
    out_dir = Path(output_dir) if output_dir else video_path.parent / f"{record.video_id}_frames"
    frame_fn = sampler or sample_frames
    frames = frame_fn(video_path, out_dir, num_frames)
    if not frames:
        _status("no_frames")
        return []

    units: list[EvidenceUnit] = []
    chunk_errors: list[str] = []
    for offset in range(0, len(frames), VISION_REQUEST_FRAME_LIMIT):
        chunk = frames[offset : offset + VISION_REQUEST_FRAME_LIMIT]
        chunk_units, errors = _extract_chunk_units(
            record.video_id,
            llm,
            chunk,
            frame_offset=offset,
            question_hints=list(question_hints or []),
        )
        units.extend(chunk_units)
        chunk_errors.extend(errors)
    _renumber_units(units)
    if not units:
        if chunk_errors:
            _status("error", sampled=len(frames), detail="; ".join(chunk_errors)[:200])
            return []
        # Frames were sent and a response parsed, but it carried no usable per-frame facts — a soft
        # refusal or empty/garbage JSON. Distinct from "no video"; surfaced so it is not silent.
        _status("empty", sampled=len(frames))
        return []
    described = len({u.provenance.get("frame_index") for u in units} - {None})
    if chunk_errors:
        _status("partial", sampled=len(frames), described=described, detail="; ".join(chunk_errors)[:200])
        return units
    _status("ok", sampled=len(frames), described=described)
    return units


def _extract_chunk_units(
    video_id: str,
    llm: Any,
    frames: list[tuple[float | None, Path]],
    *,
    frame_offset: int,
    question_hints: list[str],
) -> tuple[list[EvidenceUnit], list[str]]:
    from viwikigraph.llm.prompts import video_vision_prompt

    prompt = video_vision_prompt(len(frames), question_hints)
    paths = [str(path) for _, path in frames]
    try:
        data = llm.strict_json_vision(
            prompt, paths, cache_version="vision_v3", max_tokens=_vision_max_tokens(llm, len(frames))
        )
        units = _units_from_response(video_id, frames, data, frame_offset=frame_offset)
    except Exception as exc:
        if len(frames) == 1:
            detail = f"frame {frame_offset + 1}: {type(exc).__name__}: {exc}"
            return [], [detail[:200]]
        return _retry_frames_individually(video_id, llm, list(enumerate(frames)), frame_offset, question_hints)

    # The tolerant parser may recover only the frames that completed before a truncation/quote break.
    # Re-issue the frames that produced no unit one at a time (a single-frame request rarely truncates),
    # so a partially-parsed multi-frame chunk still recovers its tail instead of silently dropping it.
    if len(frames) > 1:
        covered = {u.provenance.get("frame_index") for u in units}
        missing = [(index, frame) for index, frame in enumerate(frames) if frame_offset + index not in covered]
        if missing:
            extra_units, errors = _retry_frames_individually(video_id, llm, missing, frame_offset, question_hints)
            return units + extra_units, errors
    return units, []


def _retry_frames_individually(
    video_id: str,
    llm: Any,
    indexed_frames: list[tuple[int, tuple[float | None, Path]]],
    frame_offset: int,
    question_hints: list[str],
) -> tuple[list[EvidenceUnit], list[str]]:
    """Recover the given frames one request at a time, collecting per-frame errors."""
    units: list[EvidenceUnit] = []
    errors: list[str] = []
    for index, frame in indexed_frames:
        frame_units, frame_errors = _extract_chunk_units(
            video_id, llm, [frame], frame_offset=frame_offset + index, question_hints=question_hints
        )
        units.extend(frame_units)
        errors.extend(frame_errors)
    return units, errors


def sample_frames(
    video_path: str | Path,
    output_dir: str | Path,
    num_frames: int,
) -> list[tuple[float | None, Path]]:
    """Sample ``num_frames`` evenly-spaced frames (with timestamps) via ffmpeg. ``[]`` if unavailable.

    Requires ffmpeg on PATH and an existing video file (graceful empty otherwise). Uses ffprobe to
    find the duration so frames land at evenly-spaced timestamps; falls back to 1s spacing if ffprobe
    is absent."""
    video_path = Path(video_path)
    if num_frames <= 0 or not video_path.exists():
        return []
    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        return []
    output_dir = ensure_dir(output_dir)
    duration = _probe_duration(video_path)
    frames: list[tuple[float | None, Path]] = []
    for index in range(num_frames):
        timestamp = duration * (index + 0.5) / num_frames if duration and duration > 0 else float(index)
        out = output_dir / f"frame_{index + 1:04d}.jpg"
        cmd = [ffmpeg, "-y", "-ss", str(timestamp), "-i", str(video_path),
               "-frames:v", "1", "-q:v", "3", str(out)]
        try:
            subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=120)
        except (OSError, subprocess.SubprocessError):
            continue
        if out.exists():
            frames.append((timestamp if duration else None, out))
    return frames


def _probe_duration(video_path: Path) -> float | None:
    ffprobe = shutil.which("ffprobe")
    if not ffprobe:
        return None
    cmd = [ffprobe, "-v", "error", "-show_entries", "format=duration",
           "-of", "default=noprint_wrappers=1:nokey=1", str(video_path)]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30, check=False)
        return float(result.stdout.strip())
    except (OSError, subprocess.SubprocessError, ValueError):
        return None


def _units_from_response(
    video_id: str,
    frames: list[tuple[float | None, Path]],
    data: dict[str, Any],
    *,
    frame_offset: int = 0,
) -> list[EvidenceUnit]:
    """Parse the vision JSON into caption/visual_concept/ocr EvidenceUnits grounded at each frame."""
    frame_results = data.get("frames") if isinstance(data, dict) else None
    if not isinstance(frame_results, list):
        return []
    by_index = {}
    for raw in frame_results:
        if isinstance(raw, dict):
            try:
                by_index[int(raw.get("index", -1))] = raw
            except (TypeError, ValueError):
                continue

    units: list[EvidenceUnit] = []
    for index, (timestamp, path) in enumerate(frames):
        raw = by_index.get(index)
        if raw is None:
            continue
        objects = _strings(raw.get("objects"))
        entities = _strings(raw.get("entities"))
        actions = _strings(raw.get("actions"))
        events = _strings(raw.get("events"))
        description = str(raw.get("description", "")).strip()
        caption_text = description or ", ".join(objects + entities)
        if caption_text or objects or entities:
            units.append(
                EvidenceUnit(
                    evidence_id=f"vlm_{len(units) + 1}",
                    video_id=video_id,
                    modality=Modality.CAPTION,
                    text=caption_text,
                    start=timestamp,
                    end=timestamp,
                    confidence=0.8,
                    provenance={"source": "vlm", "frame_index": frame_offset + index, "timestamp": timestamp},
                    entities=entities,
                    objects=objects,
                    actions=actions,
                    events=events,
                    media_paths=[str(path)],
                )
            )
        ocr_text = str(raw.get("ocr", "")).strip()
        if ocr_text:
            units.append(
                EvidenceUnit(
                    evidence_id=f"vlm_ocr_{sum(1 for u in units if u.modality == Modality.OCR) + 1}",
                    video_id=video_id,
                    modality=Modality.OCR,
                    text=ocr_text,
                    start=timestamp,
                    end=timestamp,
                    confidence=0.8,
                    provenance={"source": "vlm_ocr", "frame_index": frame_offset + index, "timestamp": timestamp},
                    media_paths=[str(path)],
                )
            )
    return units


def _renumber_units(units: list[EvidenceUnit]) -> None:
    caption_count = 0
    ocr_count = 0
    for unit in units:
        if unit.modality == Modality.OCR:
            ocr_count += 1
            unit.evidence_id = f"vlm_ocr_{ocr_count}"
        else:
            caption_count += 1
            unit.evidence_id = f"vlm_{caption_count}"


def _strings(value: Any) -> list[str]:
    if not isinstance(value, (list, tuple)):
        return []
    out: list[str] = []
    for item in value:
        text = str(item).strip()
        if text and text not in out:
            out.append(text)
    return out
