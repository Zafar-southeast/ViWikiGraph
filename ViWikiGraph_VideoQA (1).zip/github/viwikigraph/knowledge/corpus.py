"""KnowIT external-knowledge corpus (RAG, no LLM) — SPEC §6.

KnowIT VQA is knowledge-intensive: answering many questions requires external/world knowledge that
the dataset distributes as the per-row gold ``reason`` sentence. This module turns the **train**
split's ``reason`` sentences (plus optional captions/faces sidecars, when present in record/QA
metadata) into a small, on-disk, BM25-searchable corpus that downstream retrieval (``retrieval.py``)
queries at answer time.

Hard constraints (see the implementation spec):
  - Pure-Python, deterministic, **no LLM** and **no network**. The BM25 scorer is implemented
    locally with a token-overlap tie-breaker so it works fully offline.
  - **Leakage guard:** the corpus is built from the *train* split only, and :meth:`retrieve` accepts
    ``exclude_scene`` / ``exclude_text`` so a queried row's own gold ``reason`` can never surface in
    its retrieved knowledge. Gold annotations (``reason``/``kg_type``/``QType``/``answer_index``) are
    indexed as a knowledge *source*, never read back as answer-time evidence for the same row.
  - TVQA / NExT-QA carry no external-knowledge corpus: :func:`build_knowledge_corpus` returns an
    empty (disabled) corpus for any non-KnowIT adapter, and :meth:`retrieve` then yields ``[]``.
"""

from __future__ import annotations

import math
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Protocol

from viwikigraph.core.io import read_jsonl, write_jsonl
from viwikigraph.core.text import tokenize as _tokenize

# BM25 Okapi free parameters (standard defaults).
_BM25_K1 = 1.5
_BM25_B = 0.75


class _QAAdapter(Protocol):
    """Minimal adapter surface used to build the corpus (matches ``datasets.py`` adapters)."""

    dataset: str

    def iter_qa_instances(self, split: str) -> Iterable[Any]:  # pragma: no cover - structural
        ...


@dataclass(slots=True)
class KnowledgeItem:
    """One indexed knowledge snippet plus its pre-tokenized form for BM25."""

    text: str
    scene: str
    source: str
    tokens: list[str] = field(default_factory=list)

    def to_record(self) -> dict[str, Any]:
        """Serialize without the derived ``tokens`` field (re-derived on load)."""
        return {"text": self.text, "scene": self.scene, "source": self.source}


@dataclass(slots=True)
class KnowledgeCorpus:
    """Deterministic BM25 corpus over KnowIT train-split knowledge snippets.

    A corpus with no items (TVQA/NExT-QA, or an empty train split) is *disabled*: :meth:`retrieve`
    returns ``[]`` regardless of the query.
    """

    dataset: str
    items: list[KnowledgeItem] = field(default_factory=list)
    _doc_freq: dict[str, int] = field(default_factory=dict, repr=False)
    _avg_len: float = 0.0

    def __post_init__(self) -> None:
        self._reindex()

    @property
    def enabled(self) -> bool:
        """True when the corpus holds at least one snippet."""
        return bool(self.items)

    def _reindex(self) -> None:
        """(Re)compute document frequencies and average length from ``items``."""
        doc_freq: Counter[str] = Counter()
        total_len = 0
        for item in self.items:
            if not item.tokens:
                item.tokens = _tokenize(item.text)
            total_len += len(item.tokens)
            doc_freq.update(set(item.tokens))
        self._doc_freq = dict(doc_freq)
        self._avg_len = (total_len / len(self.items)) if self.items else 0.0

    def retrieve(
        self,
        question: str,
        options: list[str] | None = None,
        k: int = 5,
        *,
        exclude_scene: str | None = None,
        exclude_text: str | None = None,
    ) -> list[dict[str, Any]]:
        """Return the top-``k`` knowledge snippets for ``question`` (+ ``options``).

        Scoring is BM25 over the query tokens with a token-overlap tie-breaker; both are fully
        deterministic and offline. The queried row's own knowledge is suppressed via the leakage
        guard: any item whose ``scene == exclude_scene`` or whose normalized ``text`` matches
        ``exclude_text`` is dropped before ranking, so a row never retrieves its own gold ``reason``.

        Each returned dict has keys ``{text, scene, source, score}`` (matching ``EvidencePacket``'s
        ``knowledge`` shape with an extra ``score``); the list is ordered by descending score.
        """
        if not self.enabled or k <= 0:
            return []
        query = question if options is None else " ".join([question, *options])
        query_tokens = _tokenize(query)
        if not query_tokens:
            return []
        excl_text = _normalize(exclude_text) if exclude_text else None
        scored: list[tuple[float, int, dict[str, Any]]] = []
        for index, item in enumerate(self.items):
            if exclude_scene is not None and item.scene == exclude_scene:
                continue
            if excl_text is not None and _normalize(item.text) == excl_text:
                continue
            score = self._bm25(query_tokens, item)
            if score <= 0.0:
                continue
            scored.append(
                (score, index, {"text": item.text, "scene": item.scene, "source": item.source, "score": round(score, 6)})
            )
        # Sort by score desc, then by original index for a stable deterministic ordering.
        scored.sort(key=lambda triple: (-triple[0], triple[1]))
        return [payload for _, _, payload in scored[:k]]

    def _bm25(self, query_tokens: list[str], item: KnowledgeItem) -> float:
        """Okapi BM25 score of ``item`` against the query token list."""
        doc_len = len(item.tokens)
        if doc_len == 0:
            return 0.0
        counts = Counter(item.tokens)
        n_docs = len(self.items)
        score = 0.0
        for term in set(query_tokens):
            tf = counts.get(term, 0)
            if tf == 0:
                continue
            df = self._doc_freq.get(term, 0)
            idf = math.log(1.0 + (n_docs - df + 0.5) / (df + 0.5))
            denom = tf + _BM25_K1 * (1.0 - _BM25_B + _BM25_B * doc_len / (self._avg_len or 1.0))
            score += idf * (tf * (_BM25_K1 + 1.0)) / (denom or 1.0)
        return score

    def to_records(self) -> list[dict[str, Any]]:
        """Serializable snippet records (``{text, scene, source}``), in index order."""
        return [item.to_record() for item in self.items]

    @classmethod
    def from_records(cls, dataset: str, records: Iterable[dict[str, Any]]) -> "KnowledgeCorpus":
        """Build a corpus from serialized snippet records (de-duplicated by text+scene+source)."""
        items: list[KnowledgeItem] = []
        seen: set[tuple[str, str, str]] = set()
        for record in records:
            text = str(record.get("text", "")).strip()
            if not text:
                continue
            scene = str(record.get("scene", ""))
            source = str(record.get("source", "knowit_reason"))
            key = (_normalize(text), scene, source)
            if key in seen:
                continue
            seen.add(key)
            items.append(KnowledgeItem(text=text, scene=scene, source=source))
        return cls(dataset=dataset, items=items)


def build_knowledge_corpus(adapter: _QAAdapter, split: str = "train") -> KnowledgeCorpus:
    """Index a dataset's external-knowledge snippets into a :class:`KnowledgeCorpus`.

    For KnowIT, indexes the ``split`` (train by default) gold ``reason`` sentences read from
    ``adapter.iter_qa_instances(split)`` metadata, plus optional ``captions``/``faces`` sidecar text
    when the adapter surfaces them in QA metadata. The gold ``reason`` is treated as a knowledge
    *source* for OTHER rows only; the per-row leakage guard in :meth:`KnowledgeCorpus.retrieve`
    prevents a row from ever retrieving its own reason.

    For any non-KnowIT adapter (TVQA / NExT-QA), returns an empty (disabled) corpus.
    """
    dataset = str(getattr(adapter, "dataset", "")).lower()
    if dataset != "knowit":
        return KnowledgeCorpus(dataset=dataset or "unknown", items=[])

    records: list[dict[str, Any]] = []
    for qa in adapter.iter_qa_instances(split):
        metadata = dict(getattr(qa, "metadata", {}) or {})
        scene = str(metadata.get("scene", getattr(qa, "video_id", "")))
        reason = str(metadata.get("reason", "")).strip()
        if reason:
            records.append({"text": reason, "scene": scene, "source": "knowit_reason"})
        for caption in _coerce_text_list(metadata.get("captions")):
            records.append({"text": caption, "scene": scene, "source": "knowit_caption"})
        for face in _coerce_text_list(metadata.get("faces")):
            records.append({"text": face, "scene": scene, "source": "knowit_face"})
    return KnowledgeCorpus.from_records("knowit", records)


def save_corpus(corpus: KnowledgeCorpus, path: str | Path) -> None:
    """Persist a corpus as JSONL (one ``{text, scene, source}`` record per line)."""
    write_jsonl(path, corpus.to_records())


def load_corpus(path: str | Path, dataset: str = "knowit") -> KnowledgeCorpus:
    """Load a corpus previously written by :func:`save_corpus`. Missing file → empty corpus."""
    file_path = Path(path)
    if not file_path.exists():
        return KnowledgeCorpus(dataset=dataset, items=[])
    return KnowledgeCorpus.from_records(dataset, read_jsonl(file_path))


def _coerce_text_list(value: Any) -> list[str]:
    """Normalize an optional captions/faces sidecar value into a list of non-empty strings."""
    if not value:
        return []
    raw: Iterable[Any]
    if isinstance(value, str):
        raw = [value]
    elif isinstance(value, dict):
        raw = value.values()
    elif isinstance(value, (list, tuple)):
        raw = value
    else:
        return []
    out: list[str] = []
    for entry in raw:
        if isinstance(entry, dict):
            entry = entry.get("text", "")
        text = str(entry).strip()
        if text:
            out.append(text)
    return out


def _normalize(text: str) -> str:
    """Whitespace/case-normalized form for exact-text leakage and de-duplication checks."""
    return " ".join((text or "").lower().split())
