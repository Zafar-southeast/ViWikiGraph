"""Phase 2 — schema-guided narrative wiki (paper §IV-B, eq. 13-17).

``build_narrative_sections`` drafts the fixed-schema narrative wiki for one video. With an
``LLMClient`` it runs a single :func:`viwikigraph.llm.prompts.narrative_prompt` call, validates every
cited ``evidence_id`` against the real :class:`EvidenceUnit` ids (dropping hallucinated refs), scores
each atomic claim with :func:`viwikigraph.knowledge.validation.support_score` (eq. 15), and keeps only claims
whose support is ``>= tau_sup`` (eq. 16). Without an LLM (no API key / ``--dry-run`` / unit tests) it
falls back to the deterministic heuristic sections. ``render_narrative_markdown`` is unchanged in
shape (heading / time / confidence / evidence / media / content) and appends a provenance listing.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from typing import Any

from viwikigraph.llm.prompts import NARRATIVE_SECTION_TYPES, narrative_prompt, parse_json
from viwikigraph.core.schemas import EvidenceUnit, WikiSection
from viwikigraph.core.text import fmt_time as _fmt_time
from viwikigraph.core.text import tokens as _tokens

try:  # validation.support_score is owned by the validation phase (spec §7).
    from viwikigraph.knowledge.validation import support_score as _support_score
except ImportError:  # pragma: no cover - keeps wiki usable before that phase lands.
    _support_score = None


#: Default support threshold ``τ_sup`` for retaining atomic claims (paper eq. 16).
DEFAULT_TAU_SUP = 0.5

__all__ = ["build_narrative_sections", "render_narrative_markdown"]


@dataclass(slots=True)
class _DraftSection:
    """LLM-proposed section before evidence validation and claim filtering."""

    section_type: str
    heading: str
    content: str
    claims: list[str]
    evidence_ids: list[str]


def build_narrative_sections(
    video_id: str,
    evidence: list[EvidenceUnit],
    metadata: dict[str, Any],
    llm: Any | None = None,
    *,
    tau_sup: float = DEFAULT_TAU_SUP,
) -> list[WikiSection]:
    """Build the schema-guided narrative wiki sections for ``video_id`` (eq. 13-16).

    With a usable ``llm`` the model drafts schema sections; cited evidence ids are validated against
    the real units, hallucinated refs are dropped, per-claim support is computed via
    :func:`support_score`, and only claims ``>= tau_sup`` are retained. Otherwise the deterministic
    heuristic sections are returned so the pipeline runs end-to-end offline.
    """
    if llm is not None and getattr(llm, "available", False):
        sections = _llm_sections(video_id, evidence, metadata, llm, tau_sup)
        if sections:
            return sections
    return _heuristic_sections(video_id, evidence, metadata)


# --------------------------------------------------------------------------- LLM path


def _llm_sections(
    video_id: str,
    evidence: list[EvidenceUnit],
    metadata: dict[str, Any],
    llm: Any,
    tau_sup: float,
) -> list[WikiSection]:
    """Draft, validate, and assemble narrative sections from a single LLM call."""
    evidence_by_id = {unit.evidence_id: unit for unit in evidence}
    digest = _evidence_digest(evidence)
    try:
        response = llm.chat(narrative_prompt(video_id, digest), response_format="json", cache_version="v1")
        payload = parse_json(response.text)
    except Exception:
        return []

    sections: list[WikiSection] = []
    scene_index = 0
    for raw in payload.get("sections", []):
        draft = _coerce_draft(raw)
        if draft is None:
            continue
        valid_ids = [eid for eid in draft.evidence_ids if eid in evidence_by_id]
        linked = [evidence_by_id[eid] for eid in valid_ids]
        retained = _retain_supported_claims(draft.claims, linked, tau_sup)
        if not draft.content.strip() and not retained:
            continue
        if draft.section_type == "scene":
            scene_index += 1
            section_id = f"scene_{scene_index}"
        else:
            section_id = draft.section_type
        start, end, media_paths = _span_and_media(linked)
        sections.append(
            WikiSection(
                section_id=section_id,
                video_id=video_id,
                section_type=draft.section_type,
                heading=draft.heading or draft.section_type.title(),
                content=draft.content,
                claims=retained,
                evidence_ids=valid_ids,
                start=start,
                end=end,
                confidence=_avg_confidence(linked),
                provenance={
                    "source": "llm_narrative",
                    "metadata": metadata,
                    "evidence_ids": valid_ids,
                    "media_paths": media_paths,
                    "dropped_evidence_ids": [eid for eid in draft.evidence_ids if eid not in evidence_by_id],
                },
            )
        )
    return sections


def _coerce_draft(raw: Any) -> _DraftSection | None:
    """Validate one model-proposed section dict against the fixed schema."""
    if not isinstance(raw, dict):
        return None
    section_type = str(raw.get("type", "")).strip().lower()
    if section_type not in NARRATIVE_SECTION_TYPES:
        return None
    claims = [str(c).strip() for c in raw.get("claims", []) if str(c).strip()]
    evidence_ids = [str(e).strip() for e in raw.get("evidence_ids", []) if str(e).strip()]
    return _DraftSection(
        section_type=section_type,
        heading=str(raw.get("heading", "")).strip(),
        content=str(raw.get("content", "")).strip(),
        claims=claims,
        evidence_ids=evidence_ids,
    )


def _retain_supported_claims(claims: list[str], evidence: list[EvidenceUnit], tau_sup: float) -> list[str]:
    """Keep atomic claims whose support (eq. 15) meets ``tau_sup`` (eq. 16)."""
    retained: list[str] = []
    for claim in claims:
        score, _ = _claim_support(claim, evidence)
        if score >= tau_sup:
            retained.append(claim)
    return retained


def _claim_support(text: str, evidence: list[EvidenceUnit]) -> tuple[float, list[str]]:
    """Per-claim support via :func:`validation.support_score`, with an offline fallback."""
    if _support_score is not None:
        return _support_score(text, evidence)
    return _fallback_support(text, evidence)


def _fallback_support(text: str, evidence: list[EvidenceUnit]) -> tuple[float, list[str]]:
    """Token-overlap support used only when ``validation.support_score`` is unavailable.

    Mirrors the ``(score, supporting_ids)`` contract of eq. 15 so the LLM path stays deterministic
    and offline-safe until the validation phase provides the canonical scorer.
    """
    tokens = _tokens(text)
    if not tokens or not evidence:
        return 0.0, []
    best_score = 0.0
    supporting: list[str] = []
    for unit in evidence:
        unit_tokens = _tokens(" ".join([unit.text, *unit.entities, *unit.objects, *unit.actions, *unit.events]))
        overlap = len(tokens & unit_tokens) / len(tokens)
        score = min(1.0, 0.2 + overlap) if overlap else 0.0
        if score > best_score:
            best_score = score
            supporting = [unit.evidence_id]
    return round(best_score, 3), supporting


# --------------------------------------------------------------------------- deterministic path


def _heuristic_sections(video_id: str, evidence: list[EvidenceUnit], metadata: dict[str, Any]) -> list[WikiSection]:
    """Deterministic fallback sections (summary / scene* / entity / object)."""
    sections: list[WikiSection] = []
    evidence_ids = [unit.evidence_id for unit in evidence]
    starts = [unit.start for unit in evidence if unit.start is not None]
    ends = [unit.end for unit in evidence if unit.end is not None]
    entities = Counter(entity for unit in evidence for entity in unit.entities)
    objects = Counter(obj for unit in evidence for obj in unit.objects)
    actions = Counter(action for unit in evidence for action in unit.actions)

    summary_text = _summary_text(evidence, entities, actions)
    sections.append(
        WikiSection(
            section_id="summary",
            video_id=video_id,
            section_type="summary",
            heading="Global Summary",
            content=summary_text,
            claims=_split_claims(summary_text),
            evidence_ids=evidence_ids,
            start=min(starts) if starts else None,
            end=max(ends) if ends else None,
            confidence=_avg_confidence(evidence),
            provenance={"source": "heuristic", "metadata": metadata, "evidence_ids": evidence_ids},
        )
    )

    for index, unit in enumerate(evidence, start=1):
        content = unit.text or ", ".join(unit.objects + unit.entities + unit.actions) or "No textual evidence available."
        media_paths = list(unit.media_paths)
        if "snapshot_path" in unit.provenance:
            media_paths.append(str(unit.provenance["snapshot_path"]))
        sections.append(
            WikiSection(
                section_id=f"scene_{index}",
                video_id=video_id,
                section_type="scene",
                heading=f"Scene {index}",
                content=content,
                claims=_split_claims(content),
                evidence_ids=[unit.evidence_id],
                start=unit.start,
                end=unit.end,
                confidence=unit.confidence,
                provenance={"source": unit.provenance, "media_paths": media_paths},
            )
        )

    if entities:
        entity_text = "; ".join(f"{name} appears {count} time(s)" for name, count in entities.most_common())
        sections.append(
            WikiSection(
                section_id="entity",
                video_id=video_id,
                section_type="entity",
                heading="Entities",
                content=entity_text,
                claims=_split_claims(entity_text),
                evidence_ids=evidence_ids,
                confidence=_avg_confidence(evidence),
                provenance={"source": "heuristic", "entities": dict(entities)},
            )
        )
    if objects:
        object_text = "; ".join(f"{name} appears {count} time(s)" for name, count in objects.most_common())
        sections.append(
            WikiSection(
                section_id="object",
                video_id=video_id,
                section_type="object",
                heading="Objects",
                content=object_text,
                claims=_split_claims(object_text),
                evidence_ids=evidence_ids,
                confidence=_avg_confidence(evidence),
                provenance={"source": "heuristic", "objects": dict(objects)},
            )
        )
    return sections


# --------------------------------------------------------------------------- rendering


def render_narrative_markdown(video_id: str, sections: list[WikiSection]) -> str:
    """Render the narrative wiki to Markdown (eq. 17): per-section heading / time / confidence /
    evidence / media / content, followed by an evidence→source provenance listing."""
    lines = [f"# Narrative Wiki: {video_id}", ""]
    for section in sections:
        lines.append(f"## {section.heading}")
        if section.start is not None or section.end is not None:
            lines.append(f"- Time: {_fmt_time(section.start)} - {_fmt_time(section.end)}")
        lines.append(f"- Confidence: {section.confidence:.2f}")
        if section.evidence_ids:
            lines.append(f"- Evidence: {', '.join(section.evidence_ids)}")
        media_paths = section.provenance.get("media_paths", [])
        if media_paths:
            lines.append(f"- Media: {', '.join(media_paths)}")
        lines.append("")
        lines.append(section.content)
        lines.append("")
    lines.extend(_provenance_lines(sections))
    return "\n".join(lines).rstrip() + "\n"


def _provenance_lines(sections: list[WikiSection]) -> list[str]:
    """Provenance section: each retained section mapped to its source evidence ids."""
    lines = ["## Provenance", ""]
    rows = False
    for section in sections:
        if not section.evidence_ids:
            continue
        rows = True
        source = section.provenance.get("source", "")
        suffix = f" ({source})" if isinstance(source, str) and source else ""
        lines.append(f"- {section.section_id}: {', '.join(section.evidence_ids)}{suffix}")
    if not rows:
        lines.append("- (no evidence-linked sections)")
    lines.append("")
    return lines


# --------------------------------------------------------------------------- shared helpers


def _evidence_digest(evidence: list[EvidenceUnit]) -> str:
    """Compact, id-tagged evidence listing for the narrative prompt (model cites these ids)."""
    lines: list[str] = []
    for unit in evidence:
        span = ""
        if unit.start is not None or unit.end is not None:
            span = f" [{_fmt_time(unit.start)}-{_fmt_time(unit.end)}]"
        text = unit.text.strip() or ", ".join(unit.objects + unit.entities + unit.actions)
        lines.append(f"- {unit.evidence_id} ({unit.modality.value}){span}: {text}".rstrip())
    return "\n".join(lines) if lines else "(no evidence)"


def _span_and_media(evidence: list[EvidenceUnit]) -> tuple[float | None, float | None, list[str]]:
    """Aggregate the time span and media paths of a section's linked evidence."""
    starts = [unit.start for unit in evidence if unit.start is not None]
    ends = [unit.end for unit in evidence if unit.end is not None]
    media_paths: list[str] = []
    for unit in evidence:
        media_paths.extend(unit.media_paths)
        if "snapshot_path" in unit.provenance:
            media_paths.append(str(unit.provenance["snapshot_path"]))
    return (min(starts) if starts else None, max(ends) if ends else None, media_paths)


def _summary_text(evidence: list[EvidenceUnit], entities: Counter, actions: Counter) -> str:
    texts = [unit.text.strip() for unit in evidence if unit.text.strip()]
    joined = " ".join(texts[:3]) if texts else "The video package contains visual evidence without transcript text."
    if entities:
        joined += f" Key entities include {', '.join(name for name, _ in entities.most_common(5))}."
    if actions:
        joined += f" Key actions include {', '.join(name for name, _ in actions.most_common(5))}."
    return joined


def _avg_confidence(evidence: list[EvidenceUnit]) -> float:
    if not evidence:
        return 0.0
    return sum(unit.confidence for unit in evidence) / len(evidence)


def _split_claims(text: str) -> list[str]:
    claims = [part.strip() for part in text.replace(";", ".").split(".") if part.strip()]
    return claims or ([text.strip()] if text.strip() else [])
