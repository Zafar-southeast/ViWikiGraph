"""Cross-modal evidence linking (paper v1 §III-C, eq. 20-21).

After the narrative and KG wikis are generated, this module connects their items to each other and to
the underlying multimodal evidence through a typed link set ``L``. Each link is a
:class:`~viwikigraph.core.schemas.CrossModalLink` λ = (a_i, a_j, ρ_λ, τ_λ, γ_λ, ξ_λ): a source item id,
a target item id, a :class:`~viwikigraph.core.schemas.LinkType`, the shared temporal range, a link
confidence, and provenance.

The linker is **deterministic and evidence-grounded**: links are created only when two items provably
share grounding evidence ids or overlap in time — faithful to the paper's "links are added only when
supported". An optional :class:`LLMClient` may *propose additional* links among already-existing items
(never inventing item ids); any failure degrades silently to the deterministic set, so the pipeline
runs offline (``--dry-run`` / no API key / unit tests).

The seven link types (eq. 20 ρ_λ):
  * ``CLAIM_TEXT``     narrative section/claim ↔ its subtitle/ASR/OCR evidence span
  * ``CLAIM_MEDIA``    narrative section ↔ a snapshot/clip it references
  * ``TRIPLE_EVIDENCE`` KG triple ↔ its supporting evidence unit
  * ``ENTITY_IMAGE``   entity/object KG item ↔ a representative image/snapshot
  * ``EVENT_CLIP``     event KG item ↔ an overlapping event clip
  * ``SECTION_TRIPLE`` narrative section ↔ a KG triple sharing evidence/time
  * ``TIME_ALIGN``     two items sharing a timestamp with no more-specific link
"""

from __future__ import annotations

from typing import Any

from viwikigraph.core.schemas import (
    CrossModalLink,
    EvidenceUnit,
    KGItem,
    LinkType,
    MediaItem,
    Modality,
    WikiSection,
)

# Evidence modalities that carry textual spans (CLAIM_TEXT / TRIPLE_EVIDENCE text targets).
_TEXT_MODALITIES = frozenset(
    {Modality.SUBTITLE, Modality.ASR, Modality.OCR, Modality.CAPTION}
)
# Media types treated as image-like vs clip-like for ENTITY_IMAGE / EVENT_CLIP.
_IMAGE_TYPES = frozenset({"image", "snapshot", "entity", "frame"})
_CLIP_TYPES = frozenset({"clip"})
# Per-item cap on TIME_ALIGN links to keep the set bounded (links are "added only when supported").
_MAX_TIME_ALIGN_PER_ITEM = 3


def build_cross_modal_links(
    video_id: str,
    sections: list[WikiSection],
    kg_items: list[KGItem],
    media_items: list[MediaItem],
    evidence_units: list[EvidenceUnit],
    llm: Any | None = None,
) -> list[CrossModalLink]:
    """Construct the typed cross-modal evidence link set ``L`` for one video (eq. 20-21).

    Deterministic, evidence-grounded. ``llm`` (when available) may propose extra links among existing
    item ids; failures fall back to the deterministic set. Returns links with stable ``link_{n}`` ids.
    """
    builder = _LinkBuilder(video_id, sections, kg_items, media_items, evidence_units)
    builder.claim_text_links()
    builder.triple_evidence_links()
    builder.claim_media_links()
    builder.entity_image_links()
    builder.event_clip_links()
    builder.section_triple_links()
    builder.time_align_links()
    if llm is not None and getattr(llm, "available", False):
        builder.llm_proposed_links(llm)
    return builder.links


class _LinkBuilder:
    """Accumulates de-duplicated :class:`CrossModalLink`s, indexing items for fast lookup."""

    def __init__(
        self,
        video_id: str,
        sections: list[WikiSection],
        kg_items: list[KGItem],
        media_items: list[MediaItem],
        evidence_units: list[EvidenceUnit],
    ) -> None:
        self.video_id = video_id
        self.sections = sections
        self.kg_items = kg_items
        self.media_items = media_items
        self.evidence_by_id = {unit.evidence_id: unit for unit in evidence_units}
        self.text_evidence_ids = {
            unit.evidence_id for unit in evidence_units if unit.modality in _TEXT_MODALITIES
        }
        self.media_by_id = {item.media_id: item for item in media_items}
        self.links: list[CrossModalLink] = []
        self._seen: set[tuple[str, str, str]] = set()

    # --- public per-type builders ----------------------------------------------------------- #
    def claim_text_links(self) -> None:
        """Section ↔ its subtitle/ASR/OCR evidence spans (eq. 20 CLAIM_TEXT)."""
        for section in self.sections:
            for eid in section.evidence_ids:
                if eid in self.text_evidence_ids:
                    self._add(section.section_id, eid, LinkType.CLAIM_TEXT, rule="section_evidence")

    def triple_evidence_links(self) -> None:
        """KG triple ↔ its supporting evidence unit (eq. 20 TRIPLE_EVIDENCE)."""
        for item in self.kg_items:
            if item.item_type != "triple" and not item.triples:
                continue
            for eid in item.evidence_ids:
                if eid in self.evidence_by_id:
                    self._add(item.item_id, eid, LinkType.TRIPLE_EVIDENCE, rule="triple_evidence")

    def claim_media_links(self) -> None:
        """Section ↔ a snapshot/clip it references via provenance or media linkage (CLAIM_MEDIA)."""
        media_by_path = {item.path: item for item in self.media_items}
        for section in self.sections:
            for path in section.provenance.get("media_paths", []):
                media = media_by_path.get(path)
                if media is not None:
                    self._add(section.section_id, media.media_id, LinkType.CLAIM_MEDIA, rule="section_media")
            for media in self.media_items:
                if media.linked_item_id == section.section_id:
                    self._add(section.section_id, media.media_id, LinkType.CLAIM_MEDIA, rule="media_linked_item")

    def entity_image_links(self) -> None:
        """Entity/object KG item ↔ a representative image/snapshot (ENTITY_IMAGE)."""
        for item in self.kg_items:
            if item.item_type not in {"entity", "object", "location"}:
                continue
            for media in self.media_items:
                if media.media_type in _IMAGE_TYPES and (
                    media.linked_item_id == item.item_id
                    or _shares_evidence(item.evidence_ids, media)
                ):
                    self._add(item.item_id, media.media_id, LinkType.ENTITY_IMAGE, rule="entity_image")

    def event_clip_links(self) -> None:
        """Event KG item ↔ an overlapping event clip (EVENT_CLIP)."""
        for item in self.kg_items:
            if item.item_type != "event":
                continue
            for media in self.media_items:
                if media.media_type in _CLIP_TYPES and (
                    media.linked_item_id == item.item_id
                    or _spans_overlap(item.start, item.end, media.start, media.end)
                ):
                    self._add(item.item_id, media.media_id, LinkType.EVENT_CLIP, rule="event_clip")

    def section_triple_links(self) -> None:
        """Narrative section ↔ a KG triple sharing evidence or overlapping in time (SECTION_TRIPLE)."""
        for section in self.sections:
            section_eids = set(section.evidence_ids)
            for item in self.kg_items:
                if item.item_type not in {"triple", "temporal_link"}:
                    continue
                shares = bool(section_eids & set(item.evidence_ids))
                overlaps = _spans_overlap(section.start, section.end, item.start, item.end)
                if shares or overlaps:
                    self._add(
                        section.section_id,
                        item.item_id,
                        LinkType.SECTION_TRIPLE,
                        rule="shared_evidence" if shares else "time_overlap",
                    )

    def time_align_links(self) -> None:
        """Time-align items that overlap in time but are not already linked (TIME_ALIGN).

        Bounded per item (``_MAX_TIME_ALIGN_PER_ITEM``) so the link set stays compact. Pairs a section
        with overlapping media/subtitle spans that no CLAIM_TEXT/CLAIM_MEDIA link already covers.
        """
        spanned_media = [m for m in self.media_items if m.start is not None or m.end is not None]
        spanned_text = [
            self.evidence_by_id[eid] for eid in self.text_evidence_ids
            if self.evidence_by_id[eid].start is not None or self.evidence_by_id[eid].end is not None
        ]
        for section in self.sections:
            if section.start is None and section.end is None:
                continue
            added = 0
            for media in spanned_media:
                if added >= _MAX_TIME_ALIGN_PER_ITEM:
                    break
                if _spans_overlap(section.start, section.end, media.start, media.end) and self._add(
                    section.section_id, media.media_id, LinkType.TIME_ALIGN, rule="time_overlap"
                ):
                    added += 1
            for unit in spanned_text:
                if added >= _MAX_TIME_ALIGN_PER_ITEM:
                    break
                if unit.evidence_id in section.evidence_ids:
                    continue  # already a CLAIM_TEXT link
                if _spans_overlap(section.start, section.end, unit.start, unit.end) and self._add(
                    section.section_id, unit.evidence_id, LinkType.TIME_ALIGN, rule="time_overlap"
                ):
                    added += 1

    def llm_proposed_links(self, llm: Any) -> None:
        """Optionally let the LLM propose extra links among EXISTING item ids (filtered, eq. 20).

        Conservative: only links whose source/target ids and link_type are recognized are accepted,
        and every accepted link is still tagged with deterministic provenance. Any failure is ignored.
        """
        try:
            from viwikigraph.llm.prompts import linking_prompt, parse_json

            known_ids = (
                {s.section_id for s in self.sections}
                | {k.item_id for k in self.kg_items}
                | set(self.media_by_id)
                | set(self.evidence_by_id)
            )
            digest = self._item_digest()
            response = llm.strict_json(linking_prompt(self.video_id, digest), cache_version="linking_v1")
            for raw in response.get("links", []) if isinstance(response, dict) else []:
                if not isinstance(raw, dict):
                    continue
                source = str(raw.get("source_id", "")).strip()
                target = str(raw.get("target_id", "")).strip()
                type_raw = str(raw.get("link_type", "")).strip().lower()
                if source not in known_ids or target not in known_ids or source == target:
                    continue
                try:
                    link_type = LinkType(type_raw)
                except ValueError:
                    continue
                self._add(source, target, link_type, rule="llm_proposed")
        except Exception:
            return

    # --- helpers ---------------------------------------------------------------------------- #
    def _add(self, source_id: str, target_id: str, link_type: LinkType, *, rule: str) -> bool:
        """Append a de-duplicated link; returns ``True`` when newly added."""
        key = (source_id, target_id, link_type.value)
        if key in self._seen:
            return False
        self._seen.add(key)
        start, end = self._shared_span(source_id, target_id)
        self.links.append(
            CrossModalLink(
                link_id=f"link_{len(self.links) + 1}",
                video_id=self.video_id,
                source_id=source_id,
                target_id=target_id,
                link_type=link_type,
                start=start,
                end=end,
                confidence=self._confidence(source_id, target_id),
                provenance={"rule": rule, "source": "cross_modal_linking"},
            )
        )
        return True

    def _endpoint_span(self, item_id: str) -> tuple[float | None, float | None]:
        if item_id in self.evidence_by_id:
            unit = self.evidence_by_id[item_id]
            return unit.start, unit.end
        if item_id in self.media_by_id:
            media = self.media_by_id[item_id]
            return media.start, media.end
        for section in self.sections:
            if section.section_id == item_id:
                return section.start, section.end
        for item in self.kg_items:
            if item.item_id == item_id:
                return item.start, item.end
        return None, None

    def _shared_span(self, source_id: str, target_id: str) -> tuple[float | None, float | None]:
        a_start, a_end = self._endpoint_span(source_id)
        b_start, b_end = self._endpoint_span(target_id)
        starts = [v for v in (a_start, b_start) if v is not None]
        ends = [v for v in (a_end, b_end) if v is not None]
        return (max(starts) if starts else None, min(ends) if ends else None)

    def _endpoint_confidence(self, item_id: str) -> float:
        if item_id in self.evidence_by_id:
            return self.evidence_by_id[item_id].confidence
        if item_id in self.media_by_id:
            return self.media_by_id[item_id].confidence
        for section in self.sections:
            if section.section_id == item_id:
                return section.confidence
        for item in self.kg_items:
            if item.item_id == item_id:
                return item.confidence
        return 0.5

    def _confidence(self, source_id: str, target_id: str) -> float:
        return round(min(self._endpoint_confidence(source_id), self._endpoint_confidence(target_id)), 3)

    def _item_digest(self) -> str:
        lines: list[str] = []
        for section in self.sections:
            lines.append(f"- [{section.section_id}] section: {section.heading}")
        for item in self.kg_items:
            lines.append(f"- [{item.item_id}] {item.item_type}: {item.label}")
        for media in self.media_items:
            lines.append(f"- [{media.media_id}] media({media.media_type}): {media.path}")
        return "\n".join(lines) if lines else "(no items)"


def _shares_evidence(evidence_ids: list[str], media: MediaItem) -> bool:
    linked = media.provenance.get("evidence_ids", []) if media.provenance else []
    return bool(set(evidence_ids) & set(linked)) or media.linked_item_id in evidence_ids


def _spans_overlap(
    a_start: float | None,
    a_end: float | None,
    b_start: float | None,
    b_end: float | None,
) -> bool:
    """True when two [start, end] spans overlap. Items lacking any time do not time-align."""
    if (a_start is None and a_end is None) or (b_start is None and b_end is None):
        return False
    a_lo = a_start if a_start is not None else a_end
    a_hi = a_end if a_end is not None else a_start
    b_lo = b_start if b_start is not None else b_end
    b_hi = b_end if b_end is not None else b_start
    return a_lo <= b_hi and b_lo <= a_hi


def render_links_section(links: list[CrossModalLink]) -> list[str]:
    """Render the cross-modal evidence-link table for ``kg_wiki.md`` (eq. 21)."""
    lines = [
        "## Cross-Modal Evidence Links",
        "",
        "| ID | Type | Source | Target | Time | Confidence | Provenance |",
        "| --- | --- | --- | --- | --- | --- | --- |",
    ]
    for link in links:
        time = _fmt_span(link.start, link.end)
        rule = str(link.provenance.get("rule", "")) if link.provenance else ""
        lines.append(
            f"| {link.link_id} | {link.link_type.value} | {link.source_id} | {link.target_id} | "
            f"{time} | {link.confidence:.2f} | {rule} |"
        )
    if not links:
        lines.append("| (none) | - | - | - | - | - | - |")
    return lines


def _fmt_span(start: float | None, end: float | None) -> str:
    if start is None and end is None:
        return "-"
    s = "?" if start is None else f"{start:g}"
    e = "?" if end is None else f"{end:g}"
    return f"{s}-{e}"
