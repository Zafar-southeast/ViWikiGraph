"""Phase D — evidence validation (paper §IV, eq. 15, 25-27).

Deterministic, offline-first validation of wiki items (narrative claims / sections and KG items)
against their grounding :class:`EvidenceUnit`s. No network or API key is required: every signal is
computed from token / entity / temporal / visual overlap. An optional LLM-entailment refinement is
available behind a flag but is **off by default** so tests and ``--dry-run`` are fully deterministic.

Public surface (consumed by ``pipeline.py`` and the wiki/kg builders):
  - :func:`support_score`  — eq. 15 support signal: weighted textual + entity/event + temporal +
    visual-grounding overlap, returning the scalar support and the supporting evidence ids.
  - :func:`validate_item`  — fills the 5-dim quality vector ``[support, provenance, consistency,
    coverage, media]`` (eq. 25), scores it via :attr:`ValidationResult.score` (eq. 26) and decides
    keep / revise / flag against thresholds (eq. 27).
  - :func:`detect_conflicts` — surfaces non-kept items for the conflict log.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from viwikigraph.core.schemas import CrossModalLink, EvidenceUnit, Modality, ValidationResult
from viwikigraph.core.text import tokens as _tokens
from viwikigraph.core.text import words as _word_list


# Eq. 11 — β weights over the support sub-signals supp_u = β1 e_text + β2 e_ent + β3 e_time + β4 e_vis.
# Textual entailment dominates; entity/event, temporal compatibility and visual grounding refine it.
# Fixed (NOT learned) — RAG-only / no-training constraint. Σβ = 1 so support stays in [0, 1].
SUPPORT_WEIGHTS: dict[str, float] = {
    "textual": 0.45,
    "entity_event": 0.25,
    "temporal": 0.15,
    "visual": 0.15,
}

# Modalities whose grounding is primarily visual (drive the visual-grounding sub-signal e_vis).
_VISUAL_MODALITIES = frozenset({Modality.VISUAL_CONCEPT, Modality.FRAME, Modality.SNAPSHOT,
                                Modality.CLIP, Modality.CAPTION, Modality.OCR})

# Eq. 24 — decision bands on the scalar quality score Q(z). Fixed thresholds (not learned).
KEEP_THRESHOLD = 0.5
TAU_Z = KEEP_THRESHOLD  # eq. 24 retention threshold τ_z (alias)
REVISE_THRESHOLD = 0.3


@dataclass(slots=True)
class _Signals:
    """Per-evidence-unit support sub-signals and their weighted combination (eq. 15)."""

    textual: float
    entity_event: float
    temporal: float
    visual: float

    @property
    def support(self) -> float:
        return (
            SUPPORT_WEIGHTS["textual"] * self.textual
            + SUPPORT_WEIGHTS["entity_event"] * self.entity_event
            + SUPPORT_WEIGHTS["temporal"] * self.temporal
            + SUPPORT_WEIGHTS["visual"] * self.visual
        )


def support_score(text: str, evidence: list[EvidenceUnit], *, llm: object | None = None) -> tuple[float, list[str]]:
    """Eq. 10-11 support signal for a claim/item ``text`` against its grounding ``evidence``.

    Eq. 10 takes the outer max over BOTH unit-level support (eq. 11 supp_u, a weighted blend of
    textual entailment, entity/event overlap, temporal compatibility, and visual grounding) AND
    fact-level support supp_f over the structured ``EvidenceUnit.facts`` triples. Returns the best
    support found and the supporting evidence ids (most-supportive first). ``llm`` (optional, off by
    default) refines the textual-entailment sub-signal; everything is deterministic when ``llm`` is
    ``None``. With no evidence/claim the support is ``0.0`` and the supporting set empty.
    """
    best, supporting, _signals = _support_with_signals(text, evidence)
    if llm is not None and best > 0.0:
        best = _llm_refined_support(text, evidence, supporting, best, llm)
    return best, supporting


def _support_with_signals(
    text: str,
    evidence: list[EvidenceUnit],
) -> tuple[float, list[str], dict[str, float]]:
    """Core of :func:`support_score` (eq. 10-11) returning ``(best, supporting_ids, signals)``.

    ``signals`` carries the eq. 11 sub-signals of the best-supporting unit plus an ``e_ocr`` term (max
    textual entailment over OCR-modality units) for persistence on :class:`ValidationResult`.
    """
    claim_tokens = _tokens(text)
    if not evidence or not claim_tokens:
        return 0.0, [], {}

    scored: list[tuple[float, str]] = []
    best = 0.0
    best_signals = _Signals(0.0, 0.0, 0.0, 0.0)
    e_ocr = 0.0
    for unit in evidence:
        signals = _unit_signals(text, claim_tokens, unit)
        support = signals.support
        if support > best:
            best = support
            best_signals = signals
        if support > 0.0:
            scored.append((support, unit.evidence_id))
        if unit.modality == Modality.OCR:
            e_ocr = max(e_ocr, _textual_entailment(claim_tokens, _tokens(unit.text), text, unit.text))

    # Eq. 10 fact-level term: max over the structured facts of the assigned evidence.
    fact_best, fact_unit_id = _best_fact_support(text, claim_tokens, evidence)

    scored.sort(key=lambda pair: pair[0], reverse=True)
    floor = max(0.15, best * 0.5)
    supporting: list[str] = []
    for support, evidence_id in scored:
        if support >= floor and evidence_id not in supporting:
            supporting.append(evidence_id)
    # When fact-level support wins (or no unit met the floor), credit the unit carrying the fact.
    if fact_best > best and fact_unit_id and fact_unit_id not in supporting:
        supporting.insert(0, fact_unit_id)
    if not supporting and scored:
        supporting.append(scored[0][1])
    elif not supporting and fact_unit_id:
        supporting.append(fact_unit_id)

    best = max(best, fact_best)
    signals = {
        "e_text": round(best_signals.textual, 3),
        "e_ent": round(best_signals.entity_event, 3),
        "e_time": round(best_signals.temporal, 3),
        "e_vis": round(best_signals.visual, 3),
        "e_ocr": round(e_ocr, 3),
        "e_fact": round(fact_best, 3),
    }
    return round(best, 3), supporting, signals


def _best_fact_support(
    text: str,
    claim_tokens: set[str],
    evidence: list[EvidenceUnit],
) -> tuple[float, str]:
    """Eq. 10 fact-level term: best supp_f over the (h, r, o) facts of the assigned evidence."""
    best = 0.0
    best_unit = ""
    for unit in evidence:
        for fact in unit.facts:
            score = _fact_support(claim_tokens, fact)
            if score > best:
                best = score
                best_unit = unit.evidence_id
    return best, best_unit


def _fact_support(claim_tokens: set[str], fact: tuple[str, str, str]) -> float:
    """Score a claim against one structured fact (h, r, o) by token overlap (eq. 10 supp_f).

    Requires ≥2 of {head, relation, tail} to share a token with the claim before contributing, so a
    claim merely sharing an entity with an unrelated fact is not over-credited.
    """
    head, relation, obj = fact
    components = [_tokens(head), _tokens(relation), _tokens(obj)]
    hits = sum(1 for comp in components if comp and (comp & claim_tokens))
    if hits < 2:
        return 0.0
    fact_tokens = components[0] | components[1] | components[2]
    if not fact_tokens:
        return 0.0
    return min(1.0, len(fact_tokens & claim_tokens) / len(fact_tokens))


def validate_item(
    item_id: str,
    item_type: str,
    text: str,
    evidence: list[EvidenceUnit],
    media_paths: Iterable[str | Path] = (),
    threshold: float = TAU_Z,
    *,
    grounded_items: list[tuple[str, list[EvidenceUnit]]] | None = None,
    links: list[CrossModalLink] | None = None,
    llm: object | None = None,
) -> ValidationResult:
    """Validate one wiki item, returning its 6-dim quality vector and keep/revise/flag decision.

    The vector (eq. 22) is ``[support, provenance, consistency, coverage, media, link]``:
      * **support**    — eq. 10-11 via :func:`support_score` (unit + fact outer max).
      * **provenance** — fraction of supporting units carrying non-empty provenance metadata.
      * **consistency**— 1.0 unless this item conflicts with another *grounded* item in
        ``grounded_items`` (negation / numeric / OCR mismatch), in which case a penalty is applied.
      * **coverage**   — fraction of available evidence units that support the item.
      * **media**      — fraction of referenced media paths that exist on disk (1.0 when none).
      * **link**       — mean quality of the cross-modal links incident on this item (1.0 when none).

    ``Q(z)`` is the weighted sum (eq. 23, weights live in :attr:`ValidationResult.score`); the
    decision (eq. 24) is ``keep`` ≥ ``threshold``, else ``revise`` ≥ :data:`REVISE_THRESHOLD`, else
    ``flag``. ``links`` (incident or full link set; filtered by item id) drives q_link.
    ``support_signals`` persists the eq. 11 β sub-signals (incl. ``e_ocr``); ``unsupported_span``
    scopes a span-restricted Revise (eq. 25) when the item is not kept. ``llm`` optionally refines the
    support signal but is unused by default so the path stays deterministic and offline.
    """
    support, supporting, signals = _support_with_signals(text, evidence)
    if llm is not None and support > 0.0:
        support = _llm_refined_support(text, evidence, supporting, support, llm)

    supporting_units = [unit for unit in evidence if unit.evidence_id in supporting]
    provenance_score = (
        sum(1 for unit in supporting_units if unit.provenance) / len(supporting_units)
        if supporting_units
        else (1.0 if any(unit.provenance for unit in evidence) else 0.0)
    )

    consistency_score, conflict_note = _consistency(text, evidence, grounded_items)
    coverage_score = len(supporting) / len(evidence) if evidence else 0.0

    media_list = [Path(path) for path in media_paths]
    media_score = (
        1.0 if not media_list else sum(1 for path in media_list if path.exists()) / len(media_list)
    )

    link_score = _incident_link_quality(item_id, links)

    result = ValidationResult(
        item_id=item_id,
        item_type=item_type,
        support=round(support, 3),
        provenance=round(provenance_score, 3),
        consistency=round(consistency_score, 3),
        coverage=round(coverage_score, 3),
        media=round(media_score, 3),
        decision="keep",
        link=round(link_score, 3),
        evidence_ids=supporting,
        support_signals=signals,
    )

    decision = _decide(result.score, threshold)
    result.decision = decision
    result.notes = _notes(decision, threshold, conflict_note)
    # Eq. 25 — scope a span-restricted Revise only when the item is not kept.
    if decision != "keep":
        result.unsupported_span = _unsupported_span(text, evidence)
    return result


def validate_link(
    link: CrossModalLink,
    items_by_id: dict[str, object],
    evidence_by_id: dict[str, EvidenceUnit],
    *,
    llm: object | None = None,
) -> ValidationResult:
    """Validate a single cross-modal link λ as a candidate item z (eq. 22, item_type='cross_modal_link').

    q_link (the link's primary score) = mean(compatible endpoints + endpoint-text overlap, timestamp
    alignment of τ_λ with the endpoints' spans, non-empty provenance ξ_λ). q_sup = link confidence
    γ_λ; q_prov = provenance present; q_cons = endpoints not mutually contradictory; q_cov/q_media are
    neutral (1.0). Deterministic; ``llm`` may refine endpoint compatibility but is unused by default.
    """
    quality, note = _link_quality(link, items_by_id, evidence_by_id)
    prov = 1.0 if link.provenance else 0.0
    consistency = 1.0  # endpoint contradiction would be surfaced at item level; links are additive
    result = ValidationResult(
        item_id=link.link_id,
        item_type="cross_modal_link",
        support=round(link.confidence, 3),
        provenance=prov,
        consistency=consistency,
        coverage=1.0,
        media=1.0,
        decision="keep",
        link=round(quality, 3),
        evidence_ids=[link.source_id, link.target_id],
        notes=note,
    )
    result.decision = _decide(result.score, TAU_Z)
    if result.decision != "keep" and not result.notes:
        result.notes = "Cross-modal link below keep threshold."
    return result


def detect_conflicts(validations: list[ValidationResult]) -> list[dict]:
    """Return the non-kept validations as conflict-log records (revise/flag items)."""
    return [
        {
            "item_id": item.item_id,
            "item_type": item.item_type,
            "decision": item.decision,
            "score": item.score,
            "notes": item.notes,
        }
        for item in validations
        if item.decision != "keep"
    ]


def _unit_signals(text: str, claim_tokens: set[str], unit: EvidenceUnit) -> _Signals:
    """Compute the four eq.-15 sub-signals of ``text`` against a single evidence ``unit``."""
    unit_text_tokens = _tokens(" ".join([unit.text, *unit.actions]))
    textual = _textual_entailment(claim_tokens, unit_text_tokens, text, unit.text)

    entity_event_tokens = _tokens(" ".join([*unit.entities, *unit.objects, *unit.events]))
    entity_event = _jaccard_recall(claim_tokens, entity_event_tokens)

    temporal = _temporal_compatibility(unit)

    visual = 0.0
    if unit.modality in _VISUAL_MODALITIES:
        visual_tokens = _tokens(" ".join([*unit.objects, *unit.entities]))
        # Concept/bbox overlap; fall back to the unit's own text for caption/OCR modalities.
        if not visual_tokens:
            visual_tokens = unit_text_tokens
        visual = _jaccard_recall(claim_tokens, visual_tokens)

    return _Signals(textual=textual, entity_event=entity_event, temporal=temporal, visual=visual)


def _textual_entailment(claim_tokens: set[str], unit_tokens: set[str], claim: str, unit_text: str) -> float:
    """Token recall blended with a contiguous-sequence (substring) bonus."""
    if not claim_tokens:
        return 0.0
    recall = len(claim_tokens & unit_tokens) / len(claim_tokens)
    sequence = _sequence_overlap(claim, unit_text)
    return min(1.0, 0.7 * recall + 0.3 * sequence)


def _sequence_overlap(claim: str, unit_text: str) -> float:
    """Length of the longest claim token-run that appears verbatim in the unit text, normalized."""
    claim_words = _word_list(claim)
    if not claim_words:
        return 0.0
    unit_lower = " " + " ".join(_word_list(unit_text)) + " "
    longest = 0
    for start in range(len(claim_words)):
        run: list[str] = []
        for word in claim_words[start:]:
            candidate = run + [word]
            if f" {' '.join(candidate)} " in unit_lower:
                run = candidate
                longest = max(longest, len(run))
            else:
                break
    return min(1.0, longest / len(claim_words))


def _jaccard_recall(claim_tokens: set[str], other_tokens: set[str]) -> float:
    """Recall of claim tokens present in ``other_tokens`` (0 when either side is empty)."""
    if not claim_tokens or not other_tokens:
        return 0.0
    return len(claim_tokens & other_tokens) / len(claim_tokens)


def _temporal_compatibility(unit: EvidenceUnit) -> float:
    """1.0 when the unit carries a coherent time span, else a neutral 0.5 (no span ≠ conflict)."""
    if unit.start is None and unit.end is None:
        return 0.5
    if unit.start is not None and unit.end is not None and unit.end < unit.start:
        return 0.0
    return 1.0


# --- cross-modal link quality (eq. 22 q_link) ------------------------------------------------


def _link_self_quality(link: CrossModalLink) -> float:
    """Self-contained quality of one cross-modal link from its own fields (provenance, confidence,
    temporal coherence). Used for an item's q_link without needing the endpoint objects."""
    provenanced = 1.0 if link.provenance else 0.0
    confidence = max(0.0, min(1.0, link.confidence))
    if link.start is not None and link.end is not None:
        coherent = 1.0 if link.end >= link.start else 0.0
    else:
        coherent = 1.0  # no/partial span is not a conflict (graceful, e.g. NExT-QA)
    return (provenanced + confidence + coherent) / 3.0


def _incident_link_quality(item_id: str, links: list[CrossModalLink] | None) -> float:
    """Mean quality of the cross-modal links incident on ``item_id`` (1.0 when none — eq. 22 q_link)."""
    if not links:
        return 1.0
    incident = [link for link in links if link.source_id == item_id or link.target_id == item_id]
    if not incident:
        return 1.0
    return sum(_link_self_quality(link) for link in incident) / len(incident)


def _link_quality(
    link: CrossModalLink,
    items_by_id: dict[str, object],
    evidence_by_id: dict[str, EvidenceUnit],
) -> tuple[float, str]:
    """Full q_link for :func:`validate_link`: mean(compatible+overlap, timestamp-aligned, provenanced).

    ``compatible`` = both endpoints resolve AND their texts share a token; ``aligned`` = τ_λ overlaps
    both endpoints' spans (1.0 when neither carries a span — graceful); ``provenanced`` = ξ_λ present.
    """
    src = _resolve_endpoint(link.source_id, items_by_id, evidence_by_id)
    tgt = _resolve_endpoint(link.target_id, items_by_id, evidence_by_id)
    if src is None or tgt is None:
        return 0.5 * (1.0 if link.provenance else 0.0) + 0.25, "Unresolved link endpoint."
    src_text, src_start, src_end = src
    tgt_text, tgt_start, tgt_end = tgt
    overlap = _tokens(src_text) & _tokens(tgt_text)
    compatible = 1.0 if overlap else 0.5  # both exist → at least partially compatible
    aligned = _temporal_alignment((link.start, link.end), (src_start, src_end), (tgt_start, tgt_end))
    provenanced = 1.0 if link.provenance else 0.0
    quality = (compatible + aligned + provenanced) / 3.0
    note = "" if quality >= TAU_Z else "Weak cross-modal link (low compatibility/alignment/provenance)."
    return quality, note


def _resolve_endpoint(
    item_id: str,
    items_by_id: dict[str, object],
    evidence_by_id: dict[str, EvidenceUnit],
) -> tuple[str, float | None, float | None] | None:
    """Resolve a link endpoint id to ``(text, start, end)`` from evidence or wiki items (duck-typed)."""
    if item_id in evidence_by_id:
        unit = evidence_by_id[item_id]
        return unit.text, unit.start, unit.end
    obj = items_by_id.get(item_id)
    if obj is None:
        return None
    text = (
        getattr(obj, "content", None)
        or getattr(obj, "label", None)
        or getattr(obj, "description", None)
        or getattr(obj, "path", "")
        or ""
    )
    return str(text), getattr(obj, "start", None), getattr(obj, "end", None)


def _temporal_alignment(
    link_span: tuple[float | None, float | None],
    a_span: tuple[float | None, float | None],
    b_span: tuple[float | None, float | None],
) -> float:
    """1.0 when the link's τ_λ overlaps both endpoints' spans; graceful 1.0 when spans are absent."""
    return min(_span_overlap(link_span, a_span), _span_overlap(link_span, b_span))


def _span_overlap(
    a: tuple[float | None, float | None],
    b: tuple[float | None, float | None],
) -> float:
    a_lo, a_hi = a
    b_lo, b_hi = b
    if (a_lo is None and a_hi is None) or (b_lo is None and b_hi is None):
        return 1.0  # no span on one side → not a misalignment
    a_lo = a_lo if a_lo is not None else a_hi
    a_hi = a_hi if a_hi is not None else a_lo
    b_lo = b_lo if b_lo is not None else b_hi
    b_hi = b_hi if b_hi is not None else b_lo
    return 1.0 if (a_lo <= b_hi and b_lo <= a_hi) else 0.0


def _unsupported_span(text: str, evidence: list[EvidenceUnit]) -> str:
    """Lowest-supported atomic claim/sentence within ``text`` (eq. 25 Revise scope). Deterministic."""
    spans = [part.strip() for part in re.split(r"[.;]", text) if part.strip()]
    if len(spans) <= 1:
        return text.strip()
    worst_span = spans[0]
    worst_score = 2.0
    for span in spans:
        score, _ = support_score(span, evidence)
        if score < worst_score:
            worst_score = score
            worst_span = span
    return worst_span


def _consistency(
    text: str,
    evidence: list[EvidenceUnit],
    grounded_items: list[tuple[str, list[EvidenceUnit]]] | None,
) -> tuple[float, str]:
    """Detect conflicts that lower q_cons (eq. 22): OCR contradictions on the assigned evidence and
    negation/numeric mismatches with other grounded items sharing evidence."""
    claim_tokens = _tokens(text)
    # OCR-consistency: an OCR-modality unit whose text negation/numerically contradicts the claim.
    for unit in evidence:
        if unit.modality == Modality.OCR and unit.text and _conflicts(
            claim_tokens, text, _tokens(unit.text), unit.text
        ):
            return 0.3, f"Conflicts with OCR evidence {unit.evidence_id}."
    if not grounded_items:
        return 1.0, ""
    evidence_ids = {unit.evidence_id for unit in evidence}
    for other_text, other_evidence in grounded_items:
        if other_text == text:
            continue
        shared = evidence_ids & {unit.evidence_id for unit in other_evidence}
        if not shared:
            continue
        if _conflicts(claim_tokens, text, _tokens(other_text), other_text):
            return 0.3, f"Conflicts with grounded item sharing evidence {sorted(shared)}."
    return 1.0, ""


def _conflicts(a_tokens: set[str], a_text: str, b_tokens: set[str], b_text: str) -> bool:
    """Heuristic conflict test: shared subject context with a negation or numeric mismatch."""
    overlap = a_tokens & b_tokens
    if len(overlap) < 2:
        return False
    a_neg = bool(_NEGATIONS & a_tokens)
    b_neg = bool(_NEGATIONS & b_tokens)
    if a_neg != b_neg:
        return True
    a_nums = _numbers(a_text)
    b_nums = _numbers(b_text)
    if a_nums and b_nums and a_nums != b_nums:
        return True
    return False


def _decide(score: float, threshold: float) -> str:
    """Map the scalar quality score to keep/revise/flag (eq. 27)."""
    if score >= threshold:
        return "keep"
    if score >= REVISE_THRESHOLD:
        return "revise"
    return "flag"


def _notes(decision: str, threshold: float, conflict_note: str) -> str:
    """Compose the human-readable validation note."""
    parts: list[str] = []
    if conflict_note:
        parts.append(conflict_note)
    if decision == "revise":
        parts.append(f"Validation score below keep threshold {threshold:.2f}; flagged for revision.")
    elif decision == "flag":
        parts.append("Validation score below revise threshold; insufficient grounding.")
    return " ".join(parts)


def _llm_refined_support(
    text: str,
    evidence: list[EvidenceUnit],
    supporting: list[str],
    deterministic: float,
    llm: object,
) -> float:
    """Optional LLM-entailment refinement of the support signal (off by default).

    Averages the deterministic support with an LLM verdict when ``llm`` exposes a usable, *available*
    ``strict_json`` interface; any failure (no key, offline, malformed output) silently keeps the
    deterministic value so the offline contract holds.
    """
    if not getattr(llm, "available", False) or not hasattr(llm, "strict_json"):
        return deterministic
    try:
        from viwikigraph.llm.prompts import verification_prompt

        digest = "\n".join(
            f"[{unit.evidence_id}] {unit.text}" for unit in evidence if unit.evidence_id in supporting
        )
        data = llm.strict_json(verification_prompt(text, text, [text], digest))  # type: ignore[attr-defined]
        verdicts = [str(claim.get("verdict", "")) for claim in data.get("claims", []) if isinstance(claim, dict)]
        if not verdicts:
            return deterministic
        score = sum(1.0 if v == "sup" else 0.0 if v == "unsup" else -1.0 for v in verdicts) / len(verdicts)
        llm_support = max(0.0, min(1.0, (score + 1.0) / 2.0))
        return round(0.5 * deterministic + 0.5 * llm_support, 3)
    except Exception:
        return deterministic


_NEGATIONS = frozenset({"no", "not", "never", "none", "without", "cannot", "isn", "wasn", "didn", "doesn"})


def _numbers(text: str) -> set[str]:
    return set(re.findall(r"\d+", text))
