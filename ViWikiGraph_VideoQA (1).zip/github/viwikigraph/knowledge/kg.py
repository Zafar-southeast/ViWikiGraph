"""Phase 3 — KG wiki construction and rendering (paper §IV-D, eq. 18-24).

`build_kg_items` turns the per-video evidence and narrative sections into a typed knowledge graph:
entities (eq. 20), events (eq. 21), relation triples (eq. 22), temporal links
(``BEFORE|AFTER|DURING``), and contradiction links (only between two grounded, conflicting items).

When an :class:`~viwikigraph.llm.client.LLMClient` is supplied (and a cached/live response is available) the
graph is extracted with :func:`viwikigraph.llm.prompts.kg_prompt`; otherwise a fully deterministic
fallback (entity aggregation + fact triples + consecutive-scene ``BEFORE`` links) runs so the
pipeline works offline / under ``--dry-run`` with no API key or network.
"""

from __future__ import annotations

from collections import OrderedDict
from typing import Any

from viwikigraph.llm.client import LLMClient
from viwikigraph.llm.prompts import kg_prompt
from viwikigraph.core.schemas import CrossModalLink, EvidenceUnit, KGItem, RelationTriple, WikiSection
from viwikigraph.knowledge.linking import render_links_section
from viwikigraph.core.text import fmt_time as _fmt_time

_TEMPORAL_RELATIONS = ("BEFORE", "AFTER", "DURING")


def build_kg_items(
    video_id: str,
    evidence: list[EvidenceUnit],
    sections: list[WikiSection],
    llm: LLMClient | None = None,
) -> list[KGItem]:
    """Build the KG wiki for ``video_id`` (eq. 18-24).

    LLM path: one :func:`kg_prompt` call producing entities/events/triples/temporal_links/
    contradiction_links, each citing real ``EvidenceUnit.evidence_id``s. Deterministic fallback:
    entity aggregation + fact triples + consecutive-scene ``BEFORE`` links. Any LLM failure (no key,
    no network, malformed JSON) degrades silently to the fallback.
    """
    if llm is not None:
        try:
            items = _llm_kg_items(video_id, evidence, sections, llm)
            if items:
                return items
        except Exception:
            pass
    return _fallback_kg_items(video_id, evidence, sections)


# --------------------------------------------------------------------------------------------------
# LLM path
# --------------------------------------------------------------------------------------------------
def _llm_kg_items(
    video_id: str,
    evidence: list[EvidenceUnit],
    sections: list[WikiSection],
    llm: LLMClient,
) -> list[KGItem]:
    """Extract typed KG items via :func:`kg_prompt`; drop items citing unknown evidence ids."""
    prompt = kg_prompt(video_id, _evidence_digest(evidence), _narrative_digest(sections))
    response = llm.strict_json(prompt, cache_version="kg_v1")

    valid_ids = {unit.evidence_id for unit in evidence}
    evidence_by_id = {unit.evidence_id: unit for unit in evidence}
    items: list[KGItem] = []
    counters: dict[str, int] = {}

    def _next_id(prefix: str) -> str:
        counters[prefix] = counters.get(prefix, 0) + 1
        return f"{prefix}_{counters[prefix]}"

    for raw in _as_list(response.get("entities")):
        label = _clean(raw.get("label") or raw.get("entity") or raw.get("name"))
        if not label:
            continue
        item_type = _normalize_entity_type(raw.get("type"))
        eids = _filter_ids(raw.get("evidence_ids"), valid_ids)
        items.append(
            KGItem(
                item_id=_next_id(item_type),
                video_id=video_id,
                item_type=item_type,
                label=label,
                description=_clean(raw.get("description")) or f"{label} appears in the video evidence.",
                evidence_ids=eids,
                start=_min_start(eids, evidence_by_id),
                end=_max_end(eids, evidence_by_id),
                confidence=_evidence_confidence(eids, evidence_by_id),
                provenance={"source": "llm_kg", "evidence_ids": eids},
            )
        )

    for raw in _as_list(response.get("events")):
        label = _clean(raw.get("label") or raw.get("event"))
        if not label:
            continue
        eids = _filter_ids(raw.get("evidence_ids"), valid_ids)
        participants = [p for p in (_clean(x) for x in _as_list(raw.get("participants"))) if p]
        description = _clean(raw.get("description")) or label
        items.append(
            KGItem(
                item_id=_next_id("event"),
                video_id=video_id,
                item_type="event",
                label=label,
                description=description,
                evidence_ids=eids,
                start=_min_start(eids, evidence_by_id),
                end=_max_end(eids, evidence_by_id),
                confidence=_evidence_confidence(eids, evidence_by_id),
                provenance={"source": "llm_kg", "participants": participants, "evidence_ids": eids},
            )
        )

    for raw in _as_list(response.get("triples")):
        subject = _clean(raw.get("subject"))
        relation = _clean(raw.get("relation"))
        obj = _clean(raw.get("object"))
        if not (subject and relation and obj):
            continue
        eids = _filter_ids(raw.get("evidence_ids"), valid_ids)
        start = _min_start(eids, evidence_by_id)
        end = _max_end(eids, evidence_by_id)
        confidence = _evidence_confidence(eids, evidence_by_id)
        triple = RelationTriple(
            subject=subject,
            relation=relation,
            object=obj,
            start=start,
            end=end,
            confidence=confidence,
            evidence_ids=eids,
            provenance={"source": "llm_kg"},
        )
        items.append(
            KGItem(
                item_id=_next_id("triple"),
                video_id=video_id,
                item_type="triple",
                label=f"{subject} {relation} {obj}",
                description=f"{subject} {relation} {obj}",
                triples=[triple],
                evidence_ids=eids,
                start=start,
                end=end,
                confidence=confidence,
                provenance={"source": "llm_kg"},
            )
        )

    for raw in _as_list(response.get("temporal_links")):
        before = _clean(raw.get("before") or raw.get("item_a"))
        after = _clean(raw.get("after") or raw.get("item_b"))
        if not (before and after):
            continue
        relation = _normalize_temporal_relation(raw.get("relation"))
        eids = _filter_ids(raw.get("evidence_ids"), valid_ids)
        start = _min_start(eids, evidence_by_id)
        end = _max_end(eids, evidence_by_id)
        confidence = _evidence_confidence(eids, evidence_by_id)
        items.append(
            KGItem(
                item_id=_next_id("temporal"),
                video_id=video_id,
                item_type="temporal_link",
                label=f"{before} {relation} {after}",
                description=f"{before} {relation.lower()} {after}.",
                triples=[
                    RelationTriple(
                        subject=before,
                        relation=relation,
                        object=after,
                        start=start,
                        end=end,
                        confidence=confidence,
                        evidence_ids=eids,
                        provenance={"source": "llm_kg"},
                    )
                ],
                evidence_ids=eids,
                start=start,
                end=end,
                confidence=confidence,
                provenance={"source": "llm_kg", "relation": relation},
            )
        )

    for raw in _as_list(response.get("contradiction_links")):
        item_a = _clean(raw.get("item_a") or raw.get("before"))
        item_b = _clean(raw.get("item_b") or raw.get("after"))
        if not (item_a and item_b):
            continue
        reason = _clean(raw.get("reason"))
        eids = _filter_ids(raw.get("evidence_ids"), valid_ids)
        items.append(
            KGItem(
                item_id=_next_id("contradiction"),
                video_id=video_id,
                item_type="contradiction_link",
                label=f"{item_a} CONTRADICTS {item_b}",
                description=reason or f"{item_a} conflicts with {item_b}.",
                triples=[
                    RelationTriple(
                        subject=item_a,
                        relation="CONTRADICTS",
                        object=item_b,
                        confidence=_evidence_confidence(eids, evidence_by_id),
                        evidence_ids=eids,
                        provenance={"source": "llm_kg"},
                    )
                ],
                evidence_ids=eids,
                confidence=_evidence_confidence(eids, evidence_by_id),
                provenance={"source": "llm_kg", "reason": reason},
            )
        )

    return items


def _evidence_digest(evidence: list[EvidenceUnit]) -> str:
    """Compact, id-tagged listing of evidence for grounding the KG extraction prompt."""
    lines: list[str] = []
    for unit in evidence:
        parts: list[str] = []
        if unit.text.strip():
            parts.append(unit.text.strip())
        if unit.entities:
            parts.append(f"entities={', '.join(unit.entities)}")
        if unit.objects:
            parts.append(f"objects={', '.join(unit.objects)}")
        if unit.actions:
            parts.append(f"actions={', '.join(unit.actions)}")
        if unit.events:
            parts.append(f"events={', '.join(unit.events)}")
        time = _fmt_window(unit.start, unit.end)
        lines.append(f"- [{unit.evidence_id}] ({unit.modality.value}{time}) {' | '.join(parts)}".rstrip())
    return "\n".join(lines) if lines else "(no evidence)"


def _narrative_digest(sections: list[WikiSection]) -> str:
    """Compact listing of narrative sections (heading + content) for KG-prompt context."""
    lines = [f"- [{s.section_id}] {s.heading}: {s.content}".strip() for s in sections]
    return "\n".join(lines) if lines else "(no narrative)"


# --------------------------------------------------------------------------------------------------
# Deterministic fallback (no LLM)
# --------------------------------------------------------------------------------------------------
def _fallback_kg_items(
    video_id: str,
    evidence: list[EvidenceUnit],
    sections: list[WikiSection],
) -> list[KGItem]:
    """Entity aggregation + fact triples + consecutive-scene ``BEFORE`` links (no LLM)."""
    items: list[KGItem] = []
    entity_evidence: OrderedDict[str, list[EvidenceUnit]] = OrderedDict()
    triples: list[RelationTriple] = []

    for unit in evidence:
        for entity in unit.entities + unit.objects:
            entity_evidence.setdefault(entity, []).append(unit)
        for subject, relation, obj in unit.facts:
            triples.append(
                RelationTriple(
                    subject=subject,
                    relation=relation,
                    object=obj,
                    start=unit.start,
                    end=unit.end,
                    confidence=unit.confidence,
                    evidence_ids=[unit.evidence_id],
                    provenance=unit.provenance,
                )
            )

    for index, (entity, linked) in enumerate(entity_evidence.items(), start=1):
        evidence_ids = [unit.evidence_id for unit in linked]
        items.append(
            KGItem(
                item_id=f"entity_{index}",
                video_id=video_id,
                item_type="entity",
                label=entity,
                description=f"{entity} is mentioned or visible in the video evidence.",
                evidence_ids=evidence_ids,
                start=_min_time(linked),
                end=_max_time(linked),
                confidence=sum(unit.confidence for unit in linked) / len(linked),
                provenance={"evidence_ids": evidence_ids},
            )
        )

    for index, triple in enumerate(triples, start=1):
        items.append(
            KGItem(
                item_id=f"triple_{index}",
                video_id=video_id,
                item_type="triple",
                label=f"{triple.subject} {triple.relation} {triple.object}",
                description=f"{triple.subject} {triple.relation} {triple.object}",
                triples=[triple],
                evidence_ids=list(triple.evidence_ids),
                start=triple.start,
                end=triple.end,
                confidence=triple.confidence,
                provenance=triple.provenance,
            )
        )

    if len(sections) > 1:
        for previous, current in zip(sections, sections[1:]):
            if previous.start is None or current.start is None:
                continue
            items.append(
                KGItem(
                    item_id=f"temporal_{previous.section_id}_{current.section_id}",
                    video_id=video_id,
                    item_type="temporal_link",
                    label=f"{previous.section_id} BEFORE {current.section_id}",
                    description=f"{previous.heading} occurs before {current.heading}.",
                    triples=[
                        RelationTriple(
                            subject=previous.section_id,
                            relation="BEFORE",
                            object=current.section_id,
                            start=previous.start,
                            end=current.end,
                            confidence=min(previous.confidence, current.confidence),
                            evidence_ids=previous.evidence_ids + current.evidence_ids,
                        )
                    ],
                    evidence_ids=previous.evidence_ids + current.evidence_ids,
                    start=previous.start,
                    end=current.end,
                    confidence=min(previous.confidence, current.confidence),
                )
            )
    return items


# --------------------------------------------------------------------------------------------------
# Markdown rendering (eq. 24)
# --------------------------------------------------------------------------------------------------
def render_kg_markdown(
    video_id: str,
    kg_items: list[KGItem],
    links: list[CrossModalLink] | None = None,
) -> str:
    """Render the KG wiki: entity/event, relation-triple, temporal-link, contradiction-link,
    cross-modal-link (eq. 21), and provenance tables (eq. 24). ``links`` adds the cross-modal section."""
    entity_event_types = {"entity", "event", "object", "location"}
    triple_types = {"triple"}

    lines = [
        f"# KG Wiki: {video_id}",
        "",
        "## Entities and Events",
        "",
        "| ID | Type | Label | Description | Evidence |",
        "| --- | --- | --- | --- | --- |",
    ]
    for item in kg_items:
        if item.item_type not in entity_event_types:
            continue
        lines.append(
            f"| {item.item_id} | {item.item_type} | {_escape(item.label)} | "
            f"{_escape(item.description)} | {', '.join(item.evidence_ids)} |"
        )

    lines.extend(
        [
            "",
            "## Relation Triples",
            "",
            "| Subject | Relation | Object | Time | Confidence | Evidence |",
            "| --- | --- | --- | --- | --- | --- |",
        ]
    )
    for item in kg_items:
        if item.item_type not in triple_types:
            continue
        for triple in item.triples:
            time = f"{_fmt_time(triple.start)}-{_fmt_time(triple.end)}"
            lines.append(
                f"| {_escape(triple.subject)} | {_escape(triple.relation)} | {_escape(triple.object)} | "
                f"{time} | {triple.confidence:.2f} | {', '.join(triple.evidence_ids)} |"
            )

    lines.extend(
        [
            "",
            "## Temporal Links",
            "",
            "| Earlier | Relation | Later | Time | Confidence | Evidence |",
            "| --- | --- | --- | --- | --- | --- |",
        ]
    )
    for item in kg_items:
        if item.item_type != "temporal_link":
            continue
        triple = item.triples[0] if item.triples else None
        subject = triple.subject if triple else item.label
        relation = triple.relation if triple else "BEFORE"
        obj = triple.object if triple else ""
        time = f"{_fmt_time(item.start)}-{_fmt_time(item.end)}"
        lines.append(
            f"| {_escape(subject)} | {_escape(relation)} | {_escape(obj)} | "
            f"{time} | {item.confidence:.2f} | {', '.join(item.evidence_ids)} |"
        )

    lines.extend(
        [
            "",
            "## Contradiction Links",
            "",
            "| Item A | Item B | Reason | Confidence | Evidence |",
            "| --- | --- | --- | --- | --- |",
        ]
    )
    for item in kg_items:
        if item.item_type != "contradiction_link":
            continue
        triple = item.triples[0] if item.triples else None
        item_a = triple.subject if triple else item.label
        item_b = triple.object if triple else ""
        reason = str(item.provenance.get("reason", "")) or item.description
        lines.append(
            f"| {_escape(item_a)} | {_escape(item_b)} | {_escape(reason)} | "
            f"{item.confidence:.2f} | {', '.join(item.evidence_ids)} |"
        )

    lines.append("")
    lines.extend(render_links_section(links or []))

    lines.extend(
        [
            "",
            "## Provenance",
            "",
            "| ID | Type | Evidence | Provenance |",
            "| --- | --- | --- | --- |",
        ]
    )
    for item in kg_items:
        lines.append(
            f"| {item.item_id} | {item.item_type} | {', '.join(item.evidence_ids)} | "
            f"{_escape(_provenance_summary(item.provenance))} |"
        )

    return "\n".join(lines).rstrip() + "\n"


# --------------------------------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------------------------------
def _as_list(value: Any) -> list[dict[str, Any]]:
    if not isinstance(value, list):
        return []
    return [item for item in value if isinstance(item, dict)]


def _clean(value: Any) -> str:
    return str(value).strip() if value is not None else ""


def _filter_ids(value: Any, valid_ids: set[str]) -> list[str]:
    """Keep only known evidence ids, de-duplicated, in first-seen order (O(n) membership)."""
    if not isinstance(value, list):
        return []
    ordered: list[str] = []
    chosen: set[str] = set()
    for item in value:
        eid = str(item).strip()
        if eid in valid_ids and eid not in chosen:
            chosen.add(eid)
            ordered.append(eid)
    return ordered


def _normalize_entity_type(value: Any) -> str:
    text = _clean(value).lower()
    if text in {"object"}:
        return "object"
    if text in {"location", "place"}:
        return "location"
    return "entity"


def _normalize_temporal_relation(value: Any) -> str:
    text = _clean(value).upper()
    return text if text in _TEMPORAL_RELATIONS else "BEFORE"


def _evidence_confidence(evidence_ids: list[str], evidence_by_id: dict[str, EvidenceUnit]) -> float:
    units = [evidence_by_id[eid] for eid in evidence_ids if eid in evidence_by_id]
    if not units:
        return 0.5
    return sum(unit.confidence for unit in units) / len(units)


def _min_start(evidence_ids: list[str], evidence_by_id: dict[str, EvidenceUnit]) -> float | None:
    units = [evidence_by_id[eid] for eid in evidence_ids if eid in evidence_by_id]
    return _min_time(units)


def _max_end(evidence_ids: list[str], evidence_by_id: dict[str, EvidenceUnit]) -> float | None:
    units = [evidence_by_id[eid] for eid in evidence_ids if eid in evidence_by_id]
    return _max_time(units)


def _min_time(units: list[EvidenceUnit]) -> float | None:
    values = [unit.start for unit in units if unit.start is not None]
    return min(values) if values else None


def _max_time(units: list[EvidenceUnit]) -> float | None:
    values = [unit.end for unit in units if unit.end is not None]
    return max(values) if values else None


def _fmt_window(start: float | None, end: float | None) -> str:
    if start is None and end is None:
        return ""
    return f" {_fmt_time(start)}-{_fmt_time(end)}"


def _provenance_summary(provenance: dict[str, Any]) -> str:
    source = str(provenance.get("source", "")) if provenance else ""
    return source or "; ".join(f"{k}={v}" for k, v in provenance.items()) if provenance else "-"


def _escape(value: str) -> str:
    return value.replace("|", "\\|")
