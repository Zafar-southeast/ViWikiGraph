"""Evidence-gated wiki refinement (paper v1 §III-G, eq. 3, 40).

When downstream QA exposes missing, weakly-supported, or conflicting evidence, ViWikiGraph may emit a
small wiki patch ΔW_q. The patch is accepted and written back ONLY if it passes the SAME validation
used before storage: ``W' = Update(W, ΔW_q) if Valid(ΔW_q) = 1`` (eq. 40). Patches are derived ONLY
from verified evidence already in the retrieved package — never from the user question or gold answer.

The whole path is deterministic and offline-safe (an optional ``LLMClient`` may propose richer patches
but the fallback copies verified fields from package items). It is also strictly optional and
lightweight: zero patches when no gap is detected, bounded by ``max_patches``.

Pipeline (``refine_after_qa``): load_package → detect_evidence_gaps → propose_patches →
validate_patch (reusing :func:`viwikigraph.knowledge.validation.validate_item`) → apply_patch
(idempotent write-back + re-render + reindex) → log to ``validation/refinement_log.jsonl``.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from viwikigraph.core.io import ensure_dir, read_jsonl, write_json, write_jsonl
from viwikigraph.core.schemas import (
    CrossModalLink,
    EvidencePacket,
    EvidenceUnit,
    JsonDataclass,
    KGItem,
    LinkType,
    MediaItem,
    QAInstance,
    QAPrediction,
    ValidationResult,
    WikiPatch,
    WikiSection,
)
from viwikigraph.knowledge.kg import render_kg_markdown
from viwikigraph.knowledge.validation import validate_item
from viwikigraph.knowledge.wiki import render_narrative_markdown
from viwikigraph.retrieval.index import build_retrieval_index

# Gap kinds exposed by conditional verification / packet quality.
GAP_WEAK = "weak"
GAP_CONFLICTING = "conflicting"
GAP_MISSING = "missing"


@dataclass(slots=True)
class LoadedPackage:
    """A persisted knowledge package read back into typed objects for in-memory patching."""

    root: Path
    sections: list[WikiSection]
    kg_items: list[KGItem]
    media_items: list[MediaItem]
    evidence_units: list[EvidenceUnit]
    validations: list[ValidationResult]
    links: list[CrossModalLink]

    @property
    def evidence_by_id(self) -> dict[str, EvidenceUnit]:
        return {unit.evidence_id: unit for unit in self.evidence_units}

    @property
    def items_by_id(self) -> dict[str, object]:
        out: dict[str, object] = {s.section_id: s for s in self.sections}
        out.update({k.item_id: k for k in self.kg_items})
        out.update({m.media_id: m for m in self.media_items})
        return out


@dataclass(slots=True)
class RefinementResult(JsonDataclass):
    """Outcome of one per-question refinement pass (persisted to ``qa/refinement.jsonl``)."""

    question_id: str
    video_id: str
    patches: list[WikiPatch] = field(default_factory=list)
    applied: int = 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "question_id": self.question_id,
            "video_id": self.video_id,
            "applied": self.applied,
            "patches": [patch.to_dict() for patch in self.patches],
        }


def load_package(root: str | Path) -> LoadedPackage | None:
    """Read a persisted package's artifacts into a :class:`LoadedPackage` (``None`` if absent)."""
    root = Path(root)
    if not (root / "manifest.json").exists():
        return None

    def rows(rel: str) -> list[dict]:
        path = root / rel
        return read_jsonl(path) if path.exists() else []

    return LoadedPackage(
        root=root,
        sections=[WikiSection.from_dict(r) for r in rows("wiki/narrative_sections.jsonl")],
        kg_items=[KGItem.from_dict(r) for r in rows("wiki/kg_items.jsonl")],
        media_items=[MediaItem.from_dict(r) for r in rows("validation/media_links.jsonl")],
        evidence_units=[EvidenceUnit.from_dict(r) for r in rows("evidence/evidence_units.jsonl")],
        validations=[ValidationResult.from_dict(r) for r in rows("validation/claim_support.jsonl")],
        links=[CrossModalLink.from_dict(r) for r in rows("validation/cross_modal_links.jsonl")],
    )


def detect_evidence_gaps(
    qa: QAInstance,
    packet: EvidencePacket,
    prediction: QAPrediction,
    *,
    weak_quality_threshold: float = 0.35,
) -> list[dict[str, Any]]:
    """Detect missing / weak / conflicting evidence from the QA result (eq. 38-39 trigger).

    Reads ONLY ``prediction.evidence_trace`` (the claim-level T_q + verification verdicts) and packet
    structure — never ``qa.answer_index`` / ``qa.answer_text``. Returns ``[]`` when nothing is
    actionable, so refinement is a no-op in the common case.
    """
    verified_pool = _verified_evidence_pool(packet)
    gaps: list[dict[str, Any]] = []
    for trace in prediction.claim_traces():
        evidence_ids = [eid for eid in (trace.subtitle_ids + trace.provenance) if eid in verified_pool]
        if trace.label == "contr":
            gaps.append({"kind": GAP_CONFLICTING, "claim": trace.claim, "evidence_ids": evidence_ids,
                         "detail": "verification labelled the claim contradicted"})
        elif trace.label == "unsup" and evidence_ids:
            gaps.append({"kind": GAP_WEAK, "claim": trace.claim, "evidence_ids": evidence_ids,
                         "detail": "verification labelled the claim unsupported but adjacent evidence exists"})
        elif not (trace.section_ids or trace.kg_item_ids or trace.subtitle_ids):
            gaps.append({"kind": GAP_MISSING, "claim": trace.claim, "evidence_ids": evidence_ids,
                         "detail": "no retrieved item grounds the claim"})
    if any(item.item_type == "contradiction_link" for item in packet.kg_items):
        gaps.append({"kind": GAP_CONFLICTING, "claim": prediction.answer,
                     "evidence_ids": [], "detail": "packet carries a contradiction link"})
    return gaps


def propose_patches(
    qa: QAInstance,
    packet: EvidencePacket,
    prediction: QAPrediction,
    gaps: list[dict[str, Any]],
    llm: Any | None = None,
    *,
    max_patches: int = 2,
) -> list[WikiPatch]:
    """Generate candidate patches ΔW_q from VERIFIED evidence only (eq. 40).

    Deterministic fallback attaches verified evidence (provenance/timestamp) to a weakly-grounded
    section, or adds a cross-modal link from a verified span — copying fields from package items only.
    ``qa.question`` is used only as a focusing cue for the LLM path (never as a fact source) and
    ``qa.answer_*`` is never read. Bounded by ``max_patches``.
    """
    verified_pool = _verified_evidence_pool(packet)
    patches: list[WikiPatch] = []
    if llm is not None and getattr(llm, "available", False):
        patches.extend(_llm_patches(qa, packet, gaps, verified_pool, llm))
    if not patches:
        patches.extend(_deterministic_patches(packet, gaps, verified_pool))
    # Enforce the no-leakage invariant: every cited id must be a verified packet evidence id.
    patches = [p for p in patches if p.evidence_ids and all(eid in verified_pool for eid in p.evidence_ids)]
    return patches[:max_patches]


def validate_patch(
    patch: WikiPatch,
    package: LoadedPackage,
    *,
    llm: Any | None = None,
    keep_threshold: float = 0.5,
    validate_links: bool = True,
) -> WikiPatch:
    """The eq. 40 gate: validate the patched item with the SAME validator used before storage.

    Resolves ``patch.evidence_ids`` to evidence units, builds the resulting item text, runs
    :func:`validate_item` (with the package's grounded items for the consistency/conflict check and,
    when ``validate_links``, the cross-modal links for q_link), and accepts iff the decision is
    ``keep``. ``validate_links=False`` reproduces the paper ablation "patch w/o link validation"."""
    evidence = [package.evidence_by_id[eid] for eid in patch.evidence_ids if eid in package.evidence_by_id]
    text = _patch_text(patch, package)
    grounded = _grounded_items(package)
    links = package.links if validate_links else None
    result = validate_item(
        patch.target_id or patch.patch_id,
        patch.target_type,
        text,
        evidence,
        grounded_items=grounded,
        links=links,
        threshold=keep_threshold,
        llm=llm,
    )
    patch.validation = result
    patch.accepted = result.decision == "keep" and bool(evidence)
    return patch


def apply_patch(patch: WikiPatch, package: LoadedPackage, *, dry_run: bool = False) -> bool:
    """Write a validated patch back into the package (eq. 40 Update). Returns ``True`` if it mutated.

    Idempotent: a content-hash guard skips a patch already recorded in ``refinement_log.jsonl``.
    Mutates only the targeted artifact, then re-renders both Markdown wikis and rebuilds the retrieval
    index so the patch is immediately retrievable. Never deletes or rewrites unrelated rows."""
    if not patch.accepted or dry_run:
        return False
    if _already_applied(package.root, patch.patch_id):
        return False

    mutated = _mutate_package(patch, package)
    if not mutated:
        return False

    write_jsonl(package.root / "wiki" / "narrative_sections.jsonl", package.sections)
    write_jsonl(package.root / "wiki" / "kg_items.jsonl", package.kg_items)
    write_jsonl(package.root / "validation" / "cross_modal_links.jsonl", package.links)
    (package.root / "wiki" / "narrative_wiki.md").write_text(
        render_narrative_markdown(_video_id(package), package.sections), encoding="utf-8"
    )
    (package.root / "wiki" / "kg_wiki.md").write_text(
        render_kg_markdown(_video_id(package), package.kg_items, package.links), encoding="utf-8"
    )
    subtitle_units = [u for u in package.evidence_units]
    index = build_retrieval_index(
        package.sections, package.kg_items, package.media_items, subtitle_units, package.links
    )
    write_json(package.root / "index" / "retrieval_index.json", index.to_dict())
    _record_applied(package.root, patch)
    _bump_manifest(package.root)
    return True


def refine_after_qa(
    qa: QAInstance,
    packet: EvidencePacket,
    prediction: QAPrediction,
    root: str | Path,
    llm: Any | None = None,
    *,
    dry_run: bool = False,
    validate_links: bool = True,
    max_patches: int = 2,
    keep_threshold: float = 0.5,
) -> RefinementResult:
    """End-to-end per-question evidence-gated refinement (eq. 3, 40). Optional + lightweight."""
    result = RefinementResult(question_id=qa.question_id, video_id=qa.video_id)
    package = load_package(root)
    if package is None:
        return result

    gaps = detect_evidence_gaps(qa, packet, prediction)
    if not gaps:
        return result

    for patch in propose_patches(qa, packet, prediction, gaps, llm, max_patches=max_patches):
        validate_patch(patch, package, llm=llm, keep_threshold=keep_threshold, validate_links=validate_links)
        if apply_patch(patch, package, dry_run=dry_run):
            result.applied += 1
        result.patches.append(patch)

    if result.patches:
        ensure_dir(package.root / "validation")
        decisions_path = package.root / "validation" / "refinement_log.jsonl"
        existing = read_jsonl(decisions_path) if decisions_path.exists() else []
        write_jsonl(decisions_path, existing + [p.to_dict() for p in result.patches])
    return result


# --- gap / patch helpers ---------------------------------------------------------------------


def _verified_evidence_pool(packet: EvidencePacket) -> set[str]:
    """Evidence ids that are demonstrably part of the retrieved package (the only patch sources)."""
    pool: set[str] = {span.evidence_id for span in packet.subtitle_spans}
    for section in packet.narrative_sections:
        pool.update(section.evidence_ids)
    for item in packet.kg_items:
        pool.update(item.evidence_ids)
    return pool


def _deterministic_patches(
    packet: EvidencePacket,
    gaps: list[dict[str, Any]],
    verified_pool: set[str],
) -> list[WikiPatch]:
    """Conservative patches that attach verified evidence to weakly-grounded items (no LLM)."""
    span_by_id = {span.evidence_id: span for span in packet.subtitle_spans}
    patches: list[WikiPatch] = []
    for gap in gaps:
        if gap["kind"] not in (GAP_WEAK, GAP_MISSING):
            continue  # do not auto-resolve contradictions; only strengthen grounding
        evidence_ids = [eid for eid in gap.get("evidence_ids", []) if eid in verified_pool]
        if not evidence_ids:
            continue
        target = _best_section_for_claim(gap["claim"], packet)
        if target is None:
            continue
        spans = [span_by_id[eid] for eid in evidence_ids if eid in span_by_id]
        starts = [s.start for s in spans if s.start is not None]
        ends = [s.end for s in spans if s.end is not None]
        content: dict[str, Any] = {"add_evidence_ids": evidence_ids}
        if starts:
            content["start"] = min(starts)
        if ends:
            content["end"] = max(ends)
        patches.append(
            WikiPatch(
                patch_id=_patch_id(packet.video_id, "add", "provenance", target.section_id, content, evidence_ids),
                video_id=packet.video_id,
                op="add",
                target_type="provenance",
                target_id=target.section_id,
                content=content,
                evidence_ids=evidence_ids,
                rationale=f"attach verified evidence {evidence_ids} to strengthen grounding",
                provenance={"source": "evidence_gated_refinement", "gap": gap["kind"]},
            )
        )
    return patches


def _llm_patches(
    qa: QAInstance,
    packet: EvidencePacket,
    gaps: list[dict[str, Any]],
    verified_pool: set[str],
    llm: Any,
) -> list[WikiPatch]:
    """Optional LLM-proposed patches, filtered to verified evidence ids (eq. 40 anti-leakage)."""
    try:
        from viwikigraph.llm.prompts import refinement_prompt

        gap_kind = gaps[0]["kind"] if gaps else GAP_WEAK
        evidence_digest = "\n".join(
            f"[{span.evidence_id}] {span.text}" for span in packet.subtitle_spans if span.evidence_id in verified_pool
        )
        item_digest = "\n".join(f"[{s.section_id}] {s.heading}: {s.content}" for s in packet.narrative_sections)
        response = llm.strict_json(
            refinement_prompt(qa.question, gap_kind, evidence_digest, item_digest), cache_version="refine_v1"
        )
    except Exception:
        return []
    patches: list[WikiPatch] = []
    for raw in response.get("patches", []) if isinstance(response, dict) else []:
        if not isinstance(raw, dict):
            continue
        evidence_ids = [str(e) for e in (raw.get("evidence_ids") or []) if str(e) in verified_pool]
        op = str(raw.get("op", "add")).lower()
        target_type = str(raw.get("target_type", "")).lower()
        if not evidence_ids or op not in {"add", "revise"}:
            continue
        content = raw.get("content") if isinstance(raw.get("content"), dict) else {}
        target_id = raw.get("target_id") or None
        patches.append(
            WikiPatch(
                patch_id=_patch_id(packet.video_id, op, target_type, target_id, content, evidence_ids),
                video_id=packet.video_id,
                op=op,
                target_type=target_type,
                target_id=str(target_id) if target_id else None,
                content=dict(content),
                evidence_ids=evidence_ids,
                rationale=str(raw.get("rationale", "")),
                provenance={"source": "evidence_gated_refinement", "llm": True},
            )
        )
    return patches


def _best_section_for_claim(claim: str, packet: EvidencePacket) -> WikiSection | None:
    from viwikigraph.core.text import tokens as _tok

    claim_tokens = _tok(claim)
    best: WikiSection | None = None
    best_overlap = -1
    for section in packet.narrative_sections:
        overlap = len(claim_tokens & _tok(section.content))
        if overlap > best_overlap:
            best_overlap = overlap
            best = section
    return best


def _patch_text(patch: WikiPatch, package: LoadedPackage) -> str:
    """The text whose support the patch must justify (the target item's content, or the new content)."""
    if patch.target_id:
        for section in package.sections:
            if section.section_id == patch.target_id:
                return section.content or section.heading
        for item in package.kg_items:
            if item.item_id == patch.target_id:
                return item.description or item.label
    return str(patch.content.get("text", "")) or str(patch.content.get("claim", ""))


def _grounded_items(package: LoadedPackage) -> list[tuple[str, list[EvidenceUnit]]]:
    by_id = package.evidence_by_id
    grounded: list[tuple[str, list[EvidenceUnit]]] = []
    for section in package.sections:
        grounded.append((section.content, [by_id[e] for e in section.evidence_ids if e in by_id]))
    for item in package.kg_items:
        grounded.append((item.description or item.label, [by_id[e] for e in item.evidence_ids if e in by_id]))
    return grounded


# --- write-back helpers ----------------------------------------------------------------------


def _mutate_package(patch: WikiPatch, package: LoadedPackage) -> bool:
    """Apply the patch in-memory to ``package``; returns ``True`` if anything changed."""
    if patch.target_type in {"provenance", "timestamp"} and patch.target_id:
        section = next((s for s in package.sections if s.section_id == patch.target_id), None)
        if section is None:
            return False
        new_ids = [e for e in patch.content.get("add_evidence_ids", []) if e not in section.evidence_ids]
        if not new_ids and "start" not in patch.content and "end" not in patch.content:
            return False
        section.evidence_ids = list(section.evidence_ids) + new_ids
        if patch.content.get("start") is not None:
            section.start = patch.content["start"] if section.start is None else min(section.start, patch.content["start"])
        if patch.content.get("end") is not None:
            section.end = patch.content["end"] if section.end is None else max(section.end, patch.content["end"])
        refs = section.provenance.setdefault("refinement_evidence_ids", [])
        refs.extend(new_ids)
        return True
    if patch.target_type == "cross_modal_link":
        link = _link_from_content(patch, package)
        if link is None or any(l.link_id == link.link_id for l in package.links):
            return False
        package.links.append(link)
        return True
    if patch.target_type == "claim" and patch.target_id:
        section = next((s for s in package.sections if s.section_id == patch.target_id), None)
        claim = str(patch.content.get("claim", "")).strip()
        if section is None or not claim or claim in section.claims:
            return False
        section.claims = list(section.claims) + [claim]
        section.evidence_ids = list(dict.fromkeys(section.evidence_ids + patch.evidence_ids))
        return True
    return False


def _link_from_content(patch: WikiPatch, package: LoadedPackage) -> CrossModalLink | None:
    content = patch.content
    source_id = str(content.get("source_id", "")) or (patch.target_id or "")
    target_id = str(content.get("target_id", "")) or (patch.evidence_ids[0] if patch.evidence_ids else "")
    if not source_id or not target_id:
        return None
    try:
        link_type = LinkType(str(content.get("link_type", "claim_text")))
    except ValueError:
        link_type = LinkType.CLAIM_TEXT
    return CrossModalLink(
        link_id=f"link_refine_{len(package.links) + 1}",
        video_id=_video_id(package),
        source_id=source_id,
        target_id=target_id,
        link_type=link_type,
        confidence=0.8,
        provenance={"source": "evidence_gated_refinement"},
    )


def _video_id(package: LoadedPackage) -> str:
    if package.sections:
        return package.sections[0].video_id
    if package.kg_items:
        return package.kg_items[0].video_id
    return package.root.name


def _patch_id(
    video_id: str,
    op: str,
    target_type: str,
    target_id: str | None,
    content: dict[str, Any],
    evidence_ids: list[str],
) -> str:
    payload = json.dumps({"c": content, "e": sorted(evidence_ids)}, sort_keys=True, default=str)
    digest = hashlib.sha256(payload.encode("utf-8")).hexdigest()[:8]
    return f"patch_{video_id}_{op}_{target_type}_{target_id or 'new'}_{digest}"


def _already_applied(root: Path, patch_id: str) -> bool:
    log = root / "validation" / "applied_patches.jsonl"
    if not log.exists():
        return False
    return any(row.get("patch_id") == patch_id for row in read_jsonl(log))


def _record_applied(root: Path, patch: WikiPatch) -> None:
    log = ensure_dir(root / "validation") / "applied_patches.jsonl"
    existing = read_jsonl(log) if log.exists() else []
    record = patch.to_dict()
    record["applied_at"] = True
    write_jsonl(log, existing + [record])


def _bump_manifest(root: Path) -> None:
    path = root / "manifest.json"
    if not path.exists():
        return
    data = json.loads(path.read_text(encoding="utf-8"))
    refinement = data.get("refinement", {"patches_applied": 0})
    refinement["patches_applied"] = int(refinement.get("patches_applied", 0)) + 1
    data["refinement"] = refinement
    write_json(path, data)
