"""``python -m viwikigraph`` entry point — delegates to :mod:`viwikigraph.cli`."""

from viwikigraph.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
