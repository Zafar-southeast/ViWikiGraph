"""Question answering and scoring:

* :mod:`~viwikigraph.qa.answering` — route + retrieve + answer (with verification).
* :mod:`~viwikigraph.qa.evaluation` — accuracy / EM / token-F1 metrics.
* :mod:`~viwikigraph.qa.reporting` — ``report.md`` + run-config assembly.

Imported evaluation-first so reporting's metric dependency is ready.
"""

from viwikigraph.qa.evaluation import (
    accuracy,
    evaluate_predictions,
    exact_match,
    token_f1,
)
from viwikigraph.qa.reporting import (
    PackageStats,
    collect_package_stats,
    question_type_of,
    write_report,
)
from viwikigraph.qa.answering import answer_question, serialize_evidence_packet

__all__ = [
    # evaluation
    "accuracy",
    "evaluate_predictions",
    "exact_match",
    "token_f1",
    # reporting
    "PackageStats",
    "collect_package_stats",
    "question_type_of",
    "write_report",
    # answering
    "answer_question",
    "serialize_evidence_packet",
]
