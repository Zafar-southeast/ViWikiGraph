"""Wiki-grounded VideoQA (paper v1 §III-F/§III-G, eq. 27-40).

The QA stage serializes a retrieved :class:`EvidencePacket` E_q = (R_nar, R_kg, R_media, R_link) into
an id-tagged context (eq. 32-33), answers the question with the LLM (MCQ choice / MCQ logprob /
open-ended, eq. 34), then applies *conditional* verification when the answer looks risky: it computes
a calibrated distribution p_cal (eq. 35), an evidence-quality score Q(E_q) (eq. 36), and a transparent
fixed-weight risk gate ρ_q (eq. 37); when ρ_q exceeds the threshold it decomposes the draft into
atomic claims, labels each against its support set, and revises unsupported/contradicted content
(eq. 38). The result carries a claim-level evidence trace T_q (eq. 39).

RAG-only / no training. All scalar weights (``_CALIBRATION_T``, ``_ETA``, ``_RISK_WEIGHTS``) are FIXED
hyperparameters, NOT learned. Every LLM path has a deterministic token-overlap fallback so the
pipeline runs end-to-end with no API key / no network. Gold annotations are never read here.
"""

from __future__ import annotations

import hashlib
import math
from dataclasses import dataclass, field
from typing import Any

from viwikigraph.llm.client import LLMClient
from viwikigraph.llm.prompts import (
    mcq_prompt,
    mcq_tc_prompt,
    open_prompt,
    option_scoring_prefix,
    verification_prompt,
)
from viwikigraph.core.schemas import (
    ClaimTrace,
    CrossModalLink,
    EvidencePacket,
    EvidenceUnit,
    KGItem,
    QAInstance,
    QAPrediction,
    WikiSection,
)
from viwikigraph.core.text import tokens as _tokens

# Eq. 35 — fixed calibration temperature T (NOT learned).
_CALIBRATION_T = 1.5
# Eq. 36 — fixed per-group weights η over (R_nar, R_kg, R_media, R_link); renormalized over present
# groups so a text-only packet is not penalized for lacking media/links.
_ETA = {"narrative": 0.40, "kg": 0.30, "media": 0.15, "link": 0.15}
# Eq. 37 — fixed risk-gate weights over [1-p_chosen, H̄(p_cal), 1-Q(E_q), conflict, visual-need].
# The eq. 37 σ(·) is realized as a transparent clamp (monotone squashing), NOT a trained sigmoid.
_RISK_WEIGHTS = (0.35, 0.10, 0.20, 0.25, 0.10)

# Optional strict response schema for the MCQ call (P3). Only sent when VIWIKIGRAPH_JSON_SCHEMA is
# enabled AND the proxy accepts it (auto-falls back to json_object otherwise); the tolerant
# repair_json parser remains the load-bearing safeguard regardless.
_MCQ_SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "properties": {
        "answer_index": {"type": "integer"},
        "answer": {"type": "string"},
        "confidence": {"type": "number"},
        "evidence_ids": {"type": "array", "items": {"type": "string"}},
        "rationale": {"type": "string"},
    },
    "required": ["answer_index", "answer", "confidence", "evidence_ids", "rationale"],
}


@dataclass(slots=True)
class _Draft:
    """Intermediate answer before (optional) verification."""

    predicted_index: int | None
    answer: str
    confidence: float
    evidence_ids: list[str]
    rationale: str
    method: str
    logprobs: list[float] | None = None  # per-option logprobs feeding p_cal (eq. 35), logprob mode
    fallback: dict[str, str] | None = None


def answer_question(
    qa: QAInstance,
    packet: EvidencePacket,
    llm: LLMClient | None = None,
    *,
    mode: str = "mcq",
    scorer: str = "choice",
    verify: bool = True,
    risk_threshold: float = 0.5,
    require_llm: bool = False,
) -> QAPrediction:
    """Answer ``qa`` from the retrieved ``packet`` (eq. 32-39).

    ``mode`` selects MCQ vs ``open`` answering; ``scorer`` selects the MCQ protocol (``choice`` JSON
    or length-normalized ``logprob``). ``risk_threshold`` plays the role of τ_ρ: when ``verify`` and
    the computed risk ρ_q exceeds it, a verification pass revises unsupported claims and adjusts
    confidence (eq. 38). With no usable LLM the deterministic token-overlap fallback is used (unless
    ``require_llm``). The returned :class:`QAPrediction` carries the claim-level trace T_q (eq. 39).
    """
    context = serialize_evidence_packet(qa, packet)
    draft = _draft_answer(qa, packet, context, llm, mode=mode, scorer=scorer, require_llm=require_llm)

    verification: dict[str, Any] | None = None
    if verify and llm is not None and draft.method != "heuristic_overlap":
        risk = _risk_score(qa, packet, draft)
        if risk > risk_threshold:
            verification = _verify(qa, packet, context, draft, llm)
            if verification is not None:
                verification["risk"] = round(risk, 3)
                verification["evidence_quality"] = round(_evidence_quality(packet), 3)
                draft = _apply_verification(draft, verification, qa, mode)
            else:
                verification = {"triggered": True, "applied": False, "risk": round(risk, 3)}
        else:
            # Eq. 38 — when verification is not triggered, the answer confidence is c = 1 - ρ_q.
            verification = {"triggered": False, "risk": round(risk, 3)}
            draft = _Draft(
                draft.predicted_index, draft.answer, _clamp(1.0 - risk),
                draft.evidence_ids, draft.rationale, draft.method, draft.logprobs, draft.fallback,
            )

    claims = _decompose_claims(qa, draft)
    trace = _build_trace(qa, packet, draft, claims, verification)
    return QAPrediction(
        question_id=qa.question_id,
        video_id=qa.video_id,
        answer=draft.answer,
        confidence=round(_clamp(draft.confidence), 4),
        evidence_trace=trace,
        scoring_method=draft.method,
        predicted_index=draft.predicted_index,
    )


# --------------------------------------------------------------------------------------------- #
# Serialization (eq. 32-33)
# --------------------------------------------------------------------------------------------- #
def serialize_evidence_packet(qa: QAInstance, packet: EvidencePacket) -> str:
    """Render the 4-part packet E_q into an id-tagged context block (eq. 32).

    Blocks, in order: narrative sections, KG entries (structured per eq. 33 with confidence and
    provenance), subtitle/ASR/OCR spans, media references, cross-modal evidence links, and external
    knowledge. Every item is tagged with a citable id so the model can ground ``evidence_ids`` and
    ``link_ids`` against real evidence.
    """
    lines: list[str] = [f"Question: {qa.question}", ""]

    if _is_temporal_question(qa):
        timeline = _temporal_timeline(packet.subtitle_spans, packet.narrative_sections)
        if timeline:
            lines.append("Temporal Timeline Evidence (timestamp order; use this first for before/after reasoning):")
            lines.extend(timeline)
            lines.append("")

    if packet.narrative_sections:
        lines.append("Narrative Evidence:")
        for section in packet.narrative_sections:
            time = _format_span(section.start, section.end)
            lines.append(
                f"- [{section.section_id}] ({section.section_type}{time}) "
                f"{section.heading}: {section.content}".rstrip()
            )
            for claim in section.claims:
                lines.append(f"    * claim: {claim}")
        lines.append("")

    if packet.kg_items:
        lines.append("Knowledge Graph Evidence:")
        for item in packet.kg_items:
            lines.append(_serialize_kg_item(item))
        lines.append("")

    if packet.subtitle_spans:
        lines.append("Subtitle/Transcript Evidence:")
        for span in packet.subtitle_spans:
            time = _format_span(span.start, span.end)
            lines.append(
                f"- [{span.evidence_id}] ({span.modality.value}{time}) {span.text}".rstrip()
            )
        lines.append("")

    if packet.media_items:
        lines.append("Media Evidence:")
        for media in packet.media_items:
            lines.append(f"- [{media.media_id}] {media.media_type}: {media.path}")
        lines.append("")

    if packet.cross_modal_links:
        lines.append("Cross-Modal Evidence Links:")
        for link in packet.cross_modal_links:
            time = _format_span(link.start, link.end)
            lines.append(
                f"- [{link.link_id}] {link.link_type.value}: {link.source_id} <-> {link.target_id}"
                f"{time} (conf={link.confidence:.2f})".rstrip()
            )
        lines.append("")

    if packet.knowledge:
        lines.append("External Knowledge:")
        for idx, snippet in enumerate(packet.knowledge):
            sid = str(snippet.get("id") or snippet.get("source") or f"know_{idx}")
            text = str(snippet.get("text", "")).strip()
            lines.append(f"- [{sid}] {text}")
        lines.append("")

    return "\n".join(lines).rstrip()


def _is_temporal_question(qa: QAInstance) -> bool:
    qtype = str((qa.metadata or {}).get("question_type", "")).upper()
    text = qa.question.lower()
    return qtype.startswith("T") or any(
        cue in text for cue in ("before", "after", "then", "next", "first", "last", "start", "end")
    )


def _is_tc_question(qa: QAInstance) -> bool:
    return str((qa.metadata or {}).get("question_type", "")).upper() == "TC"


def _temporal_timeline(spans: list[EvidenceUnit], sections: list[WikiSection]) -> list[str]:
    rows: list[tuple[float, str, str]] = []
    seen: set[str] = set()
    for span in spans:
        if span.start is None or span.evidence_id in seen:
            continue
        seen.add(span.evidence_id)
        action_bits = [*span.actions, *span.events]
        action_text = "; ".join(bit for bit in action_bits if bit).strip()
        text = action_text or span.text
        rows.append((float(span.start), span.evidence_id, text))
    for section in sections:
        if section.start is None or section.section_id in seen:
            continue
        seen.add(section.section_id)
        rows.append((float(section.start), section.section_id, section.content))
    rows.sort(key=lambda row: row[0])
    return [f"- [{item_id}] @ {time:g}s: {text}" for time, item_id, text in rows]


def _serialize_kg_item(item: KGItem) -> str:
    """Structured per-KG-item projection z_j (eq. 33): head/relation/tail with confidence γ and a
    compact provenance π (timestamps, evidence ids). Deterministic string projection (no learned matrix)."""
    desc = f": {item.description}" if item.description else ""
    head = f"- [{item.item_id}] {item.item_type} {item.label}{desc}".rstrip()
    rows = [head]
    for triple in item.triples:
        prov_bits: list[str] = [f"conf={triple.confidence:.2f}"]
        span = _format_span(triple.start, triple.end).strip()
        if span:
            prov_bits.append(f"t={span}")
        if triple.evidence_ids:
            prov_bits.append(f"ev={','.join(triple.evidence_ids)}")
        rows.append(
            f"    * triple: ({triple.subject}, {triple.relation}, {triple.object}) [{'; '.join(prov_bits)}]"
        )
    return "\n".join(rows)


# --------------------------------------------------------------------------------------------- #
# Drafting (eq. 34)
# --------------------------------------------------------------------------------------------- #
def _draft_answer(
    qa: QAInstance,
    packet: EvidencePacket,
    context: str,
    llm: LLMClient | None,
    *,
    mode: str,
    scorer: str,
    require_llm: bool,
) -> _Draft:
    if llm is not None:
        try:
            if mode == "open":
                return _open_draft(qa, context, llm)
            if scorer == "logprob":
                logprob_draft = _logprob_draft(qa, context, llm)
                if logprob_draft is not None:
                    return logprob_draft
                # fall through to choice scorer on None/error
            return _choice_draft(qa, context, llm)
        except Exception as exc:
            if require_llm:
                raise
            return _with_fallback(_heuristic_draft(qa, context, mode), _attempted_llm_method(mode, scorer), exc)
    elif require_llm:
        raise RuntimeError("answer_question requires an LLM but none was provided.")
    return _heuristic_draft(qa, context, mode)


def _attempted_llm_method(mode: str, scorer: str) -> str:
    if mode == "open":
        return "llm_open"
    if scorer == "logprob":
        return "llm_logprob"
    return "llm_choice"


def _with_fallback(draft: _Draft, attempted_method: str, exc: Exception) -> _Draft:
    return _Draft(
        predicted_index=draft.predicted_index,
        answer=draft.answer,
        confidence=draft.confidence,
        evidence_ids=draft.evidence_ids,
        rationale=draft.rationale,
        method=draft.method,
        logprobs=draft.logprobs,
        fallback={
            "from": attempted_method,
            "to": draft.method,
            "error_type": type(exc).__name__,
            "error": str(exc)[:300],
        },
    )


def _choice_draft(qa: QAInstance, context: str, llm: LLMClient) -> _Draft:
    if _is_tc_question(qa):
        prompt = mcq_tc_prompt(qa.question, qa.options, context)
        cache_version = "qa_mcq_tc_v1"
    else:
        prompt = mcq_prompt(qa.question, qa.options, context)
        cache_version = "qa_mcq_v1"
    response = llm.strict_json(prompt, cache_version=cache_version, tolerant=True, response_schema=_MCQ_SCHEMA)
    if not isinstance(response, dict):  # defensive: tolerant parse coerces, but never .get() on a list
        response = {}
    predicted_index = _coerce_index(response.get("answer_index"), len(qa.options))
    answer = str(response.get("answer", "") or "")
    if predicted_index is not None and qa.options and 0 <= predicted_index < len(qa.options):
        answer = qa.options[predicted_index]
    confidence = _coerce_confidence(response.get("confidence"), default=0.6)
    evidence_ids = _coerce_ids(response.get("evidence_ids"))
    rationale = str(response.get("rationale", "") or "")
    method = "llm_choice_tc" if _is_tc_question(qa) else "llm_choice"
    if predicted_index is None and qa.options:
        # MCQ is forced-choice — every question has a gold option and there is no abstain slot, so an
        # unset answer is guaranteed wrong. When the model declines to commit, fall back to the
        # deterministic evidence-overlap option as an explicit low-confidence guess (the abstention is
        # still recorded via the low confidence + ``_guess`` method, never silently as a real answer).
        guess = _heuristic_draft(qa, context, "mcq")
        # ``_heuristic_draft`` always commits an index for MCQ-with-options, but fall back to 0 if a
        # future change ever returns None so the never-abstain contract holds with no escape hatch.
        predicted_index = guess.predicted_index if guess.predicted_index is not None else 0
        answer = qa.options[predicted_index]
        confidence = min(confidence, 0.2)
        rationale = rationale or "model asserted no option; fell back to an evidence-overlap guess"
        method = "llm_choice_guess"
    return _Draft(predicted_index, answer, confidence, evidence_ids, rationale, method)


def _logprob_draft(qa: QAInstance, context: str, llm: LLMClient) -> _Draft | None:
    """Length-normalized option scoring (eq. 34): ``argmax (1/|o|) Σ log P(o | q, E_q)``."""
    if not qa.options:
        return None
    prefix = option_scoring_prefix(qa.question, context)
    scores: list[float | None] = []
    for option in qa.options:
        score = llm.normalized_logprob(prefix, option, cache_version="qa_logprob_v1")
        scores.append(score)
    if any(score is None for score in scores):
        return None  # endpoint lacks logprobs -> caller falls back to choice
    resolved = [s for s in scores if s is not None]
    best_idx = max(range(len(resolved)), key=lambda i: resolved[i])
    confidence = _softmax_confidence(resolved, best_idx)
    return _Draft(
        predicted_index=best_idx,
        answer=qa.options[best_idx],
        confidence=confidence,
        evidence_ids=[],
        rationale="length-normalized option likelihood",
        method="llm_logprob",
        logprobs=resolved,
    )


def _open_draft(qa: QAInstance, context: str, llm: LLMClient) -> _Draft:
    prompt = open_prompt(qa.question, context)
    response = llm.strict_json(prompt, cache_version="qa_open_v1", tolerant=True)
    if not isinstance(response, dict):
        response = {}
    answer = str(response.get("answer", "") or "")
    confidence = _coerce_confidence(response.get("confidence"), default=0.5)
    evidence_ids = _coerce_ids(response.get("evidence_ids"))
    return _Draft(None, answer, confidence, evidence_ids, "", "llm_open")


def _heuristic_draft(qa: QAInstance, context: str, mode: str) -> _Draft:
    """Deterministic token-overlap fallback (no LLM / no network)."""
    if mode == "open" or not qa.options:
        return _Draft(None, "", 0.0, [], "", "heuristic_overlap")
    context_tokens = _tokens(context)
    scored: list[tuple[float, int, str]] = []
    for idx, option in enumerate(qa.options):
        option_tokens = _tokens(option)
        overlap = len(context_tokens & option_tokens) / max(1, len(option_tokens))
        scored.append((overlap, idx, option))
    best_score = max(overlap for overlap, _, _ in scored)
    # Break ties among the top-scoring options by a stable per-question hash rather than always taking
    # the lowest index. On empty/near-empty context every option scores 0, so the old ``-item[1]`` rule
    # deterministically picked option 0 — worse than chance on NExT-QA (gold is ~uniform). The hash
    # spreads forced guesses across indices while staying fully deterministic and reproducible.
    top = [(idx, option) for overlap, idx, option in scored if overlap >= best_score]
    best_idx, best_answer = min(top, key=lambda io: _stable_tiebreak(qa.question_id, io[1]))
    return _Draft(best_idx, best_answer, best_score, [], "", "heuristic_overlap")


# --------------------------------------------------------------------------------------------- #
# Conditional verification (eq. 35-38)
# --------------------------------------------------------------------------------------------- #
def _calibrated_distribution(draft: _Draft, *, temperature: float = _CALIBRATION_T) -> list[float]:
    """Eq. 35 calibrated distribution p_cal = softmax(ℓ/T) with fixed T.

    Logprob mode uses the per-option logprobs; otherwise a transparent 2-point distribution
    ``[conf, 1-conf]`` so max(p_cal) and entropy are defined for every answering mode.
    """
    if draft.logprobs:
        scaled = [lp / temperature for lp in draft.logprobs]
        peak = max(scaled)
        exps = [math.exp(s - peak) for s in scaled]
        total = sum(exps) or 1.0
        return [e / total for e in exps]
    conf = _clamp(draft.confidence)
    return [conf, 1.0 - conf]


def _chosen_prob(draft: _Draft, dist: list[float]) -> float:
    """Calibrated probability mass on the chosen answer (eq. 35 feature for risk)."""
    if draft.logprobs and draft.predicted_index is not None and 0 <= draft.predicted_index < len(dist):
        return dist[draft.predicted_index]
    return _clamp(draft.confidence)


def _normalized_entropy(dist: list[float]) -> float:
    """H̄(p_cal) ∈ [0, 1]: Shannon entropy normalized by log(n) (eq. 37 feature)."""
    nonzero = [p for p in dist if p > 0.0]
    if len(nonzero) <= 1:
        return 0.0
    entropy = -sum(p * math.log(p) for p in nonzero)
    return _clamp(entropy / math.log(len(dist)))


def _risk_score(qa: QAInstance, packet: EvidencePacket, draft: _Draft) -> float:
    """Verification risk ρ_q (eq. 37) — fixed-weight transparent gate over five features:
    [1-p_chosen, H̄(p_cal), 1-Q(E_q), narrative/KG conflict, explicit visual-grounding need]."""
    dist = _calibrated_distribution(draft)
    f_uncertain = 1.0 - _chosen_prob(draft, dist)
    f_entropy = _normalized_entropy(dist)
    f_quality = 1.0 - _evidence_quality(packet)
    f_conflict = 1.0 if _has_conflict(packet) else 0.0
    f_visual = 1.0 if _needs_visual(qa, packet) else 0.0
    features = (f_uncertain, f_entropy, f_quality, f_conflict, f_visual)
    return _clamp(sum(w * c for w, c in zip(_RISK_WEIGHTS, features)))


def _verify(
    qa: QAInstance,
    packet: EvidencePacket,
    context: str,
    draft: _Draft,
    llm: LLMClient,
) -> dict[str, Any] | None:
    claims = _verifier_claims(qa, draft)
    prompt = verification_prompt(qa.question, draft.answer, claims, context)
    try:
        response = llm.strict_json(prompt, cache_version="qa_verify_v1", tolerant=True)
    except Exception:
        return None
    if not isinstance(response, dict) or not response:
        return None
    response["triggered"] = True
    response["applied"] = True
    return response


def _apply_verification(draft: _Draft, verification: dict[str, Any], qa: QAInstance, mode: str) -> _Draft:
    """Revise unsupported/contradicted content and adjust confidence per the verdicts (eq. 38).

    Supported claims are preserved; contradicted claims drop confidence sharply and adopt the revised
    answer; unsupported claims down-weight confidence. Only verified content is kept.

    MCQ is answered by index, not free text. The verifier returns prose ("Insufficient evidence.") that
    must NOT replace a committed option — eval keys on ``predicted_index`` (preserved below), so a prose
    answer on a committed index is incoherent and reads as an abstention in the report. On MCQ,
    verification therefore only adjusts confidence; the answer string stays the chosen option's text."""
    claims = verification.get("claims") or []
    verdicts = [str(c.get("verdict", "")).lower() for c in claims if isinstance(c, dict)]
    contradicted = any(v == "contr" for v in verdicts)
    unsupported = any(v in ("unsup", "contr") for v in verdicts)

    revised_answer = draft.answer
    raw_revised = str(verification.get("revised_answer", "") or "").strip()
    if raw_revised:
        revised_answer = raw_revised
    is_committed_mcq = (
        mode == "mcq"
        and draft.predicted_index is not None
        and bool(qa.options)
        and 0 <= draft.predicted_index < len(qa.options)
    )
    if is_committed_mcq:
        revised_answer = qa.options[draft.predicted_index]

    confidence = _coerce_confidence(verification.get("confidence"), default=draft.confidence)
    if contradicted:
        confidence = min(confidence, draft.confidence * 0.5)
    elif unsupported:
        confidence = min(confidence, draft.confidence * 0.8)

    supporting_ids = _coerce_ids(
        [eid for c in claims if isinstance(c, dict) for eid in (c.get("evidence_ids") or [])]
    )
    evidence_ids = supporting_ids or draft.evidence_ids
    return _Draft(
        predicted_index=draft.predicted_index,
        answer=revised_answer,
        confidence=_clamp(confidence),
        evidence_ids=evidence_ids,
        rationale=draft.rationale,
        method=f"{draft.method}+verified",
        logprobs=draft.logprobs,
        fallback=draft.fallback,
    )


def _verifier_claims(qa: QAInstance, draft: _Draft) -> list[str]:
    """Claims fed to the verification prompt (the decomposed draft answer)."""
    return _decompose_claims(qa, draft)


# --------------------------------------------------------------------------------------------- #
# Atomic-claim decomposition + per-claim support sets (eq. 38-39)
# --------------------------------------------------------------------------------------------- #
def _decompose_claims(qa: QAInstance, draft: _Draft) -> list[str]:
    """Decompose the draft answer into atomic claims (eq. 38 g_claim). Deterministic, no LLM call.

    Open-ended answers split on sentence boundaries; MCQ binds the question to the chosen option.
    The rationale, when present, is preferred as it states the supporting reason."""
    if draft.rationale:
        spans = [part.strip() for part in _split_sentences(draft.rationale) if part.strip()]
        if spans:
            return spans
    if draft.method.startswith("llm_open") and draft.answer:
        spans = [part.strip() for part in _split_sentences(draft.answer) if part.strip()]
        if spans:
            return spans
    if draft.answer:
        return [f"The answer to '{qa.question}' is '{draft.answer}'."]
    return []


def _claim_support(claim: str, packet: EvidencePacket, cited: set[str]) -> ClaimTrace:
    """Collect the typed support set S_m for one claim across all four evidence groups (eq. 38-39).

    Deterministic: an item supports the claim when its id (or one of its evidence ids) was cited, or
    — absent any citations — when its text token-overlaps the claim. Cross-modal links incident on a
    supporting item are surfaced as ``link_ids``."""
    claim_tokens = _tokens(claim)
    supporting_ids: set[str] = set()

    section_ids: list[str] = []
    for section in packet.narrative_sections:
        if _supports(section.section_id, section.evidence_ids, _section_text(section), claim_tokens, cited):
            section_ids.append(section.section_id)
            supporting_ids.add(section.section_id)
            supporting_ids.update(section.evidence_ids)

    kg_item_ids: list[str] = []
    triple_ids: list[str] = []
    for item in packet.kg_items:
        if _supports(item.item_id, item.evidence_ids, _kg_text(item), claim_tokens, cited):
            kg_item_ids.append(item.item_id)
            supporting_ids.add(item.item_id)
            supporting_ids.update(item.evidence_ids)
            if item.item_type == "triple":
                triple_ids.append(item.item_id)

    subtitle_ids: list[str] = []
    timestamps: list[tuple[float | None, float | None]] = []
    for span in packet.subtitle_spans:
        if span.evidence_id in cited or (not cited and claim_tokens & _tokens(span.text)):
            subtitle_ids.append(span.evidence_id)
            supporting_ids.add(span.evidence_id)
            if span.start is not None or span.end is not None:
                timestamps.append((span.start, span.end))
    for section in packet.narrative_sections:
        if section.section_id in section_ids and (section.start is not None or section.end is not None):
            timestamps.append((section.start, section.end))

    media_paths = [m.path for m in packet.media_items if not m.linked_item_id or m.linked_item_id in supporting_ids]
    if not media_paths:
        media_paths = [m.path for m in packet.media_items]
    link_ids = [
        link.link_id
        for link in packet.cross_modal_links
        if link.source_id in supporting_ids or link.target_id in supporting_ids
    ]

    return ClaimTrace(
        claim=claim,
        section_ids=section_ids,
        kg_item_ids=kg_item_ids,
        triple_ids=triple_ids,
        subtitle_ids=subtitle_ids,
        timestamps=_dedupe_spans(timestamps),
        media_paths=media_paths,
        link_ids=link_ids,
        provenance=subtitle_ids,
    )


def _supports(item_id: str, evidence_ids: list[str], text: str, claim_tokens: set[str], cited: set[str]) -> bool:
    if not cited:
        return bool(claim_tokens & _tokens(text))
    if item_id in cited:
        return True
    return any(eid in cited for eid in evidence_ids)


# --------------------------------------------------------------------------------------------- #
# Evidence trace T_q (eq. 39)
# --------------------------------------------------------------------------------------------- #
def _build_trace(
    qa: QAInstance,
    packet: EvidencePacket,
    draft: _Draft,
    claims: list[str],
    verification: dict[str, Any] | None,
) -> list[dict[str, Any]]:
    """Build T_q (eq. 39): one :class:`ClaimTrace` entry per atomic answer claim, each mapped to its
    typed support set across narrative/KG/media/link evidence, plus an optional verification meta
    entry (key ``verification``) so the report can detect that conditional verification considered
    this answer."""
    cited = set(draft.evidence_ids)
    verdict_by_claim = _verdict_map(verification)

    trace: list[dict[str, Any]] = []
    claim_list = claims or ([draft.answer] if draft.answer else [])
    for claim in claim_list:
        entry = _claim_support(claim, packet, cited)
        entry.label = verdict_by_claim.get(claim, verdict_by_claim.get(draft.answer, ""))
        trace.append(entry.to_dict())

    if verification is not None:
        trace.append(
            {
                "verification": {
                    "triggered": bool(verification.get("triggered", True)),
                    "applied": bool(verification.get("applied", False)),
                    "risk": verification.get("risk"),
                    "evidence_quality": verification.get("evidence_quality"),
                    "claims": verification.get("claims", []),
                }
            }
        )
    if draft.fallback is not None:
        trace.append({"fallback": dict(draft.fallback)})
    return trace


def _verdict_map(verification: dict[str, Any] | None) -> dict[str, str]:
    if not verification:
        return {}
    out: dict[str, str] = {}
    for claim in verification.get("claims", []) or []:
        if isinstance(claim, dict):
            text = str(claim.get("claim", "")).strip()
            verdict = str(claim.get("verdict", "")).strip().lower()
            if text and verdict:
                out[text] = verdict
    return out


# --------------------------------------------------------------------------------------------- #
# Evidence-quality / conflict / visual-need signals (eq. 36-37)
# --------------------------------------------------------------------------------------------- #
def _evidence_quality(packet: EvidencePacket) -> float:
    """Q(E_q) (eq. 36): η-weighted average per-group quality over R_nar, R_kg, R_media, R_link.

    Group quality is the mean item confidence (a proxy for the stored validation score). η is
    renormalized over the groups actually present, so a text-only packet is judged on its narrative/KG
    quality rather than penalized for missing media/links. Empty packet → 0.0."""
    groups = {
        "narrative": [s.confidence for s in packet.narrative_sections],
        "kg": [k.confidence for k in packet.kg_items],
        "media": [m.confidence for m in packet.media_items],
        "link": [link.confidence for link in packet.cross_modal_links],
    }
    present = {name: vals for name, vals in groups.items() if vals}
    if not present:
        return 0.0
    total_eta = sum(_ETA[name] for name in present) or 1.0
    weighted = sum(_ETA[name] * (sum(vals) / len(vals)) for name, vals in present.items())
    return _clamp(weighted / total_eta)


def _has_conflict(packet: EvidencePacket) -> bool:
    if any(item.item_type == "contradiction_link" for item in packet.kg_items):
        return True
    return any(
        "contradiction" in str(section.provenance.get("flag", "")).lower()
        for section in packet.narrative_sections
    )


def _needs_visual(qa: QAInstance, packet: EvidencePacket) -> bool:
    has_visual = any(
        item.modality.value in ("visual_concept", "frame", "snapshot", "clip", "ocr")
        for item in packet.subtitle_spans
    ) or bool(packet.media_items)
    text = qa.question.lower()
    visual_cue = any(
        word in text for word in ("color", "colour", "wearing", "see", "look", "appear", "holding")
    )
    return visual_cue and not has_visual


# --------------------------------------------------------------------------------------------- #
# Coercion / scoring / text helpers
# --------------------------------------------------------------------------------------------- #
def _section_text(section: WikiSection) -> str:
    return " ".join([section.heading, section.content, *section.claims])


def _kg_text(item: KGItem) -> str:
    parts = [item.label, item.description]
    for triple in item.triples:
        parts.extend([triple.subject, triple.relation, triple.object])
    return " ".join(parts)


def _split_sentences(text: str) -> list[str]:
    out: list[str] = []
    current: list[str] = []
    for char in text:
        current.append(char)
        if char in ".;!?":
            out.append("".join(current).strip(" .;!?"))
            current = []
    tail = "".join(current).strip(" .;!?")
    if tail:
        out.append(tail)
    return [s for s in out if s]


def _dedupe_spans(
    spans: list[tuple[float | None, float | None]],
) -> list[tuple[float | None, float | None]]:
    out: list[tuple[float | None, float | None]] = []
    for span in spans:
        if span not in out:
            out.append(span)
    return out


def _coerce_index(value: Any, n_options: int) -> int | None:
    if value in (None, ""):
        return None
    try:
        idx = int(value)
    except (TypeError, ValueError):
        return None
    if n_options and 0 <= idx < n_options:
        return idx
    return idx if n_options == 0 else None


def _coerce_confidence(value: Any, *, default: float) -> float:
    try:
        return _clamp(float(value))
    except (TypeError, ValueError):
        return _clamp(default)


def _coerce_ids(value: Any) -> list[str]:
    if not isinstance(value, (list, tuple)):
        return []
    out: list[str] = []
    for item in value:
        text = str(item).strip()
        if text and text not in out:
            out.append(text)
    return out


def _softmax_confidence(logprobs: list[float], best_idx: int) -> float:
    """Softmax over option log-likelihoods, returning the winner's probability mass."""
    if not logprobs:
        return 0.0
    peak = max(logprobs)
    exps = [math.exp(lp - peak) for lp in logprobs]
    total = sum(exps)
    if total <= 0:
        return 0.0
    return _clamp(exps[best_idx] / total)


def _stable_tiebreak(question_id: str, option: str) -> str:
    """Deterministic, process-independent tie-break key for forced MCQ guesses.

    Python's built-in ``hash()`` is salted per process (``PYTHONHASHSEED``), so it would make forced
    guesses non-reproducible across runs; a content hash keeps the pick stable and run-independent."""
    return hashlib.sha256(f"{question_id}\x00{option}".encode("utf-8")).hexdigest()


def _clamp(value: float) -> float:
    return max(0.0, min(1.0, float(value)))


def _format_span(start: float | None, end: float | None) -> str:
    if start is None and end is None:
        return ""
    s = "?" if start is None else f"{start:g}"
    e = "?" if end is None else f"{end:g}"
    return f" {s}-{e}s"


__all__ = ["answer_question", "serialize_evidence_packet"]
