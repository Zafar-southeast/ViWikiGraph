from __future__ import annotations

import math
import re
from collections import Counter, defaultdict
from typing import Mapping, Sequence

from viwikigraph.core.schemas import QAInstance, QAPrediction

# Metadata keys that may carry a question-type label, in priority order.
# NExT-QA/KnowIT adapters store ``question_type``; KnowIT also exposes ``QType``/``kg_type``.
_QUESTION_TYPE_KEYS = ("question_type", "QType", "qtype", "kg_type", "type")
_UNTYPED = "untyped"
# Scoring methods that mean "the LLM did not produce a usable answer" (parse failure or no LLM); these
# drive the ``fallback_rate`` health metric so a silent regression to the near-chance token-overlap
# guesser is visible in metrics.json.
_FALLBACK_METHODS = {"heuristic_overlap"}
# 95% two-sided normal quantile for the Wilson interval.
_WILSON_Z = 1.959963984540054


def accuracy(predicted: Sequence[int | None], gold: Sequence[int | None]) -> float:
    if not gold:
        return 0.0
    correct = sum(1 for pred, target in zip(predicted, gold) if pred is not None and target is not None and pred == target)
    return correct / len(gold)


def wilson_interval(correct: int, total: int, *, z: float = _WILSON_Z) -> tuple[float, float]:
    """Wilson score 95% confidence interval for a binomial proportion (correct/total).

    Used instead of a bare point accuracy because at n=50 the interval is ~±0.12 — wide enough that
    runs differing by a few questions (exp5/6/7 = .76/.78/.76) are statistically indistinguishable.
    Returns ``(0.0, 0.0)`` for an empty sample."""
    if total <= 0:
        return (0.0, 0.0)
    phat = correct / total
    denom = 1.0 + z * z / total
    center = (phat + z * z / (2 * total)) / denom
    margin = z * math.sqrt(phat * (1 - phat) / total + z * z / (4 * total * total)) / denom
    return (max(0.0, center - margin), min(1.0, center + margin))


def question_type_of(qa: QAInstance) -> str:
    """Return the question-type label for grouping (``question_type`` / KnowIT QType / fallback)."""
    for key in _QUESTION_TYPE_KEYS:
        value = qa.metadata.get(key)
        if value not in (None, ""):
            return str(value)
    return _UNTYPED


def exact_match(prediction: str, reference: str) -> float:
    return 1.0 if _normalize(prediction) == _normalize(reference) else 0.0


def token_f1(prediction: str, reference: str) -> float:
    pred_tokens = _normalize(prediction).split()
    ref_tokens = _normalize(reference).split()
    if not pred_tokens and not ref_tokens:
        return 1.0
    if not pred_tokens or not ref_tokens:
        return 0.0
    common = Counter(pred_tokens) & Counter(ref_tokens)
    same = sum(common.values())
    if same == 0:
        return 0.0
    precision = same / len(pred_tokens)
    recall = same / len(ref_tokens)
    return 2 * precision * recall / (precision + recall)


def evaluate_predictions(qas: list[QAInstance], predictions: list[QAPrediction]) -> tuple[dict, list[dict]]:
    by_question = {prediction.question_id: prediction for prediction in predictions}
    gold_indices: list[int | None] = []
    pred_indices: list[int | None] = []
    rows: list[dict] = []
    for qa in qas:
        prediction = by_question.get(qa.question_id)
        pred_index = prediction.predicted_index if prediction else None
        gold_indices.append(qa.answer_index)
        pred_indices.append(pred_index)
        row = {
            "question_id": qa.question_id,
            "video_id": qa.video_id,
            "gold_index": qa.answer_index,
            "predicted_index": pred_index,
            "correct": pred_index is not None and qa.answer_index is not None and pred_index == qa.answer_index,
        }
        if qa.answer_text and prediction:
            row["em"] = exact_match(prediction.answer, qa.answer_text)
            row["f1"] = token_f1(prediction.answer, qa.answer_text)
        rows.append(row)
    total = len(qas)
    correct = sum(
        1 for pred, gold in zip(pred_indices, gold_indices)
        if pred is not None and gold is not None and pred == gold
    )
    ci_low, ci_high = wilson_interval(correct, total)
    matched = [by_question[qa.question_id] for qa in qas if qa.question_id in by_question]
    method_counts = Counter(p.scoring_method for p in matched)
    fallbacks = sum(count for method, count in method_counts.items() if method in _FALLBACK_METHODS)
    metrics = {
        "count": total,
        "accuracy": accuracy(pred_indices, gold_indices),
        "answered": sum(1 for item in pred_indices if item is not None),
        "accuracy_ci_low": ci_low,
        "accuracy_ci_high": ci_high,
        # Health metric: fraction answered by the near-chance token-overlap fallback (LLM JSON failure
        # or no LLM) rather than a real LLM choice. Track it so the JSON-robustness regression that
        # produced exp7's 26% fallback rate cannot recur silently.
        "fallback_rate": (fallbacks / total) if total else 0.0,
        "method_counts": dict(sorted(method_counts.items())),
        "by_question_type": _by_question_type(qas, by_question),
    }
    em_values = [row["em"] for row in rows if "em" in row]
    f1_values = [row["f1"] for row in rows if "f1" in row]
    if em_values:
        metrics["exact_match"] = sum(em_values) / len(em_values)
    if f1_values:
        metrics["token_f1"] = sum(f1_values) / len(f1_values)
    return metrics, rows


def _by_question_type(
    qas: Sequence[QAInstance], by_question: Mapping[str, QAPrediction]
) -> dict[str, dict]:
    """Per-question-type count/accuracy with Wilson CIs (non-recursive; safe to call from anywhere)."""
    groups: dict[str, list[QAInstance]] = defaultdict(list)
    for qa in qas:
        groups[question_type_of(qa)].append(qa)
    out: dict[str, dict] = {}
    for qtype in sorted(groups):
        group = groups[qtype]
        answered = 0
        correct = 0
        for qa in group:
            prediction = by_question.get(qa.question_id)
            pred_index = prediction.predicted_index if prediction else None
            if pred_index is not None:
                answered += 1
                if qa.answer_index is not None and pred_index == qa.answer_index:
                    correct += 1
        n = len(group)
        lo, hi = wilson_interval(correct, n)
        out[qtype] = {
            "count": n,
            "correct": correct,
            "answered": answered,
            "accuracy": (correct / n) if n else 0.0,
            "accuracy_ci_low": lo,
            "accuracy_ci_high": hi,
        }
    return out


def _normalize(text: str) -> str:
    text = text.lower().strip()
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    return " ".join(text.split())
