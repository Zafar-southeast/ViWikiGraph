"""Deliverable assembly for a ViWikiGraph experiment (SPEC §10).

This module turns the per-experiment artifacts into the two human/machine-facing files that live at
``outputs/{experiment_id}/{dataset}/{split}/``:

  - ``report.md``        — experiment id, model, dataset/split, sample size & sampling, QA accuracy
                           (with a per-question-type breakdown), open-ended EM/F1 where applicable,
                           intrinsic wiki statistics (Narrative Support Rate, entity/triple/temporal/
                           contradiction counts, Media Correctness, Provenance Exactness), the
                           conditional-verification trigger rate, and a few example evidence traces.
  - ``run_config.json``  — resolved config + budgets + model + git commit + sampling seed.

Everything here is deterministic and uses no LLM. QA metrics and per-question-type grouping reuse
:mod:`viwikigraph.qa.evaluation` so the report agrees with ``eval/metrics.json``.
"""

from __future__ import annotations

import subprocess
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping, Sequence

from viwikigraph.qa.evaluation import evaluate_predictions, question_type_of
from viwikigraph.core.io import ensure_dir, write_json
from viwikigraph.core.schemas import (
    KGItem,
    QAInstance,
    QAPrediction,
    ValidationResult,
    WikiSection,
)

_MAX_TRACE_EXAMPLES = 5


@dataclass(slots=True)
class PackageStats:
    """Intrinsic knowledge-package statistics aggregated across the built videos.

    All fields are plain counts/ratios so the struct round-trips through JSON. ``from_*`` builders
    derive the values from package artifacts; :meth:`narrative_support_rate` and
    :meth:`media_correctness` expose the paper's intrinsic ratios.
    """

    total_claims: int = 0
    kept_claims: int = 0
    num_entities: int = 0
    num_triples: int = 0
    num_temporal: int = 0
    num_contradiction: int = 0
    media_total: int = 0
    media_present: int = 0
    items_total: int = 0
    items_with_provenance: int = 0
    num_links: int = 0
    link_quality_mean: float | None = None
    video_count: int = 0
    extra: dict[str, Any] = field(default_factory=dict)

    @property
    def narrative_support_rate(self) -> float | None:
        """Kept / total atomic claims (paper Narrative Support Rate); ``None`` when no claims."""
        if self.total_claims <= 0:
            return None
        return self.kept_claims / self.total_claims

    @property
    def media_correctness(self) -> float | None:
        """Fraction of linked media paths that resolve to a real file; ``None`` when no media."""
        if self.media_total <= 0:
            return None
        return self.media_present / self.media_total

    @property
    def provenance_exactness(self) -> float | None:
        """Fraction of items carrying non-empty provenance; ``None`` when no items."""
        if self.items_total <= 0:
            return None
        return self.items_with_provenance / self.items_total

    def to_dict(self) -> dict[str, Any]:
        data: dict[str, Any] = {
            "total_claims": self.total_claims,
            "kept_claims": self.kept_claims,
            "num_entities": self.num_entities,
            "num_triples": self.num_triples,
            "num_temporal": self.num_temporal,
            "num_contradiction": self.num_contradiction,
            "media_total": self.media_total,
            "media_present": self.media_present,
            "items_total": self.items_total,
            "items_with_provenance": self.items_with_provenance,
            "num_links": self.num_links,
            "link_quality_mean": self.link_quality_mean,
            "video_count": self.video_count,
            "narrative_support_rate": self.narrative_support_rate,
            "media_correctness": self.media_correctness,
            "provenance_exactness": self.provenance_exactness,
        }
        if self.extra:
            data["extra"] = dict(self.extra)
        return data


def collect_package_stats(
    sections: Sequence[WikiSection],
    kg_items: Sequence[KGItem],
    validations: Sequence[ValidationResult],
    *,
    media_paths: Sequence[str] = (),
    media_root: str | Path | None = None,
    num_links: int = 0,
    link_validations: Sequence[ValidationResult] = (),
    video_count: int = 0,
) -> PackageStats:
    """Aggregate intrinsic statistics from package artifacts (deterministic, no LLM).

    - ``total_claims``/``kept_claims`` from narrative sections vs. their kept ``ValidationResult``s.
    - entity/triple/temporal/contradiction counts from KG items by ``item_type``.
    - media correctness from whether each linked path resolves under ``media_root`` (or as-is).
    - provenance exactness from sections + KG items carrying non-empty provenance.
    """
    kept_ids = {v.item_id for v in validations if v.decision == "keep"}
    total_claims = 0
    kept_claims = 0
    for section in sections:
        n = len(section.claims)
        total_claims += n
        if section.section_id in kept_ids:
            kept_claims += n

    num_entities = sum(1 for item in kg_items if item.item_type in {"entity", "object", "location"})
    num_triples = sum(len(item.triples) for item in kg_items) + sum(
        1 for item in kg_items if item.item_type == "triple"
    )
    num_temporal = sum(1 for item in kg_items if item.item_type == "temporal_link")
    num_contradiction = sum(1 for item in kg_items if item.item_type == "contradiction_link")

    media_total = len(media_paths)
    base = Path(media_root) if media_root is not None else None
    media_present = 0
    for raw in media_paths:
        path = Path(raw)
        if not path.is_absolute() and base is not None:
            path = base / path
        if path.exists():
            media_present += 1

    items_total = len(sections) + len(kg_items)
    items_with_provenance = sum(1 for s in sections if s.provenance) + sum(
        1 for item in kg_items if item.provenance
    )

    # Cross-modal-link quality (proxy for Link Correctness in the absence of gold link labels):
    # the mean q_link of the link-validation results (item_type == "cross_modal_link").
    link_scores = [v.link for v in link_validations if v.item_type == "cross_modal_link"]
    link_quality_mean = (sum(link_scores) / len(link_scores)) if link_scores else None

    return PackageStats(
        total_claims=total_claims,
        kept_claims=kept_claims,
        num_entities=num_entities,
        num_triples=num_triples,
        num_temporal=num_temporal,
        num_contradiction=num_contradiction,
        media_total=media_total,
        media_present=media_present,
        items_total=items_total,
        items_with_provenance=items_with_provenance,
        num_links=num_links,
        link_quality_mean=link_quality_mean,
        video_count=video_count,
    )


def write_report(
    out_dir: str | Path,
    *,
    experiment_id: str,
    dataset: str,
    split: str,
    model: str,
    sample_info: Mapping[str, Any] | None = None,
    qas: Sequence[QAInstance],
    predictions: Sequence[QAPrediction],
    validations: Sequence[ValidationResult] | None = None,
    package_stats: PackageStats | Mapping[str, Any] | None = None,
) -> Path:
    """Write ``report.md`` and ``run_config.json`` under ``out_dir`` and return the report path.

    ``out_dir`` is the experiment/dataset/split directory
    (``outputs/{experiment_id}/{dataset}/{split}``). The function is deterministic and performs no
    network/LLM calls, so it is safe under ``--dry-run`` and offline tests.
    """
    out_dir = ensure_dir(out_dir)
    sample_info = dict(sample_info or {})

    metrics, rows = evaluate_predictions(list(qas), list(predictions))
    by_type = _per_question_type(qas, predictions)
    stats = _coerce_stats(package_stats)
    verify_total, verify_triggered = _verification_trigger(predictions)
    examples = _example_traces(qas, predictions)

    report_md = _render_report(
        experiment_id=experiment_id,
        dataset=dataset,
        split=split,
        model=model,
        sample_info=sample_info,
        metrics=metrics,
        by_type=by_type,
        stats=stats,
        verify_total=verify_total,
        verify_triggered=verify_triggered,
        examples=examples,
    )
    report_path = out_dir / "report.md"
    report_path.write_text(report_md, encoding="utf-8")

    write_json(
        out_dir / "run_config.json",
        _run_config(
            experiment_id=experiment_id,
            dataset=dataset,
            split=split,
            model=model,
            sample_info=sample_info,
            metrics=metrics,
            stats=stats,
            verify_total=verify_total,
            verify_triggered=verify_triggered,
        ),
    )
    return report_path


# --- internals --------------------------------------------------------------------------------


def _coerce_stats(value: PackageStats | Mapping[str, Any] | None) -> PackageStats:
    if value is None:
        return PackageStats()
    if isinstance(value, PackageStats):
        return value
    known = {
        "total_claims",
        "kept_claims",
        "num_entities",
        "num_triples",
        "num_temporal",
        "num_contradiction",
        "media_total",
        "media_present",
        "items_total",
        "items_with_provenance",
        "num_links",
        "video_count",
    }
    fields = {key: int(value.get(key, 0)) for key in known}
    link_quality_mean = value.get("link_quality_mean")
    extra = {key: item for key, item in value.items() if key not in known}
    # Drop derived ratios if a serialized PackageStats dict was passed back in.
    for derived in ("narrative_support_rate", "media_correctness", "provenance_exactness", "link_quality_mean"):
        extra.pop(derived, None)
    nested = extra.pop("extra", None)
    if isinstance(nested, Mapping):
        extra.update(nested)
    return PackageStats(
        link_quality_mean=float(link_quality_mean) if link_quality_mean is not None else None,
        extra=extra,
        **fields,
    )


def _per_question_type(
    qas: Sequence[QAInstance], predictions: Sequence[QAPrediction]
) -> dict[str, dict[str, Any]]:
    """Per-question-type metrics, reusing :func:`evaluate_predictions` per group."""
    groups: dict[str, list[QAInstance]] = defaultdict(list)
    for qa in qas:
        groups[question_type_of(qa)].append(qa)
    by_id = {prediction.question_id: prediction for prediction in predictions}
    result: dict[str, dict[str, Any]] = {}
    for qtype in sorted(groups):
        group_qas = groups[qtype]
        group_preds = [by_id[qa.question_id] for qa in group_qas if qa.question_id in by_id]
        metrics, _ = evaluate_predictions(group_qas, group_preds)
        result[qtype] = metrics
    return result


def _verification_trigger(predictions: Sequence[QAPrediction]) -> tuple[int, int]:
    """Count answers for which conditional verification fired.

    A prediction counts as verified when its ``scoring_method`` mentions verification or any
    evidence-trace entry records a verdict/verification flag (set by ``qa.conditional_verify``).
    """
    total = len(predictions)
    triggered = 0
    for prediction in predictions:
        if _is_verified(prediction):
            triggered += 1
    return total, triggered


def _is_verified(prediction: QAPrediction) -> bool:
    method = (prediction.scoring_method or "").lower()
    if "verif" in method:
        return True
    for entry in prediction.evidence_trace:
        if not isinstance(entry, Mapping):
            continue
        if entry.get("verified") or entry.get("verification") or "verdict" in entry:
            return True
    return False


def _example_traces(
    qas: Sequence[QAInstance], predictions: Sequence[QAPrediction]
) -> list[dict[str, Any]]:
    """Pick a few predictions with non-empty evidence traces as illustrative examples."""
    by_id = {qa.question_id: qa for qa in qas}
    examples: list[dict[str, Any]] = []
    for prediction in predictions:
        if not prediction.evidence_trace:
            continue
        qa = by_id.get(prediction.question_id)
        examples.append(
            {
                "question_id": prediction.question_id,
                "video_id": prediction.video_id,
                "question": qa.question if qa else "",
                "answer": prediction.answer,
                "confidence": prediction.confidence,
                "scoring_method": prediction.scoring_method,
                "trace": list(prediction.evidence_trace),
            }
        )
        if len(examples) >= _MAX_TRACE_EXAMPLES:
            break
    return examples


def _git_commit() -> str | None:
    try:
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    commit = result.stdout.strip()
    return commit or None


def _run_config(
    *,
    experiment_id: str,
    dataset: str,
    split: str,
    model: str,
    sample_info: Mapping[str, Any],
    metrics: Mapping[str, Any],
    stats: PackageStats,
    verify_total: int,
    verify_triggered: int,
) -> dict[str, Any]:
    sample_info = dict(sample_info)
    config: dict[str, Any] = {
        "experiment_id": experiment_id,
        "dataset": dataset,
        "split": split,
        "model": model,
        "mode": "rag_only",
        "training_enabled": False,
        "git_commit": _git_commit(),
        "sampling": {
            "limit": sample_info.get("limit"),
            "sample_seed": sample_info.get("sample_seed", sample_info.get("seed")),
            "stratify_by": sample_info.get("stratify_by"),
            "sample_size": int(metrics.get("count", 0)),
        },
        "budgets": dict(sample_info.get("budgets", {})),
        "config": sample_info.get("config"),
        "config_hash": sample_info.get("config_hash"),
        "metrics": dict(metrics),
        "package_stats": stats.to_dict(),
        "verification": {
            "total": verify_total,
            "triggered": verify_triggered,
            "trigger_rate": (verify_triggered / verify_total) if verify_total else None,
        },
    }
    return config


def _fmt_ratio(value: float | None) -> str:
    return "n/a" if value is None else f"{value:.4f}"


def _fmt_count_ratio(numerator: int, denominator: int, value: float | None) -> str:
    return "n/a" if value is None else f"{value:.4f} ({numerator}/{denominator})"


def _fmt_ci(metrics: Mapping[str, Any]) -> str:
    low = metrics.get("accuracy_ci_low")
    high = metrics.get("accuracy_ci_high")
    if low is None or high is None:
        return ""
    return f"95% CI [{float(low):.3f}, {float(high):.3f}]"


def _render_report(
    *,
    experiment_id: str,
    dataset: str,
    split: str,
    model: str,
    sample_info: Mapping[str, Any],
    metrics: Mapping[str, Any],
    by_type: Mapping[str, Mapping[str, Any]],
    stats: PackageStats,
    verify_total: int,
    verify_triggered: int,
    examples: Sequence[Mapping[str, Any]],
) -> str:
    lines: list[str] = [f"# ViWikiGraph Report — {experiment_id}", ""]

    lines.append("## Experiment")
    lines.append("")
    lines.append(f"- Experiment id: `{experiment_id}`")
    lines.append(f"- Model: `{model}`")
    lines.append(f"- Dataset / split: `{dataset}` / `{split}`")
    lines.append("- Mode: `rag_only` (no training)")
    lines.append("")

    lines.append("## Sample")
    lines.append("")
    limit = sample_info.get("limit")
    seed = sample_info.get("sample_seed", sample_info.get("seed"))
    stratify = sample_info.get("stratify_by")
    lines.append(f"- Sample size: {metrics.get('count', 0)}")
    lines.append(f"- Limit: {'full split' if limit in (None, '') else limit}")
    lines.append(f"- Sample seed: {seed if seed not in (None, '') else 'n/a'}")
    lines.append(f"- Stratified by: {stratify if stratify not in (None, '') else 'none'}")
    lines.append("")

    lines.append("## QA Accuracy")
    lines.append("")
    lines.append(f"- Accuracy: {_fmt_ratio(metrics.get('accuracy'))} {_fmt_ci(metrics)}".rstrip())
    lines.append(f"- Answered: {metrics.get('answered', 0)} / {metrics.get('count', 0)}")
    if "fallback_rate" in metrics:
        lines.append(
            "- Fallback rate (non-LLM token-overlap answers): "
            f"{_fmt_ratio(metrics.get('fallback_rate'))}"
        )
    if metrics.get("method_counts"):
        rendered = ", ".join(f"{m}={c}" for m, c in metrics["method_counts"].items())
        lines.append(f"- Scoring methods: {rendered}")
    if "exact_match" in metrics or "token_f1" in metrics:
        lines.append(f"- Open-ended EM: {_fmt_ratio(metrics.get('exact_match'))}")
        lines.append(f"- Open-ended token-F1: {_fmt_ratio(metrics.get('token_f1'))}")
    lines.append("")

    lines.append("### Per question type")
    lines.append("")
    if by_type:
        lines.append("| Type | Count | Accuracy | 95% CI | EM | F1 |")
        lines.append("| --- | ---: | ---: | :---: | ---: | ---: |")
        for qtype in by_type:
            row = by_type[qtype]
            lines.append(
                f"| {qtype} | {row.get('count', 0)} | {_fmt_ratio(row.get('accuracy'))} "
                f"| {_fmt_ci(row)} | {_fmt_ratio(row.get('exact_match'))} | {_fmt_ratio(row.get('token_f1'))} |"
            )
    else:
        lines.append("_No questions._")
    lines.append("")

    lines.append("## Intrinsic Wiki Statistics")
    lines.append("")
    lines.append(f"- Videos in package: {stats.video_count}")
    lines.append(
        "- Narrative Support Rate (kept/total claims): "
        f"{_fmt_count_ratio(stats.kept_claims, stats.total_claims, stats.narrative_support_rate)}"
    )
    lines.append(f"- Entities: {stats.num_entities}")
    lines.append(f"- Triples: {stats.num_triples}")
    lines.append(f"- Temporal links: {stats.num_temporal}")
    lines.append(f"- Contradiction links: {stats.num_contradiction}")
    lines.append(
        f"- Cross-modal links: {stats.num_links} (mean q_link: {_fmt_ratio(stats.link_quality_mean)})"
    )
    lines.append(
        "- Media Correctness (present/linked): "
        f"{_fmt_count_ratio(stats.media_present, stats.media_total, stats.media_correctness)}"
    )
    lines.append(
        "- Provenance Exactness (items with provenance): "
        f"{_fmt_count_ratio(stats.items_with_provenance, stats.items_total, stats.provenance_exactness)}"
    )
    lines.append("")

    lines.append("## Conditional Verification")
    lines.append("")
    rate = (verify_triggered / verify_total) if verify_total else None
    lines.append(
        "- Trigger rate (verified/answers): "
        f"{_fmt_count_ratio(verify_triggered, verify_total, rate)}"
    )
    lines.append("")

    refinement = stats.extra.get("refinement") if isinstance(stats.extra, Mapping) else None
    if isinstance(refinement, Mapping):
        proposed = int(refinement.get("proposed", 0))
        accepted = int(refinement.get("accepted", 0))
        applied = int(refinement.get("applied", 0))
        lines.append("## Evidence-Gated Refinement")
        lines.append("")
        lines.append(f"- Patches proposed: {proposed}")
        acc_rate = (accepted / proposed) if proposed else None
        lines.append(f"- Patch Acceptance Precision (accepted/proposed): {_fmt_count_ratio(accepted, proposed, acc_rate)}")
        lines.append(f"- Patches applied (written back): {applied}")
        lines.append("")

    lines.append("## Example Evidence Traces")
    lines.append("")
    if examples:
        for example in examples:
            lines.append(f"### {example['question_id']} (video `{example['video_id']}`)")
            lines.append("")
            if example.get("question"):
                lines.append(f"- Question: {example['question']}")
            lines.append(f"- Answer: {example['answer']}")
            lines.append(f"- Confidence: {float(example['confidence']):.3f}")
            lines.append(f"- Scoring method: {example['scoring_method']}")
            for entry in example["trace"]:
                lines.append(f"  - {_fmt_trace_entry(entry)}")
            lines.append("")
    else:
        lines.append("_No evidence traces available._")
        lines.append("")

    return "\n".join(lines).rstrip() + "\n"


def _fmt_trace_entry(entry: Any) -> str:
    if not isinstance(entry, Mapping):
        return str(entry)
    parts: list[str] = []
    for key in ("claim", "section_ids", "kg_item_ids", "subtitle_ids", "media_paths", "knowledge"):
        if key in entry and entry[key] not in (None, "", []):
            parts.append(f"{key}={entry[key]}")
    for key, value in entry.items():
        if key in {"claim", "section_ids", "kg_item_ids", "subtitle_ids", "media_paths", "knowledge"}:
            continue
        if value not in (None, "", []):
            parts.append(f"{key}={value}")
    return "; ".join(parts) if parts else "(empty)"
