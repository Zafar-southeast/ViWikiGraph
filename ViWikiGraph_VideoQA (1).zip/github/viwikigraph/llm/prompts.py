"""Prompt builders and tolerant JSON parsing for every LLM-grounded ViWikiGraph stage.

These are pure functions (no I/O, no network). Each ``*_prompt`` returns a prompt string that asks
the model for strict JSON; :func:`parse_json` recovers the object even when the model wraps it in a
Markdown code fence or adds prose. Keeping all prompts in one place makes the paper→prompt mapping
auditable and lets every stage share the same JSON discipline.

Paper references (docs/paper/ViWikiGraph_VideoQA.pdf):
  - extraction          → Phase 1, eq. 10 (evidence units carry entities/objects/actions/triples)
  - narrative           → Phase 2, eq. 13-14 (schema sections drafted from assigned evidence)
  - kg                  → Phase 3, eq. 18-24 (entities/events/triples/temporal/contradiction)
  - router              → eq. 30 (evidence-need vector r_q)
  - mcq / open / verify → eq. 34-40 (serialize → answer → conditional verification)
"""

from __future__ import annotations

import json
import re
from typing import Any

# Fixed narrative schema (paper §IV-B). Scene is repeatable.
NARRATIVE_SECTION_TYPES = (
    "metadata",
    "summary",
    "scene",
    "entity",
    "object",
    "location",
    "event",
    "provenance",
)

_GROUNDING_RULE = (
    "Use ONLY the information present in the provided evidence. Do not invent facts, names, times, "
    "or relationships. If the evidence is insufficient, return fewer items rather than guessing."
)


def extraction_prompt(text: str, modality: str) -> str:
    """Extract grounded structured facts from one evidence unit (Phase 1)."""
    return f"""
You are extracting structured knowledge from a single piece of video evidence ({modality}).
{_GROUNDING_RULE}

Return STRICT JSON with this shape:
{{
  "entities": ["proper-noun people/characters/places"],
  "objects": ["physical objects visible or mentioned"],
  "actions": ["short verb phrases"],
  "events": ["short event descriptions"],
  "triples": [{{"subject": "...", "relation": "...", "object": "..."}}]
}}

Evidence text:
\"\"\"{text}\"\"\"
""".strip()


def narrative_prompt(video_id: str, evidence_digest: str) -> str:
    """Draft the schema-guided narrative wiki sections (Phase 2, eq. 13-14)."""
    types = ", ".join(NARRATIVE_SECTION_TYPES)
    return f"""
You are writing a schema-guided narrative wiki for video "{video_id}" from timestamped evidence.
{_GROUNDING_RULE}

Produce sections following this fixed schema (types: {types}). "scene" may repeat (one per coherent
moment, in temporal order). Each section's claims must be atomic, independently checkable sentences,
and every claim must be supported by the cited evidence ids.

Return STRICT JSON:
{{
  "sections": [
    {{
      "type": "summary",
      "heading": "Global Summary",
      "content": "prose grounded in the evidence",
      "claims": ["atomic claim 1", "atomic claim 2"],
      "evidence_ids": ["sub_1", "visual_concept_2"]
    }}
  ]
}}

Cite ONLY evidence ids that appear below. Evidence:
{evidence_digest}
""".strip()


def kg_prompt(video_id: str, evidence_digest: str, narrative_digest: str) -> str:
    """Extract the KG-oriented wiki (Phase 3, eq. 18-24)."""
    return f"""
You are building a knowledge graph for video "{video_id}" from its evidence and narrative wiki.
{_GROUNDING_RULE}

Return STRICT JSON:
{{
  "entities":  [{{"label": "...", "type": "person|object|location", "description": "...", "evidence_ids": ["..."]}}],
  "events":    [{{"label": "...", "description": "...", "participants": ["..."], "evidence_ids": ["..."]}}],
  "triples":   [{{"subject": "...", "relation": "...", "object": "...", "evidence_ids": ["..."]}}],
  "temporal_links":      [{{"before": "eventA", "after": "eventB", "relation": "BEFORE|AFTER|DURING", "evidence_ids": ["..."]}}],
  "contradiction_links": [{{"item_a": "...", "item_b": "...", "reason": "...", "evidence_ids": ["..."]}}]
}}

Add a contradiction link ONLY when two grounded statements are mutually inconsistent.
Cite ONLY evidence ids present below.

Narrative wiki:
{narrative_digest}

Evidence:
{evidence_digest}
""".strip()


def router_prompt(question: str, options: list[str]) -> str:
    """Analyze the question to produce the evidence-need vector (eq. 30)."""
    opts = "\n".join(f"{i}. {o}" for i, o in enumerate(options)) if options else "(open-ended)"
    return f"""
Classify what evidence is needed to answer this video question. Return STRICT JSON with booleans:
{{
  "needs_narrative": bool,    // scene summaries / descriptive context
  "needs_kg": bool,           // entities, relations, events
  "needs_temporal": bool,     // ordering / before-after / when
  "needs_visual": bool,       // objects, colors, on-screen appearance, OCR
  "needs_knowledge": bool,    // background/world knowledge beyond the clip
  "needs_verification": bool  // ambiguous or easily-confused; double-check the answer
}}

Question: {question}
Options:
{opts}
""".strip()


def mcq_prompt(question: str, options: list[str], serialized_evidence: str) -> str:
    """Wiki-grounded multiple-choice answering (eq. 34-36)."""
    opts = "\n".join(f"{i}. {o}" for i, o in enumerate(options))
    return f"""
Answer the multiple-choice question using ONLY the ViWikiGraph evidence below. Choose the single
best option. {_GROUNDING_RULE}

Do not choose an option just because its words appear in the evidence or question. Choose it only
when the evidence supports the full meaning of the option. For temporal, causal, count, color, and
action questions, match the requested event/reason/number/attribute/action exactly; reject options
that are merely related to the scene but unsupported by cited evidence.

For temporal questions containing before/after/then/next/first/last/start/end, first use the
Temporal Timeline Evidence if present. Identify the target event in timestamp order, then choose the
option whose action occurs immediately before or after that target as requested. Do not answer from a
nearby frame unless its timestamp/order matches the question.

Return STRICT JSON:
{{"answer_index": int, "answer": "the chosen option text", "confidence": 0.0-1.0,
  "evidence_ids": ["ids that support the choice"], "rationale": "one sentence"}}

{serialized_evidence}

Options:
{opts}
""".strip()


def mcq_tc_prompt(question: str, options: list[str], serialized_evidence: str) -> str:
    """TC-focused MCQ answering.

    NExT-QA TC questions often ask what happens *while/as/when* another event is happening. This is
    different from TN/TP ordering: the model should anchor the condition event and inspect
    simultaneous or very-near evidence, including background actors and subtle reactions.
    """
    opts = "\n".join(f"{i}. {o}" for i, o in enumerate(options))
    return f"""
Answer the multiple-choice TC question using ONLY the ViWikiGraph evidence below. Choose the single
best option. {_GROUNDING_RULE}

This is a Temporal Concurrent / "when/as/while" style question. Do NOT solve it as before/after
ordering. First identify the condition event mentioned in the question, then choose what is happening
at the same moment or immediate local scene around that condition.

Pay special attention to:
- background people or animals, not only the main foreground actor;
- facial expression and emotion/reaction (sad, frown, happy, proud, excited, tired);
- small actions with hands, toys, flags, bowls, or other objects;
- the exact actor named in the question (for example "lady in black", "person on the right").

Reject an option if it is only a general scene description, an action from a different moment, or an
emotion/action not directly supported by the cited evidence.

Return STRICT JSON:
{{"answer_index": int, "answer": "the chosen option text", "confidence": 0.0-1.0,
  "evidence_ids": ["ids that support the choice"], "rationale": "one sentence"}}

{serialized_evidence}

Options:
{opts}
""".strip()


def open_prompt(question: str, serialized_evidence: str) -> str:
    """Wiki-grounded open-ended answering (NExT-QA OE)."""
    return f"""
Answer the question concisely using ONLY the ViWikiGraph evidence below. {_GROUNDING_RULE}

Return STRICT JSON:
{{"answer": "short answer", "confidence": 0.0-1.0, "evidence_ids": ["supporting ids"]}}

{serialized_evidence}
""".strip()


def verification_prompt(question: str, draft_answer: str, claims: list[str], serialized_evidence: str) -> str:
    """Conditional verification of a draft answer's claims (eq. 37-40)."""
    claim_lines = "\n".join(f"- {c}" for c in claims) if claims else f"- {draft_answer}"
    return f"""
Verify a draft answer against the evidence. For each claim mark whether the evidence supports it
(sup), does not support it (unsup), or contradicts it (contr). Then give a revised answer that keeps
only supported content. {_GROUNDING_RULE}

Return STRICT JSON:
{{"claims": [{{"claim": "...", "verdict": "sup|unsup|contr", "evidence_ids": ["..."]}}],
  "revised_answer": "...", "confidence": 0.0-1.0}}

Question: {question}
Draft answer: {draft_answer}
Draft claims:
{claim_lines}

{serialized_evidence}
""".strip()


def video_vision_prompt(num_frames: int, question_hints: list[str] | None = None) -> str:
    """Vision extraction over frames sampled from one video (v1 visual stream via the same LLM).

    Asks a vision-capable model to describe each frame and extract grounded visual facts + on-screen
    text (OCR), in temporal order. Output feeds the visual EvidenceUnits (caption/visual_concept/ocr)."""
    hint = ""
    if question_hints:
        joined = "; ".join(h for h in question_hints if h)[:1200]
        if joined:
            hint = (
                "\nFocus especially on content relevant to these questions/options: "
                f"{joined} (but describe only what is visible)."
            )
    return f"""
You are analyzing {num_frames} frames sampled in temporal order from a single video (index 0 = first).
{_GROUNDING_RULE}

For EACH frame, describe what is visible and extract grounded visual facts. Be especially
action-focused: write concrete verb phrases for human/animal motion and posture changes such as
jumping, bowing, clapping, raising hands, lowering hands, standing up, sitting down, bending,
crouching, walking, running, lifting, falling, licking, touching, holding, turning, looking, entering,
leaving, and putting objects down. If motion is ambiguous, say "possible ..." rather than guessing
confidently. When the focus hints include answer-option actions, actively check whether each
candidate action is visible in the frame. Put matched or possibly matched candidate actions in
"actions" using the same plain wording where possible. If adjacent sampled frames show a state change,
describe that transition in "events" (for example, "dog goes from licking cat to going under table",
"girl moves from low/crouched position to hands raised").
Transcribe any on-screen
text (signs, captions, UI) verbatim as OCR. Describe only what is actually visible — do not infer.

Return STRICT JSON:
{{"frames": [
  {{"index": 0, "description": "one sentence", "objects": ["..."], "entities": ["named people/places"],
    "actions": ["short verb phrases"], "events": ["short event descriptions"], "ocr": "on-screen text or empty"}}
]}}{hint}
""".strip()


def linking_prompt(video_id: str, item_digest: str) -> str:
    """Propose typed cross-modal evidence links among EXISTING items (v1 §III-C, eq. 20).

    The model may only connect ids that appear in ``item_digest`` and must choose a link type from the
    fixed set; the deterministic linker already covers evidence/time-grounded links, so this is an
    optional semantic-enrichment pass.
    """
    return f"""
You are connecting already-extracted items of a video knowledge package for "{video_id}" with typed
cross-modal evidence links. {_GROUNDING_RULE}

Only link ids that appear in the item list below. Choose link_type from EXACTLY this set:
claim_text, claim_media, triple_evidence, entity_image, event_clip, section_triple, time_align.

Return STRICT JSON:
{{"links": [{{"source_id": "...", "target_id": "...", "link_type": "section_triple"}}]}}

Items:
{item_digest}
""".strip()


def claim_decomposition_prompt(answer: str, question: str) -> str:
    """Decompose a draft answer into atomic, independently checkable claims (eq. 38 g_claim)."""
    return f"""
Decompose the draft answer into atomic, independently checkable claims (one fact each). Do NOT add
information beyond the answer. {_GROUNDING_RULE}

Return STRICT JSON: {{"claims": ["atomic claim 1", "atomic claim 2"]}}

Question: {question}
Draft answer: {answer}
""".strip()


def refinement_prompt(focus_cue: str, gap_kind: str, verified_evidence_digest: str, existing_item_digest: str) -> str:
    """Propose small evidence-gated wiki patches ΔW_q from VERIFIED evidence only (eq. 40).

    ``focus_cue`` is a topic hint (the question), explicitly NOT a fact source; patches must cite only
    evidence ids present in ``verified_evidence_digest`` and never use the question/answer as content.
    """
    return f"""
A downstream question exposed a "{gap_kind}" evidence gap in a video wiki. Propose at most a few SMALL
patches that ADD or REVISE a claim, triple, timestamp, provenance record, media link, or cross-modal
link, using ONLY the verified evidence below. {_GROUNDING_RULE}

The focus topic is "{focus_cue}". Treat it ONLY as a topic hint — never as a fact. Do not copy the
question or any answer into patch content. Cite only evidence ids listed under "Verified evidence".

Return STRICT JSON:
{{"patches": [{{"op": "add|revise", "target_type": "claim|triple|timestamp|provenance|media_link|cross_modal_link",
  "target_id": "existing id or null", "content": {{}}, "evidence_ids": ["..."], "rationale": "..."}}]}}

Existing items:
{existing_item_digest}

Verified evidence:
{verified_evidence_digest}
""".strip()


def option_scoring_prefix(question: str, serialized_evidence: str) -> str:
    """Prompt prefix for length-normalized option scoring via completions ``echo`` (eq. paper).

    Each candidate option is appended as the continuation and scored by
    :meth:`viwikigraph.llm.client.LLMClient.normalized_logprob`.
    """
    return f"""{serialized_evidence}

Question: {question}
Answer: """


def parse_json(text: str) -> dict[str, Any]:
    """Best-effort strict-JSON recovery from a model response (handles code fences / prose)."""
    text = (text or "").strip()
    if not text:
        return {}
    fenced = re.search(r"```(?:json)?\s*(.*?)```", text, re.DOTALL)
    if fenced:
        text = fenced.group(1).strip()
    try:
        loaded = json.loads(text)
        return loaded if isinstance(loaded, dict) else {"value": loaded}
    except json.JSONDecodeError:
        start, end = text.find("{"), text.rfind("}")
        if 0 <= start < end:
            try:
                return json.loads(text[start : end + 1])
            except json.JSONDecodeError:
                return {}
        return {}


_FENCE_RE = re.compile(r"```(?:json)?\s*(.*?)```", re.DOTALL)


def repair_json(text: str) -> Any:
    """Recover a JSON value (object or array) from imperfect model output, or raise.

    The proxy used for v1 (gemini behind an OpenAI-compatible shim) ignores ``response_format:
    json_object`` and routinely emits fenced markdown, trailing prose, top-level arrays, unescaped
    inner quotes, and ``max_tokens``-truncated tails. The QA/vision paths lose ~26% of answers /
    several frames to this. Recovery, in order:

      1. strip a ```json fence and ``json.loads``;
      2. ``raw_decode`` from the first ``{``/``[`` — drops leading prose and trailing "Extra data";
      3. structural repair — walk the value tracking the bracket stack + string state, recording every
         point a valid prefix can be closed (after each ``,`` / ``}`` / ``]`` and at end-of-text), then
         return the LARGEST such prefix that parses, re-balancing open brackets. This recovers the
         leading, intact fields (e.g. the MCQ ``answer_index``, which is emitted first) from
         unterminated-string / unescaped-quote / truncation breaks that all occur downstream;
      4. last resort: the outermost ``{`` … ``}`` substring.

    Raises :class:`json.JSONDecodeError` when nothing is recoverable, so callers that depend on the
    strict raise contract (extraction/kg/linking/validation/refinement, and the QA heuristic fallback)
    keep working. Note this returns the recovered value as-is (dict OR list); callers coerce to the
    object shape they expect.
    """
    raw = (text or "").strip()
    if not raw:
        raise json.JSONDecodeError("empty response", raw or " ", 0)
    candidate = raw
    fenced = _FENCE_RE.search(candidate)
    if fenced:
        candidate = fenced.group(1).strip()
    try:
        return json.loads(candidate)
    except json.JSONDecodeError:
        pass
    decoded = _raw_decode_first(candidate)
    if decoded is not None:
        return decoded
    repaired = _balanced_repair(candidate)
    if repaired is not None:
        return repaired
    start, end = candidate.find("{"), candidate.rfind("}")
    if 0 <= start < end:
        try:
            return json.loads(candidate[start : end + 1])
        except json.JSONDecodeError:
            pass
    raise json.JSONDecodeError("unrecoverable JSON in model response", candidate, 0)


def _raw_decode_first(text: str) -> Any | None:
    """Decode the first complete JSON value at the first structural char (leading prose / trailing
    'Extra data'). Only the outermost opener is tried — descending into an inner ``{`` would grab a
    nested sub-object (e.g. a single frame) instead of the whole document."""
    for i, ch in enumerate(text):
        if ch in "{[":
            try:
                obj, _ = json.JSONDecoder().raw_decode(text, i)
                return obj
            except json.JSONDecodeError:
                return None
    return None


def _balanced_repair(text: str) -> Any | None:
    """Return the largest valid prefix of a truncated/mid-broken JSON value, re-balanced and closed."""
    start = next((i for i, ch in enumerate(text) if ch in "{["), -1)
    if start < 0:
        return None
    stack: list[str] = []
    in_str = False
    escape = False
    cuts: list[tuple[int, str]] = []  # (exclusive cut index, closers to append)
    for i in range(start, len(text)):
        ch = text[i]
        if in_str:
            if escape:
                escape = False
            elif ch == "\\":
                escape = True
            elif ch == '"':
                in_str = False
            continue
        if ch == '"':
            in_str = True
        elif ch == "{":
            stack.append("}")
        elif ch == "[":
            stack.append("]")
        elif ch in "}]":
            if stack:
                stack.pop()
            cuts.append((i + 1, "".join(reversed(stack))))
        elif ch == ",":
            cuts.append((i, "".join(reversed(stack))))
    if not in_str and stack:
        cuts.append((len(text), "".join(reversed(stack))))
    for cut, closers in sorted(cuts, key=lambda c: c[0], reverse=True):
        try:
            return json.loads(text[start:cut] + closers)
        except json.JSONDecodeError:
            continue
    return None


def coerce_json_object(value: Any) -> dict[str, Any]:
    """Coerce a recovered JSON value to the object shape callers expect, or raise.

    A top-level array (the model wrapped its object in ``[...]``) is unwrapped to its first object
    element — the source of the ``'list' object has no attribute 'get'`` fallbacks in exp7. A bare
    scalar is not a usable answer object and raises so the caller's strict/heuristic fallback fires.
    """
    if isinstance(value, dict):
        return value
    if isinstance(value, list):
        for item in value:
            if isinstance(item, dict):
                return item
    raise json.JSONDecodeError("recovered JSON is not an object", json.dumps(value)[:200] or " ", 0)
