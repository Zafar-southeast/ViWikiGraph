from __future__ import annotations

import base64
import hashlib
import http.client
import json
import os
import time
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlparse

from viwikigraph.core.io import ensure_dir
from viwikigraph.llm.prompts import coerce_json_object, repair_json

# Image suffixes → MIME types for base64 data URLs in vision requests.
_IMAGE_MIME = {".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".webp": "image/webp", ".gif": "image/gif"}


USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)",
]


@dataclass(slots=True)
class LLMResponse:
    text: str
    raw: dict
    cached: bool = False


class LLMClient:
    def __init__(
        self,
        api_key: str | None = None,
        model: str | None = None,
        base_url: str | None = None,
        cache_dir: str | Path = ".cache/viwikigraph/llm",
        temperature: float = 0.0,
        max_tokens: int = 2000,
        retries: int = 2,
    ):
        load_env_file(".env")
        self.api_key = api_key if api_key is not None else os.environ.get("AIGCBEST_API_KEY", "")
        self.model = model or resolve_model()
        self.base_url = base_url or os.environ.get("AIGCBEST_BASE_URL", "https://api2.aigcbest.top")
        self.auth_scheme = os.environ.get("AIGCBEST_AUTH_SCHEME", "").strip()
        self.cache_dir = ensure_dir(cache_dir)
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.retries = retries

    @property
    def available(self) -> bool:
        """True when an API key is configured (cached responses work regardless)."""
        return bool(self.api_key)

    def chat(
        self,
        prompt: str,
        *,
        response_format: str = "text",
        cache_version: str = "v1",
        response_schema: dict | None = None,
    ) -> LLMResponse:
        key = self._cache_key(prompt, response_format, cache_version)
        cache_path = self.cache_dir / f"{key}.json"
        if cache_path.exists():
            raw = json.loads(cache_path.read_text(encoding="utf-8"))
            return LLMResponse(text=raw.get("text", ""), raw=raw.get("raw", {}), cached=True)
        if not self.api_key:
            raise RuntimeError("AIGCBEST_API_KEY is not set.")
        payload = {
            "model": self.model,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
            "messages": [{"role": "user", "content": prompt}],
        }
        if response_format == "json":
            raw = self._post_json(payload, response_schema)
        else:
            raw = self._post(payload)
        text = normalize_response_text(raw)
        cache_path.write_text(json.dumps({"text": text, "raw": raw}, ensure_ascii=False, indent=2), encoding="utf-8")
        return LLMResponse(text=text, raw=raw, cached=False)

    def _post_json(self, payload: dict, response_schema: dict | None) -> dict:
        """POST a JSON-format request, optionally with a strict ``json_schema`` response format.

        ``json_schema`` (P3) is opt-in via ``VIWIKIGRAPH_JSON_SCHEMA`` because the third-party proxy
        ignores ``json_object`` and its ``json_schema`` support is unverified; when the proxy rejects
        the schema (HTTP 400/422) we transparently retry with plain ``json_object`` so a probe never
        degrades a run. The client-side :func:`repair_json` remains the load-bearing safeguard either
        way."""
        schema_fmt = self._json_schema_format(response_schema)
        if schema_fmt is not None:
            payload["response_format"] = schema_fmt
            try:
                return self._post(payload)
            except RuntimeError as exc:
                if "HTTP 400" not in str(exc) and "HTTP 422" not in str(exc):
                    raise
        payload["response_format"] = {"type": "json_object"}
        return self._post(payload)

    @staticmethod
    def _json_schema_format(response_schema: dict | None) -> dict | None:
        """Build a ``json_schema`` response_format when a schema is supplied and the opt-in env is set."""
        if not response_schema:
            return None
        flag = os.environ.get("VIWIKIGRAPH_JSON_SCHEMA", "").strip().lower()
        if flag not in ("1", "true", "yes", "on"):
            return None
        return {"type": "json_schema", "json_schema": {"name": "response", "strict": True, "schema": response_schema}}

    def strict_json(
        self,
        prompt: str,
        *,
        cache_version: str = "v1",
        tolerant: bool = False,
        response_schema: dict | None = None,
    ) -> dict:
        """Return a JSON object from the model, raising :class:`json.JSONDecodeError` on failure.

        Default (``tolerant=False``) keeps the strict behaviour the build stages rely on (json.loads,
        then an outermost ``{`` … ``}`` slice, else drop-cache + raise). ``tolerant=True`` (the QA
        path: MCQ / open / verify) instead routes through :func:`repair_json` + :func:`coerce_json_object`
        so fenced markdown, trailing prose, top-level arrays, unescaped inner quotes, and truncated
        tails are recovered into a usable object instead of collapsing to the near-chance token-overlap
        fallback. It still raises (and drops the cache so a re-run re-fetches) when nothing is
        recoverable, preserving the never-abstain heuristic fallback for genuinely empty responses."""
        response = self.chat(
            prompt, response_format="json", cache_version=cache_version, response_schema=response_schema
        )
        text = response.text.strip()
        if tolerant:
            try:
                return coerce_json_object(repair_json(text))
            except json.JSONDecodeError:
                self._drop_cache(prompt, "json", cache_version)
                raise
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            start = text.find("{")
            end = text.rfind("}")
            if start >= 0 and end > start:
                try:
                    return json.loads(text[start : end + 1])
                except json.JSONDecodeError:
                    self._drop_cache(prompt, "json", cache_version)
                    raise
            self._drop_cache(prompt, "json", cache_version)
            raise

    def chat_vision(
        self,
        prompt: str,
        image_paths: list[str | Path],
        *,
        response_format: str = "text",
        cache_version: str = "v1",
        detail: str = "low",
        max_tokens: int | None = None,
    ) -> LLMResponse:
        """Multimodal chat: send ``prompt`` + one or more images to the same model (eq. 34 visual path).

        Uses the OpenAI-style content-parts schema (``image_url`` data URLs) over the existing
        ``/v1/chat/completions`` endpoint, so a vision-capable Claude served by the proxy "just works"
        with the same auth/caching as :meth:`chat`. The cache key incorporates the image bytes, so
        re-runs over identical frames are free and fully offline."""
        images = [Path(p) for p in image_paths]
        fingerprint = prompt + "\x00" + "\x00".join(self._image_fingerprint(p) for p in images)
        key = self._cache_key(fingerprint, f"vision_{response_format}", cache_version)
        cache_path = self.cache_dir / f"{key}.json"
        if cache_path.exists():
            raw = json.loads(cache_path.read_text(encoding="utf-8"))
            return LLMResponse(text=raw.get("text", ""), raw=raw.get("raw", {}), cached=True)
        if not self.api_key:
            raise RuntimeError("AIGCBEST_API_KEY is not set.")
        content: list[dict] = [{"type": "text", "text": prompt}]
        for path in images:
            url = _encode_image(path)
            if url:
                content.append({"type": "image_url", "image_url": {"url": url, "detail": detail}})
        if len(content) == 1:
            raise RuntimeError("chat_vision called with no readable images.")
        payload = {
            "model": self.model,
            "temperature": self.temperature,
            "max_tokens": max_tokens or self.max_tokens,
            "messages": [{"role": "user", "content": content}],
        }
        if response_format == "json":
            payload["response_format"] = {"type": "json_object"}
        raw = self._post(payload)
        text = normalize_response_text(raw)
        # Don't persist a blocked / empty / un-parseable vision completion: caching it would make a
        # transient refusal permanent (the next run reads the poisoned cache and never retries). Only
        # usable responses are cached; a refusal simply re-issues the call next time.
        if _vision_response_cacheable(text, raw, response_format):
            cache_path.write_text(json.dumps({"text": text, "raw": raw}, ensure_ascii=False, indent=2), encoding="utf-8")
        return LLMResponse(text=text, raw=raw, cached=False)

    def strict_json_vision(
        self,
        prompt: str,
        image_paths: list[str | Path],
        *,
        cache_version: str = "v1",
        max_tokens: int | None = None,
    ) -> dict:
        """:meth:`chat_vision` constrained to a JSON object via :func:`repair_json` (mirrors :meth:`strict_json`).

        The 8-frame vision JSON routinely truncates at ``max_tokens`` and emits unescaped OCR quotes;
        the tolerant recovery keeps every frame that completed before the break (a top-level array of
        frame objects is wrapped as ``{"frames": [...]}``) instead of dropping the whole call. Raises
        :class:`json.JSONDecodeError` only when nothing parses, so :mod:`viwikigraph.knowledge.vision`
        still records a per-frame error and degrades to the surviving frames."""
        response = self.chat_vision(
            prompt, image_paths, response_format="json", cache_version=cache_version, max_tokens=max_tokens
        )
        recovered = repair_json(response.text.strip())
        if isinstance(recovered, list):
            return {"frames": [item for item in recovered if isinstance(item, dict)]}
        if isinstance(recovered, dict):
            return recovered
        raise json.JSONDecodeError("vision response is not a JSON object", response.text or " ", 0)

    def _image_fingerprint(self, path: Path) -> str:
        """Stable per-image cache token: content hash when readable, else the path string."""
        try:
            return hashlib.sha256(path.read_bytes()).hexdigest()[:16]
        except OSError:
            return str(path)

    def normalized_logprob(self, prompt: str, continuation: str, *, cache_version: str = "v1") -> float | None:
        """Length-normalized token log-probability of ``continuation`` given ``prompt``.

        Implements the option-scoring signal used by the paper's MCQ protocol
        (``ô = argmax (1/|o|) Σ log P(o | q, E_q)``) via the OpenAI-style ``/v1/completions``
        ``echo`` mode. Returns ``None`` when the endpoint does not support logprobs/echo so callers
        can fall back to constrained-choice scoring. Cached like :meth:`chat`.
        """
        key = self._cache_key(prompt + "\x00" + continuation, "logprob", cache_version)
        cache_path = self.cache_dir / f"{key}.json"
        if cache_path.exists():
            value = json.loads(cache_path.read_text(encoding="utf-8")).get("normalized_logprob")
            return None if value is None else float(value)
        if not self.api_key:
            raise RuntimeError("AIGCBEST_API_KEY is not set.")
        payload = {
            "model": self.model,
            "prompt": prompt + continuation,
            "max_tokens": 0,
            "echo": True,
            "logprobs": 0,
            "temperature": 0.0,
        }
        try:
            raw = self._post(payload, path="/v1/completions")
            value = _continuation_logprob(raw, prompt)
        except Exception:
            value = None
        cache_path.write_text(json.dumps({"normalized_logprob": value}), encoding="utf-8")
        return value

    def _post(self, payload: dict, *, path: str | None = None) -> dict:
        parsed = urlparse(self.base_url)
        host = parsed.netloc or parsed.path
        path = path or "/v1/chat/completions"
        last_error: Exception | None = None
        for attempt in range(self.retries + 1):
            conn = http.client.HTTPSConnection(host, timeout=60)
            try:
                conn.request(
                    "POST",
                    path,
                    json.dumps(payload),
                    {
                        "Accept": "application/json",
                        "Authorization": _auth_header(self.api_key, self.auth_scheme),
                        "User-Agent": USER_AGENTS[attempt % len(USER_AGENTS)],
                        "Content-Type": "application/json",
                    },
                )
                response = conn.getresponse()
                body = response.read().decode("utf-8")
                if response.status >= 400:
                    raise RuntimeError(f"LLM HTTP {response.status}: {body[:500]}")
                return json.loads(body)
            except Exception as exc:
                last_error = exc
                if attempt < self.retries:
                    time.sleep(0.5 * (attempt + 1))
            finally:
                conn.close()
        raise RuntimeError(f"LLM request failed: {last_error}")

    def _cache_key(self, prompt: str, response_format: str, cache_version: str) -> str:
        payload = json.dumps(
            {"model": self.model, "prompt": prompt, "format": response_format, "version": cache_version},
            sort_keys=True,
        )
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    def _drop_cache(self, prompt: str, response_format: str, cache_version: str) -> None:
        cache_path = self.cache_dir / f"{self._cache_key(prompt, response_format, cache_version)}.json"
        try:
            cache_path.unlink()
        except FileNotFoundError:
            pass


def resolve_model(default: str = "claude-sonnet-4-6") -> str:
    """Resolve the model id, tolerating the legacy/leftover env var names.

    Priority: ``VIWIKIGRAPH_MODEL`` → ``AIGCBEST_MODEL`` → ``ADAGRAPHLOOM_MODEL`` → ``default``.
    The ``.env`` in this repo historically stored the model under ``ADAGRAPHLOOM_MODEL``; honoring it
    here means the configured model is actually used instead of silently falling back to a default.
    """
    for name in ("VIWIKIGRAPH_MODEL", "AIGCBEST_MODEL", "ADAGRAPHLOOM_MODEL"):
        value = os.environ.get(name, "").strip()
        if value:
            return value
    return default


def _auth_header(api_key: str, scheme: str = "") -> str:
    """Build the Authorization header value. AIGCBEST accepts a raw key; set
    ``AIGCBEST_AUTH_SCHEME=Bearer`` for endpoints that require the standard prefix."""
    if not scheme or api_key.lower().startswith(scheme.lower()):
        return api_key
    return f"{scheme} {api_key}"


def _continuation_logprob(data: dict, prompt: str) -> float | None:
    """Length-normalized logprob of the continuation (tokens after ``prompt``) from an echo
    completion response. Returns ``None`` if the payload lacks token-level logprobs."""
    try:
        lp = data["choices"][0]["logprobs"]
        tokens = lp["tokens"]
        token_logprobs = lp["token_logprobs"]
        offsets = lp.get("text_offset")
    except (KeyError, IndexError, TypeError):
        return None
    if not tokens or not token_logprobs:
        return None
    start = len(prompt)
    selected: list[float] = []
    if offsets and len(offsets) == len(token_logprobs):
        for offset, value in zip(offsets, token_logprobs):
            if offset >= start and value is not None:
                selected.append(float(value))
    else:  # no offsets: approximate by char-length of the prompt in tokens
        consumed = 0
        for token, value in zip(tokens, token_logprobs):
            consumed += len(token)
            if consumed > start and value is not None:
                selected.append(float(value))
    if not selected:
        return None
    return sum(selected) / len(selected)


def normalize_response_text(data: dict) -> str:
    try:
        return str(data["choices"][0]["message"]["content"])
    except (KeyError, IndexError, TypeError):
        return ""


def _vision_response_cacheable(text: str, raw: dict, response_format: str) -> bool:
    """Whether a vision completion is worth persisting to the cache.

    Refusals/blocked completions arrive as empty content, a ``content_filter``/``safety`` finish
    reason, or non-JSON prose for a JSON request — none of which should be cached, or a transient
    refusal becomes sticky until ``cache_version`` is bumped. Returns ``True`` only for usable text."""
    stripped = text.strip()
    if not stripped:
        return False
    try:
        finish = str(raw["choices"][0].get("finish_reason", "")).lower()
    except (KeyError, IndexError, TypeError, AttributeError):
        finish = ""
    if finish in ("content_filter", "safety"):
        return False
    if response_format == "json":
        # Cache only what the tolerant parser can actually recover. The old "'{' present" heuristic
        # cached truncated, un-loadable bodies, so a per-frame failure became sticky across runs and
        # the partial videos never recovered on re-run. A body repair_json can salvage (even partially)
        # is deterministic and worth caching; genuine garbage is re-fetched next run.
        try:
            repair_json(stripped)
        except json.JSONDecodeError:
            return False
    return True


def _encode_image(path: Path) -> str | None:
    """Encode an image file as an OpenAI-style base64 ``data:`` URL; ``None`` when unreadable."""
    try:
        data = path.read_bytes()
    except OSError:
        return None
    mime = _IMAGE_MIME.get(path.suffix.lower(), "image/jpeg")
    return f"data:{mime};base64,{base64.b64encode(data).decode('ascii')}"


def prompt_for_image(question: str, caption: str) -> str:
    return f"""
Extract ONLY visual knowledge triplets that help answer the question.

Return strict JSON with key "triples", where each triple is an object with subject, relation, object.
Use ONLY what is present in the image caption.

Question:
{question}

Image Caption:
\"\"\"{caption}\"\"\"
""".strip()


def prompt_for_text(question: str, full_text: str) -> str:
    return f"""
Extract ONLY factual knowledge triplets that help answer the question.

Return strict JSON with key "triples", where each triple is an object with subject, relation, object.
Use ONLY information present in the text.

Question:
{question}

Text:
\"\"\"{full_text}\"\"\"
""".strip()


def normalize_triplet_output(response: str) -> list[str]:
    import re

    triplets: list[str] = []
    try:
        data = json.loads(response)
        for item in data.get("triples", []):
            triplets.append(f"({item['subject']}, {item['relation']}, {item['object']})")
        return triplets
    except Exception:
        pass
    for line in response.splitlines():
        line = re.sub(r"^\d+\.\s*", "", line.strip())
        if "|" in line and not line.startswith("("):
            parts = [p.strip() for p in line.split("|")]
            if len(parts) == 3:
                line = f"({parts[0]}, {parts[1]}, {parts[2]})"
        if line.startswith("(") and line.endswith(")"):
            triplets.append(line)
    return triplets


def load_env_file(path: str | Path) -> None:
    env_path = Path(path)
    if not env_path.exists():
        return
    for line in env_path.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or "=" not in stripped:
            continue
        key, value = stripped.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip("'\""))
