"""Local Hugging Face Llama backend compatible with the ViWikiGraph LLM client surface."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

from viwikigraph.core.io import ensure_dir
from viwikigraph.llm.client import LLMResponse
from viwikigraph.llm.prompts import coerce_json_object, repair_json


class LocalLlamaClient:
    """Deterministic local causal-LM client used for answer generation and verification."""

    def __init__(
        self,
        *,
        model_path: str | Path,
        cache_dir: str | Path | None = None,
        max_new_tokens: int = 512,
    ):
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer

        self.model_path = Path(model_path).resolve()
        if not self.model_path.exists():
            raise FileNotFoundError(f"Local model does not exist: {self.model_path}")
        if not torch.cuda.is_available():
            raise RuntimeError("CUDA is required for the local Llama backend.")

        self.model = self.model_path.name
        self.available = True
        self.max_new_tokens = int(max_new_tokens)
        self.cache_dir = ensure_dir(
            cache_dir or Path(".cache") / "viwikigraph" / "local_llama" / self.model_path.name
        )
        self._torch = torch
        self.tokenizer = AutoTokenizer.from_pretrained(self.model_path, local_files_only=True)
        self.generator = AutoModelForCausalLM.from_pretrained(
            self.model_path,
            local_files_only=True,
            dtype=torch.bfloat16,
            device_map="auto",
            low_cpu_mem_usage=True,
        )
        self.generator.eval()

    def chat(
        self,
        prompt: str,
        *,
        response_format: str = "text",
        cache_version: str = "v1",
        response_schema: dict | None = None,
    ) -> LLMResponse:
        del response_schema
        fingerprint = json.dumps(
            {
                "model": str(self.model_path),
                "prompt": prompt,
                "response_format": response_format,
                "cache_version": cache_version,
                "max_new_tokens": self.max_new_tokens,
            },
            ensure_ascii=False,
            sort_keys=True,
        )
        key = hashlib.sha256(fingerprint.encode("utf-8")).hexdigest()
        cache_path = self.cache_dir / f"{key}.json"
        if cache_path.exists():
            row = json.loads(cache_path.read_text(encoding="utf-8"))
            return LLMResponse(text=row["text"], raw=row.get("raw", {}), cached=True)

        messages = [
            {
                "role": "system",
                "content": (
                    "You are the answer generator and verifier for a video question-answering "
                    "system. Follow the requested output format exactly and use only supplied evidence."
                ),
            },
            {"role": "user", "content": prompt},
        ]
        inputs = self.tokenizer.apply_chat_template(
            messages,
            add_generation_prompt=True,
            tokenize=True,
            return_dict=True,
            return_tensors="pt",
        ).to(self.generator.device)
        with self._torch.inference_mode():
            output = self.generator.generate(
                **inputs,
                max_new_tokens=self.max_new_tokens,
                do_sample=False,
                pad_token_id=self.tokenizer.eos_token_id,
            )
        generated = output[0][inputs["input_ids"].shape[-1] :]
        text = self.tokenizer.decode(generated, skip_special_tokens=True).strip()
        raw = {
            "backend": "transformers",
            "model_path": str(self.model_path),
            "input_tokens": int(inputs["input_ids"].shape[-1]),
            "output_tokens": int(generated.shape[-1]),
        }
        cache_path.write_text(
            json.dumps({"text": text, "raw": raw}, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        return LLMResponse(text=text, raw=raw, cached=False)

    def strict_json(
        self,
        prompt: str,
        *,
        cache_version: str = "v1",
        tolerant: bool = False,
        response_schema: dict | None = None,
    ) -> dict:
        response = self.chat(
            prompt,
            response_format="json",
            cache_version=cache_version,
            response_schema=response_schema,
        )
        if tolerant:
            return coerce_json_object(repair_json(response.text))
        return json.loads(response.text)
