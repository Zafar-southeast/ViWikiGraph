"""LLM access: the OpenAI-compatible :class:`~viwikigraph.llm.client.LLMClient`
and the prompt builders in :mod:`~viwikigraph.llm.prompts`."""

from viwikigraph.llm.client import (
    LLMClient,
    LLMResponse,
    load_env_file,
    normalize_response_text,
    normalize_triplet_output,
    prompt_for_image,
    prompt_for_text,
    resolve_model,
)
from viwikigraph.llm.prompts import (
    extraction_prompt,
    kg_prompt,
    mcq_prompt,
    narrative_prompt,
    open_prompt,
    option_scoring_prefix,
    parse_json,
    router_prompt,
    verification_prompt,
)

__all__ = [
    # client
    "LLMClient",
    "LLMResponse",
    "load_env_file",
    "normalize_response_text",
    "normalize_triplet_output",
    "prompt_for_image",
    "prompt_for_text",
    "resolve_model",
    # prompts
    "extraction_prompt",
    "kg_prompt",
    "mcq_prompt",
    "narrative_prompt",
    "open_prompt",
    "option_scoring_prefix",
    "parse_json",
    "router_prompt",
    "verification_prompt",
]
