from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass(slots=True)
class DatasetConfig:
    name: str
    video_root: Path
    output_root: Path
    annotations: dict[str, Path] = field(default_factory=dict)
    subtitles_path: Path | None = None
    visual_concepts_path: Path | None = None
    vidor_map_path: Path | None = None
    captions_path: Path | None = None
    options: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class AppConfig:
    raw: dict[str, Any]
    datasets: dict[str, DatasetConfig]
    budgets: dict[str, int]
    llm: dict[str, Any]
    mode: str = "rag_only"
    training_enabled: bool = False


def load_config(path: str | Path) -> AppConfig:
    path = Path(path)
    raw = _load_mapping(path)
    mode = str(raw.get("mode", "rag_only"))
    training = raw.get("training", {})
    training_enabled = bool(training.get("enabled", False)) if isinstance(training, dict) else False
    if mode != "rag_only":
        raise ValueError(f"ViWikiGraph v1 is RAG-only; expected mode='rag_only', got {mode!r}.")
    if training_enabled:
        raise ValueError("ViWikiGraph v1 is RAG-only; training.enabled must be false.")
    base = path.parent.parent if path.parent.name == "configs" else path.parent
    datasets: dict[str, DatasetConfig] = {}
    datasets_raw = raw.get("datasets", {})
    if not isinstance(datasets_raw, dict):
        raise ValueError("Config field 'datasets' must be a mapping.")
    for name, values in datasets_raw.items():
        env_prefix = name.upper().replace("-", "_")
        output_root = _resolve_path(os.environ.get(f"{env_prefix}_OUTPUT_ROOT", values.get("output_root", raw.get("output_root", "outputs"))), base)
        video_root = _resolve_path(os.environ.get(f"{env_prefix}_VIDEO_ROOT", values.get("video_root", "")), base)
        annotations = {
            split: _resolve_path(os.environ.get(f"{env_prefix}_{split.upper()}_ANNOTATIONS", ann_path), base)
            for split, ann_path in values.get("annotations", {}).items()
        }
        datasets[name] = DatasetConfig(
            name=name,
            video_root=video_root,
            output_root=output_root,
            annotations=annotations,
            subtitles_path=_optional_path(values.get("subtitles_path"), base, f"{env_prefix}_SUBTITLES_PATH"),
            visual_concepts_path=_optional_path(values.get("visual_concepts_path"), base, f"{env_prefix}_VISUAL_CONCEPTS_PATH"),
            vidor_map_path=_optional_path(values.get("vidor_map_path"), base, f"{env_prefix}_VIDOR_MAP_PATH"),
            captions_path=_optional_path(values.get("captions_path"), base, f"{env_prefix}_CAPTIONS_PATH"),
            options={key: value for key, value in values.items() if key not in {"video_root", "output_root", "annotations", "subtitles_path", "visual_concepts_path", "vidor_map_path", "captions_path"}},
        )
    return AppConfig(
        raw=raw,
        datasets=datasets,
        budgets={key: int(value) for key, value in raw.get("budgets", {}).items()},
        llm=dict(raw.get("llm", {})),
        mode=mode,
        training_enabled=training_enabled,
    )


def config_hash(raw: dict[str, Any]) -> str:
    import hashlib

    payload = json.dumps(raw, sort_keys=True, default=str).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()[:12]


def _load_mapping(path: Path) -> dict[str, Any]:
    text = path.read_text(encoding="utf-8")
    if path.suffix.lower() == ".json":
        return json.loads(text)
    try:
        import yaml  # type: ignore

        loaded = yaml.safe_load(text)
        return loaded or {}
    except ModuleNotFoundError:
        return _parse_minimal_yaml(text)


def _resolve_path(value: str | Path, base: Path) -> Path:
    value = Path(os.path.expandvars(str(value))).expanduser()
    if value.is_absolute():
        return value
    return (base / value).resolve()


def _optional_path(value: str | None, base: Path, env_name: str) -> Path | None:
    chosen = os.environ.get(env_name, value)
    if not chosen:
        return None
    return _resolve_path(chosen, base)


def _parse_minimal_yaml(text: str) -> dict[str, Any]:
    """Small YAML subset parser for this config file when PyYAML is absent."""
    root: dict[str, Any] = {}
    stack: list[tuple[int, dict[str, Any]]] = [(-1, root)]
    for raw_line in text.splitlines():
        line = raw_line.split("#", 1)[0].rstrip()
        if not line.strip():
            continue
        indent = len(line) - len(line.lstrip(" "))
        key, _, value = line.strip().partition(":")
        while stack and indent <= stack[-1][0]:
            stack.pop()
        parent = stack[-1][1]
        if value.strip() == "":
            child: dict[str, Any] = {}
            parent[key] = child
            stack.append((indent, child))
        else:
            parent[key] = _parse_scalar(value.strip())
    return root


def _parse_scalar(value: str) -> Any:
    value = value.strip("'\"")
    if value == "{}":
        return {}
    if value.lower() in {"true", "false"}:
        return value.lower() == "true"
    try:
        return int(value)
    except ValueError:
        return value
