"""Offline video-to-wiki package builder (paper §IV, Fig. 2 phases 1-3 + validation).

``build_video_package`` runs the once-per-video offline pipeline: ingest evidence (Phase 1),
generate the schema-guided narrative wiki (Phase 2), build the KG wiki (Phase 3), validate every
item (eq. 25-27), and persist the reusable knowledge package under
``{output_root}/{experiment_id}/{dataset}/{split}/packages/{video_id}/``.

RAG-only: an optional :class:`LLMClient` drives the generative steps; with no client (``llm=None``)
or ``dry_run`` every stage uses its deterministic fallback so the pipeline runs offline. The visual
stream is features-only — ffmpeg is never invoked here.
"""

from __future__ import annotations

import time
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

from viwikigraph.config import config_hash
from viwikigraph.knowledge.extraction import ingest_evidence
from viwikigraph.core.io import ensure_dir, write_json, write_jsonl
from viwikigraph.knowledge.kg import build_kg_items, render_kg_markdown
from viwikigraph.knowledge.linking import build_cross_modal_links
from viwikigraph.llm.client import LLMClient, resolve_model
from viwikigraph.retrieval.index import build_retrieval_index
from viwikigraph.core.schemas import (
    CrossModalLink,
    EvidenceUnit,
    MediaItem,
    Modality,
    QAInstance,
    ValidationResult,
    VideoRecord,
    WikiSection,
)
from viwikigraph.knowledge.validation import detect_conflicts, validate_item, validate_link
from viwikigraph.knowledge.wiki import build_narrative_sections, render_narrative_markdown

# Subtitle-like modalities indexed for the question-time subtitle-span budget (Bsub).
_SUBTITLE_MODALITIES = (Modality.SUBTITLE, Modality.ASR, Modality.CAPTION)


@dataclass(slots=True)
class VideoPackage:
    root: Path
    evidence_units: list[EvidenceUnit]
    media_items: list[MediaItem]
    validations: list[ValidationResult]


def package_root(
    output_root: str | Path,
    experiment_id: str,
    dataset: str,
    split: str,
    video_id: str,
) -> Path:
    """Filesystem root of one video's knowledge package."""
    return Path(output_root) / experiment_id / dataset / split / "packages" / video_id


def build_video_package(
    record: VideoRecord,
    qa_instances: list[QAInstance],
    output_root: str | Path,
    budgets: dict[str, int],
    *,
    experiment_id: str,
    llm: LLMClient | None = None,
    dry_run: bool = False,
    resume: bool = False,
    use_vlm: bool = False,
    validate_before_storage: bool = True,
    raw_config: dict | None = None,
    on_stage: Callable[[str], None] | None = None,
) -> VideoPackage:
    """Build and persist the reusable video knowledge package for ``record``.

    With ``resume`` set, an existing ``manifest.json`` short-circuits the rebuild. ``llm`` (when
    provided and not ``dry_run``) drives evidence extraction, narrative generation, and KG
    construction; otherwise the deterministic fallbacks run. ``qa_instances`` are used only to derive
    salience hints for visual-frame selection — never as evidence.

    ``on_stage`` (optional) is called with a stage name as each heavy stage completes
    (``"ingest"``, ``"narrative"``, ``"kg"``, ``"links"``) — or once with ``"skipped"`` when a
    ``resume`` run short-circuits — so callers can stream progress without affecting the return value.
    """
    root = package_root(output_root, experiment_id, record.dataset, record.split, record.video_id)
    manifest_path = root / "manifest.json"

    def _emit(stage: str) -> None:
        if on_stage is not None:
            on_stage(stage)

    if resume and manifest_path.exists():
        _emit("skipped")
        return VideoPackage(root=root, evidence_units=[], media_items=[], validations=[])

    evidence_dir = ensure_dir(root / "evidence")
    media_root = ensure_dir(root / "media")
    ensure_dir(media_root / "snapshots")
    ensure_dir(media_root / "clips")
    ensure_dir(media_root / "entities")
    wiki_dir = ensure_dir(root / "wiki")
    validation_dir = ensure_dir(root / "validation")
    index_dir = ensure_dir(root / "index")

    active_llm = llm if (llm is not None and not dry_run) else None

    # Features-only ingestion: expose the configured visual-frame budget without changing the
    # ingest_evidence signature (paper Bimg / eq. 11 TopK).
    record.metadata.setdefault("Bimg", int(budgets.get("Bimg", budgets.get("keyframes", 4))))
    question_hints = _question_hints(qa_instances)
    # Optional VLM visual stream: frames are saved under the package media/ dir so they become
    # MediaItems + cross-modal links + q_media evidence. Opt-in via ``use_vlm`` (needs a vision LLM).
    frame_budget = int(budgets.get("Bframes", budgets.get("Bimg", 4)))
    frame_dir = ensure_dir(media_root / "frames") if (use_vlm and active_llm is not None) else None
    evidence_units = ingest_evidence(
        record,
        active_llm,
        question_hints=question_hints,
        vision=use_vlm and active_llm is not None,
        frame_budget=frame_budget,
        media_dir=frame_dir,
    )
    _emit("ingest")

    sections = build_narrative_sections(record.video_id, evidence_units, record.metadata, active_llm)
    _emit("narrative")
    kg_items = build_kg_items(record.video_id, evidence_units, sections, active_llm)
    _emit("kg")
    media_items = _collect_media_items(record.video_id, evidence_units, sections)
    # Cross-modal linking (Phase: §III-C) — typed links over the generated wiki + evidence (eq. 20).
    cross_modal_links = build_cross_modal_links(
        record.video_id, sections, kg_items, media_items, evidence_units, active_llm
    )
    _emit("links")
    # Validation BEFORE storage (§III-D). The explicit bypass is the paper ablation
    # "without pre-storage validation"; generated items and links are persisted unchanged.
    validations = (
        _validate(sections, kg_items, evidence_units, cross_modal_links)
        if validate_before_storage
        else []
    )
    _emit("validation" if validate_before_storage else "validation_skipped")

    subtitle_units = [unit for unit in evidence_units if unit.modality in _SUBTITLE_MODALITIES]
    index = build_retrieval_index(sections, kg_items, media_items, subtitle_units, cross_modal_links)

    write_jsonl(evidence_dir / "evidence_units.jsonl", evidence_units)
    write_jsonl(wiki_dir / "narrative_sections.jsonl", sections)
    write_jsonl(wiki_dir / "kg_items.jsonl", kg_items)
    (wiki_dir / "narrative_wiki.md").write_text(
        render_narrative_markdown(record.video_id, sections), encoding="utf-8"
    )
    (wiki_dir / "kg_wiki.md").write_text(
        render_kg_markdown(record.video_id, kg_items, cross_modal_links), encoding="utf-8"
    )
    write_jsonl(validation_dir / "claim_support.jsonl", validations)
    write_jsonl(validation_dir / "media_links.jsonl", [item.to_dict() for item in media_items])
    write_jsonl(validation_dir / "cross_modal_links.jsonl", cross_modal_links)
    write_jsonl(validation_dir / "conflicts.jsonl", detect_conflicts(validations))
    write_json(index_dir / "retrieval_index.json", index.to_dict())
    write_json(
        manifest_path,
        {
            "experiment_id": experiment_id,
            "dataset": record.dataset,
            "split": record.split,
            "video_id": record.video_id,
            "video_path": record.video_path,
            "qa_count": len(qa_instances),
            "evidence_units": len(evidence_units),
            "narrative_sections": len(sections),
            "kg_items": len(kg_items),
            "cross_modal_links": len(cross_modal_links),
            "created_at": int(time.time()),
            "dry_run": dry_run,
            "pipeline_mode": "rag_only",
            "training_enabled": False,
            "llm_used": active_llm is not None,
            "models": {
                "media": "vlm_frames" if (use_vlm and active_llm is not None) else "features_only",
                "vision": (
                    f"vlm:{resolve_model()}" if (use_vlm and active_llm is not None) else "dataset_features"
                ),
                "llm": resolve_model() if active_llm is not None else "none",
            },
            "vlm_used": bool(use_vlm and active_llm is not None),
            "pre_storage_validation": bool(validate_before_storage),
            "validation_results": len(validations),
            # Visual-extraction outcome (set by extract_visual_evidence): makes an evidence-free VLM
            # package visible here instead of indistinguishable from a video with nothing in it.
            "vision_status": record.metadata.get("vision_status"),
            "vision_detail": record.metadata.get("vision_detail"),
            "frames_sampled": record.metadata.get("frames_sampled"),
            "frames_described": record.metadata.get("frames_described"),
            "prompt_versions": {"extract": "v1", "narrative": "v1", "kg": "v1"},
            "config_hash": config_hash(raw_config or {}),
            "source_files": record.metadata.get("source_files", []),
        },
    )
    return VideoPackage(
        root=root,
        evidence_units=evidence_units,
        media_items=media_items,
        validations=validations,
    )


def _validate(
    sections: list[WikiSection],
    kg_items: list,
    evidence_units: list[EvidenceUnit],
    cross_modal_links: list[CrossModalLink] | None = None,
) -> list[ValidationResult]:
    """Validate every narrative section, KG item, and cross-modal link against its grounding
    evidence (6-dim q(z), eq. 22-24). q_link is driven by the incident ``cross_modal_links``."""
    by_id = {unit.evidence_id: unit for unit in evidence_units}
    links = list(cross_modal_links or [])

    def linked(evidence_ids: list[str]) -> list[EvidenceUnit]:
        return [by_id[eid] for eid in evidence_ids if eid in by_id]

    # Cross-item set used for the consistency (contradiction) check.
    grounded: list[tuple[str, list[EvidenceUnit]]] = [
        (section.content, linked(section.evidence_ids)) for section in sections
    ]
    grounded.extend((item.description or item.label, linked(item.evidence_ids)) for item in kg_items)

    results: list[ValidationResult] = []
    for section in sections:
        results.append(
            validate_item(
                section.section_id,
                section.section_type,
                section.content,
                linked(section.evidence_ids),
                section.provenance.get("media_paths", []),
                grounded_items=grounded,
                links=links,
            )
        )
    for item in kg_items:
        results.append(
            validate_item(
                item.item_id,
                item.item_type,
                item.description or item.label,
                linked(item.evidence_ids),
                grounded_items=grounded,
                links=links,
            )
        )
    # Validate the cross-modal links themselves as candidate items z (eq. 22, item_type link).
    items_by_id: dict[str, object] = {s.section_id: s for s in sections}
    items_by_id.update({k.item_id: k for k in kg_items})
    for link in links:
        results.append(validate_link(link, items_by_id, by_id))
    return results


def _collect_media_items(
    video_id: str,
    evidence_units: list[EvidenceUnit],
    sections: list[WikiSection],
) -> list[MediaItem]:
    """Collect media path references attached to evidence/sections (features-only: usually empty).

    No ffmpeg extraction is performed. Media items are produced only for paths that already exist on
    evidence units or section provenance (e.g. a future video-backed run), preserving the paper's
    media-linking structure without fabricating files.
    """
    items: list[MediaItem] = []
    seen: set[str] = set()
    for unit in evidence_units:
        for path in unit.media_paths:
            if path and path not in seen and Path(path).exists():
                seen.add(path)
                items.append(
                    MediaItem(
                        media_id=f"media_{len(items) + 1}",
                        video_id=video_id,
                        media_type="snapshot",
                        path=path,
                        linked_item_id=unit.evidence_id,
                        confidence=unit.confidence,
                        provenance={"source": "evidence_media"},
                    )
                )
    for section in sections:
        for path in section.provenance.get("media_paths", []):
            if path and path not in seen and Path(path).exists():
                seen.add(path)
                items.append(
                    MediaItem(
                        media_id=f"media_{len(items) + 1}",
                        video_id=video_id,
                        media_type="snapshot",
                        path=path,
                        linked_item_id=section.section_id,
                        confidence=section.confidence,
                        provenance={"source": "section_media"},
                    )
                )
    return items


def _question_hints(qa_instances: list[QAInstance]) -> list[str]:
    """Question/option text used as salience cues for visual-frame selection (not evidence)."""
    hints: list[str] = []
    def temporal_first(qa: QAInstance) -> tuple[int, str]:
        qtype = str((qa.metadata or {}).get("question_type", "")).upper()
        text = qa.question.lower()
        is_temporal = qtype.startswith("T") or any(
            cue in text for cue in ("before", "after", "then", "next", "first", "last", "start", "end")
        )
        return (0 if is_temporal else 1, qa.question_id)

    for qa in sorted(qa_instances, key=temporal_first):
        if qa.question:
            hints.append(qa.question)
        hints.extend(option for option in qa.options if option)
    return hints
