"""End-to-end v1 pipeline smoke tests (offline / no LLM): build → link → validate → persist,
then retrieve → answer → refine, exercising the cross-modal link layer."""

import json
import tempfile
import unittest
from pathlib import Path

from viwikigraph.cli import _load_index_from_package
from viwikigraph.core.schemas import QAInstance, VideoRecord
from viwikigraph.pipeline import build_video_package, package_root
from viwikigraph.qa.answering import answer_question
from viwikigraph.retrieval.index import retrieve_evidence, route_query

_BUDGETS = {"Bsub": 8, "Bimg": 4, "Bnar": 4, "Bkg": 8, "Bmedia": 2, "Blink": 6}


def _record():
    return VideoRecord(
        dataset="nextqa", split="val", video_id="vid1", video_path="vid1.mp4",
        subtitles=[
            {"text": "Penny enters the apartment.", "start": 1.0, "end": 3.0, "source": "nextqa_caption"},
            {"text": "Leonard greets Penny warmly.", "start": 3.0, "end": 5.0, "source": "nextqa_caption"},
        ],
        metadata={"visual_concepts": ["woman , couch", "man , door"]},
    )


def _qas():
    return [QAInstance(question_id="q1", video_id="vid1", question="Who enters the apartment?",
                       options=["Penny", "Sheldon"], answer_index=0)]


class PipelineV1Tests(unittest.TestCase):
    def _build(self, tmp: str):
        build_video_package(_record(), _qas(), tmp, _BUDGETS, experiment_id="exp", llm=None)
        return package_root(tmp, "exp", "nextqa", "val", "vid1")

    def test_build_persists_cross_modal_links_and_renders_section(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = self._build(tmp)
            links_file = root / "validation" / "cross_modal_links.jsonl"
            self.assertTrue(links_file.exists())
            links = [json.loads(line) for line in links_file.read_text().splitlines() if line.strip()]
            self.assertTrue(any(link["link_type"] == "claim_text" for link in links))

            kg_md = (root / "wiki" / "kg_wiki.md").read_text()
            self.assertIn("## Cross-Modal Evidence Links", kg_md)

            manifest = json.loads((root / "manifest.json").read_text())
            self.assertIn("cross_modal_links", manifest)
            self.assertEqual(manifest["cross_modal_links"], len(links))

    def test_validation_includes_link_results(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = self._build(tmp)
            validations = [json.loads(line) for line in
                           (root / "validation" / "claim_support.jsonl").read_text().splitlines() if line.strip()]
            link_validations = [v for v in validations if v["item_type"] == "cross_modal_link"]
            self.assertTrue(link_validations)
            self.assertIn("link", link_validations[0])  # 6-dim vector persisted

    def test_index_round_trips_links_and_qa_runs(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = self._build(tmp)
            index = _load_index_from_package(root)
            self.assertTrue(index.cross_modal_links)
            qa = _qas()[0]
            packet = retrieve_evidence(qa, index, _BUDGETS, need=route_query(qa.question, qa.options))
            pred = answer_question(qa, packet, llm=None)
            self.assertEqual(pred.scoring_method, "heuristic_overlap")
            self.assertTrue(pred.evidence_trace)  # claim-level trace produced offline


if __name__ == "__main__":
    unittest.main()
