import unittest

from tests._stubs import StubLLM
from viwikigraph.knowledge.extraction import ingest_evidence
from viwikigraph.core.schemas import Modality, VideoRecord


def _record() -> VideoRecord:
    return VideoRecord(
        dataset="tvqa",
        split="val",
        video_id="clip_1",
        video_path="/missing.mp4",
        subtitles=[{"text": "Penny opens the red door.", "start": 0.0, "end": 2.0, "source": "subtitle"}],
        # Two identical concept frames must de-duplicate to a single representative frame.
        metadata={"visual_concepts": ["red door , woman", "red door , woman"], "Bimg": 2},
    )


class ExtractionFallbackTests(unittest.TestCase):
    def test_no_llm_uses_regex_fallback(self):
        units = ingest_evidence(_record(), llm=None)

        subtitle_units = [u for u in units if u.modality == Modality.SUBTITLE]
        self.assertEqual(len(subtitle_units), 1)
        self.assertIn("Penny", subtitle_units[0].entities)  # capitalized token → entity heuristic

        visual_units = [u for u in units if u.modality == Modality.VISUAL_CONCEPT]
        self.assertEqual(len(visual_units), 1, "identical concept frames should de-duplicate")
        self.assertIn("red door", visual_units[0].objects)

    def test_stub_llm_extraction_populates_triples(self):
        llm = StubLLM(
            json_response={
                "entities": ["Penny"],
                "objects": ["door"],
                "actions": ["opens"],
                "events": [],
                "triples": [{"subject": "Penny", "relation": "opens", "object": "door"}],
            }
        )
        units = ingest_evidence(_record(), llm=llm)
        subtitle = next(u for u in units if u.modality == Modality.SUBTITLE)

        self.assertIn(("Penny", "opens", "door"), subtitle.facts)
        self.assertIn("door", subtitle.objects)


if __name__ == "__main__":
    unittest.main()
