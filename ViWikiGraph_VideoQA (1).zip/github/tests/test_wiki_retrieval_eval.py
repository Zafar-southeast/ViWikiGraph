import tempfile
import unittest
from pathlib import Path

from viwikigraph.qa.evaluation import accuracy, exact_match, token_f1
from viwikigraph.knowledge.kg import build_kg_items, render_kg_markdown
from viwikigraph.retrieval.index import build_retrieval_index, retrieve_evidence
from viwikigraph.core.schemas import EvidenceUnit, Modality, WikiSection
from viwikigraph.knowledge.validation import validate_item
from viwikigraph.knowledge.wiki import build_narrative_sections, render_narrative_markdown


class WikiRetrievalEvaluationTests(unittest.TestCase):
    def test_narrative_and_kg_markdown_include_provenance(self):
        units = [
            EvidenceUnit(
                evidence_id="sub_1",
                video_id="clip_1",
                modality=Modality.SUBTITLE,
                text="Penny enters the room and greets Leonard.",
                start=1.0,
                end=3.0,
                confidence=0.95,
                provenance={"source": "subtitle"},
                entities=["Penny", "Leonard"],
                actions=["enters", "greets"],
                facts=[("Penny", "greets", "Leonard")],
            )
        ]

        sections = build_narrative_sections("clip_1", units, {"dataset": "fixture"})
        kg_items = build_kg_items("clip_1", units, sections)
        narrative_md = render_narrative_markdown("clip_1", sections)
        kg_md = render_kg_markdown("clip_1", kg_items)

        self.assertIn("## Global Summary", narrative_md)
        self.assertIn("sub_1", narrative_md)
        self.assertIn("| Penny | greets | Leonard |", kg_md)
        self.assertIn("sub_1", kg_md)

    def test_validation_scores_item_with_support_and_media_path(self):
        with tempfile.TemporaryDirectory() as tmp:
            media_path = Path(tmp) / "snap.jpg"
            media_path.write_bytes(b"fake")
            evidence = EvidenceUnit(
                evidence_id="ev1",
                video_id="v1",
                modality=Modality.CAPTION,
                text="A red door is visible.",
                start=0,
                end=1,
                confidence=1,
                provenance={"snapshot_path": str(media_path)},
            )

            result = validate_item(
                item_id="claim1",
                item_type="claim",
                text="red door visible",
                evidence=[evidence],
                media_paths=[media_path],
            )

            self.assertEqual(result.decision, "keep")
            self.assertGreaterEqual(result.score, 0.75)
            self.assertEqual(result.evidence_ids, ["ev1"])

    def test_retrieval_prefers_matching_sections_and_keeps_media(self):
        section = WikiSection(
            section_id="scene_1",
            video_id="clip_1",
            section_type="scene",
            heading="Scene 1",
            content="Penny opens the red door.",
            claims=["Penny opens the red door."],
            evidence_ids=["ev1"],
            start=0,
            end=5,
            confidence=0.9,
            provenance={"media_paths": ["media/snapshots/0001.jpg"]},
        )
        index = build_retrieval_index([section], [], [])
        packet = retrieve_evidence(
            question_id="q1",
            video_id="clip_1",
            question="What color is the door?",
            index=index,
            budgets={"narrative": 1, "kg": 1, "media": 1},
        )

        self.assertEqual(packet.narrative_sections[0].section_id, "scene_1")
        self.assertEqual(packet.media_items[0].path, "media/snapshots/0001.jpg")

    def test_metrics(self):
        self.assertEqual(accuracy([1, 0, 1], [1, 1, 1]), 2 / 3)
        self.assertEqual(exact_match(" The Red Door ", "the red door"), 1.0)
        self.assertAlmostEqual(token_f1("red door", "red front door"), 0.8)


if __name__ == "__main__":
    unittest.main()
