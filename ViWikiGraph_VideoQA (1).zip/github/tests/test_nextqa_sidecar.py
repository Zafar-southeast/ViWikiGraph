"""NExT-QA optional visual-concept + caption sidecar wiring."""

import json
import tempfile
import unittest
from pathlib import Path

from viwikigraph.datasets.adapters import NextQAAdapter


def _write_csv(path: Path):
    header = "video,frame_count,width,height,question,answer,qid,type,a0,a1,a2,a3,a4\n"
    row = "vid1,100,320,240,Who enters?,0,q1,DC,Penny,Sheldon,Leonard,Amy,Raj\n"
    path.write_text(header + row, encoding="utf-8")


class NextQASidecarTests(unittest.TestCase):
    def test_visual_concept_sidecar_populates_metadata(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            _write_csv(tmp / "val.csv")
            (tmp / "visual.jsonl").write_text(
                json.dumps({"vid1": [["woman", "couch"], ["man", "door"]]}) + "\n", encoding="utf-8"
            )
            adapter = NextQAAdapter(
                {"val": tmp / "val.csv"}, vidor_map_path=None, video_root=tmp / "videos",
                visual_concepts_path=tmp / "visual.jsonl",
            )
            record = next(adapter.iter_video_records("val"))
            self.assertEqual(record.metadata["visual_concepts"], [["woman", "couch"], ["man", "door"]])

    def test_caption_and_visual_sidecars_combine(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            _write_csv(tmp / "val.csv")
            (tmp / "caps.jsonl").write_text(
                json.dumps({"video_id": "vid1", "captions": [{"text": "Penny enters", "start": 1.0, "end": 3.0}]}) + "\n",
                encoding="utf-8",
            )
            (tmp / "visual.jsonl").write_text(
                json.dumps({"video_id": "vid1", "visual_concepts": ["woman , couch"],
                            "bbox_labels": {"0": ["Penny"]}}) + "\n", encoding="utf-8",
            )
            adapter = NextQAAdapter(
                {"val": tmp / "val.csv"}, vidor_map_path=None, video_root=tmp / "videos",
                captions_path=tmp / "caps.jsonl", visual_concepts_path=tmp / "visual.jsonl",
            )
            record = next(adapter.iter_video_records("val"))
            self.assertEqual(record.subtitles[0]["text"], "Penny enters")
            self.assertEqual(record.metadata["visual_concepts"], ["woman , couch"])
            self.assertEqual(record.metadata["bbox_labels"], {"0": ["Penny"]})

    def test_no_sidecar_is_evidence_free(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            _write_csv(tmp / "val.csv")
            adapter = NextQAAdapter({"val": tmp / "val.csv"}, vidor_map_path=None, video_root=tmp / "videos")
            record = next(adapter.iter_video_records("val"))
            self.assertEqual(record.subtitles, [])
            self.assertNotIn("visual_concepts", record.metadata)
            qa = next(adapter.iter_qa_instances("val"))
            self.assertEqual(qa.answer_index, 0)  # 0-based answer preserved


if __name__ == "__main__":
    unittest.main()
