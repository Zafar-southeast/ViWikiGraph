import unittest

from viwikigraph.knowledge.kg import build_kg_items
from viwikigraph.core.schemas import EvidenceUnit, Modality, WikiSection
from viwikigraph.knowledge.validation import support_score, validate_item


def _unit(eid: str, text: str, **kw) -> EvidenceUnit:
    return EvidenceUnit(evidence_id=eid, video_id="v", modality=Modality.SUBTITLE, text=text, **kw)


class SupportScoreTests(unittest.TestCase):
    def test_supporting_unit_ranked_first_and_score_positive(self):
        strong = _unit("ev_strong", "Penny opened the red door", entities=["Penny"])
        weak = _unit("ev_weak", "Sheldon ate breakfast")
        score, supporting = support_score("Penny opened the red door", [weak, strong])
        self.assertGreater(score, 0.5)
        self.assertEqual(supporting[0], "ev_strong")

    def test_empty_claim_or_no_evidence_yields_zero(self):
        self.assertEqual(support_score("", [_unit("e", "anything")]), (0.0, []))
        self.assertEqual(support_score("a claim", []), (0.0, []))


class ConsistencyTests(unittest.TestCase):
    def test_negation_conflict_applies_consistency_penalty(self):
        unit = _unit("ev1", "Penny door open")
        result = validate_item(
            "claim_pos", "claim", "Penny opened the door", [unit],
            grounded_items=[("Penny did not open the door", [unit])],
        )
        self.assertEqual(result.consistency, 0.3)
        self.assertIn("Conflicts", result.notes)

    def test_no_grounded_items_keeps_full_consistency(self):
        unit = _unit("ev1", "Penny opened the door")
        result = validate_item("claim", "claim", "Penny opened the door", [unit])
        self.assertEqual(result.consistency, 1.0)


class KGTemporalTests(unittest.TestCase):
    def _section(self, sid: str, start, end, conf) -> WikiSection:
        return WikiSection(section_id=sid, video_id="v", section_type="scene", heading=sid,
                           content="c", start=start, end=end, confidence=conf)

    def test_consecutive_sections_yield_before_link_with_min_confidence(self):
        sections = [self._section("scene_1", 0.0, 2.0, 0.9), self._section("scene_2", 2.0, 4.0, 0.8)]
        items = build_kg_items("v", [], sections, llm=None)
        temporal = [i for i in items if i.item_type == "temporal_link"]
        self.assertEqual(len(temporal), 1)
        self.assertEqual(temporal[0].triples[0].relation, "BEFORE")
        self.assertAlmostEqual(temporal[0].confidence, 0.8)

    def test_sections_without_timestamps_have_no_temporal_links(self):
        sections = [self._section("a", None, None, 1.0), self._section("b", None, None, 1.0)]
        items = build_kg_items("v", [], sections, llm=None)
        self.assertEqual([i for i in items if i.item_type == "temporal_link"], [])


if __name__ == "__main__":
    unittest.main()
