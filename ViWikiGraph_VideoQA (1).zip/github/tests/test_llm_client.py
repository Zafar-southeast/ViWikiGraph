import json
import tempfile
from pathlib import Path
import unittest

import smoke_llm
from viwikigraph.llm.client import LLMClient, normalize_response_text, normalize_triplet_output, prompt_for_text


class LLMClientTests(unittest.TestCase):
    def test_prompt_and_triplet_helpers_are_reused_by_test_script(self):
        prompt = smoke_llm.prompt_for_text("What color?", "The door is red.")

        self.assertEqual(prompt, prompt_for_text("What color?", "The door is red."))
        self.assertIn("strict JSON", prompt)

    def test_normalize_triplet_output_accepts_json_and_legacy_lines(self):
        json_response = json.dumps({"triples": [{"subject": "door", "relation": "has_color", "object": "red"}]})
        legacy_response = "1. door | has_color | red"

        self.assertEqual(normalize_triplet_output(json_response), ["(door, has_color, red)"])
        self.assertEqual(normalize_triplet_output(legacy_response), ["(door, has_color, red)"])

    def test_normalize_response_text_extracts_openai_compatible_message(self):
        data = {"choices": [{"message": {"content": "hello"}}]}

        self.assertEqual(normalize_response_text(data), "hello")

    def test_unparseable_strict_json_response_is_not_cached(self):
        with tempfile.TemporaryDirectory() as tmp:
            client = LLMClient(api_key="test-key", cache_dir=Path(tmp) / "cache")
            calls = {"n": 0}

            def fake_post(payload, *, path=None):
                calls["n"] += 1
                return {"choices": [{"message": {"content": "not json"}}]}

            client._post = fake_post  # type: ignore[assignment]
            for _ in range(2):
                with self.assertRaises(json.JSONDecodeError):
                    client.strict_json("return json", cache_version="t")

            self.assertEqual(calls["n"], 2)


if __name__ == "__main__":
    unittest.main()
