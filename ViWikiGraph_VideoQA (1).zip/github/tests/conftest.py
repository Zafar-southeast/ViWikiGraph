"""Pytest configuration.

Adds the standalone ``scripts/`` directory to ``sys.path`` so the LLM-client
drift-guard test can import the ``smoke_llm`` example by name. ``scripts/`` holds
runnable utilities, not an importable package, so it is wired up here rather than
shipped inside ``viwikigraph``.
"""

import sys
from pathlib import Path

_SCRIPTS = Path(__file__).resolve().parent.parent / "scripts"
if str(_SCRIPTS) not in sys.path:
    sys.path.insert(0, str(_SCRIPTS))
