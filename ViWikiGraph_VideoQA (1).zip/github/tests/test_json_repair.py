"""P0/P2: tolerant JSON recovery on the QA + vision paths.

Reproduces the exp7 failure families (the 13/50 heuristic_overlap fallbacks were 10 JSONDecodeError +
3 top-level-array AttributeError) and asserts they are recovered into real LLM answers instead of the
near-chance token-overlap guess, while genuinely-unrecoverable output still raises (so the strict
build-stage callers and the never-abstain heuristic fallback are preserved).
"""

import json
import tempfile
import unittest
from pathlib import Path

from tests._stubs import StubLLM
from viwikigraph.llm.client import LLMClient, _vision_response_cacheable
from viwikigraph.llm.prompts import coerce_json_object, repair_json
from viwikigraph.qa.answering import answer_question
from viwikigraph.core.schemas import EvidencePacket, QAInstance, WikiSection


def _client(content: str) -> LLMClient:
    """A real LLMClient whose HTTP layer returns a fixed completion ``content``."""
    tmp = tempfile.mkdtemp()
    client = LLMClient(api_key="test-key", cache_dir=Path(tmp) / "cache")
    client._post = lambda payload, *, path=None: {"choices": [{"message": {"content": content}}]}  # type: ignore[assignment]
    return client


def _packet(content: str) -> EvidencePacket:
    return EvidencePacket(
        question_id="q",
        video_id="v",
        narrative_sections=[
            WikiSection(section_id="scene_1", video_id="v", section_type="scene",
                        heading="Scene 1", content=content, confidence=0.9)
        ],
    )


class RepairJsonTests(unittest.TestCase):
    def test_recovers_every_exp7_failure_family(self):
        cases = {
            "clean": ('{"answer_index": 2, "confidence": 0.9}', 2),
            "fenced": ('```json\n{"answer_index": 1, "confidence": 0.8}\n```', 1),
            "extra_data": ('{"answer_index": 0, "confidence": 0.9}\nReasoning: clear.', 0),
            "inner_quote": ('{"answer_index": 3, "confidence": 0.7, "rationale": "she said "hi" to him"}', 3),
            "unterminated": ('{\n "answer_index": 4,\n "confidence": 0.6,\n "rationale": "he picks up the', 4),
            "truncated_no_comma": ('{"answer_index": 2, "confidence": 0.8', 2),
            "leading_prose": ('Sure, here you go:\n{"answer_index": 1, "confidence": 0.5}', 1),
        }
        for name, (text, expected) in cases.items():
            with self.subTest(family=name):
                recovered = coerce_json_object(repair_json(text))
                self.assertEqual(recovered.get("answer_index"), expected)

    def test_top_level_array_is_unwrapped_to_first_object(self):
        # The 3 AttributeError fallbacks: json.loads succeeds but returns a list.
        recovered = coerce_json_object(repair_json('[{"answer_index": 4, "confidence": 0.8}]'))
        self.assertEqual(recovered["answer_index"], 4)

    def test_unrecoverable_raises(self):
        for bad in ("not json", "", "no json here", "[1, 2, 3]"):
            with self.subTest(text=bad):
                with self.assertRaises(json.JSONDecodeError):
                    coerce_json_object(repair_json(bad))

    def test_vision_truncation_keeps_completed_frames(self):
        text = ('{"frames": [{"index":0,"description":"a cat","objects":["cat"]}, '
                '{"index":1,"description":"a dog","objects":["dog"]}, {"index":2, "descrip')
        recovered = repair_json(text)
        frames = recovered["frames"] if isinstance(recovered, dict) else recovered
        usable = [f for f in frames if f.get("description")]
        self.assertGreaterEqual(len(usable), 2)


class StrictJsonTolerantTests(unittest.TestCase):
    def test_tolerant_recovers_malformed_object(self):
        client = _client('{"answer_index": 3, "confidence": 0.7, "rationale": "a "quoted" word"}')
        result = client.strict_json("p", cache_version="t", tolerant=True)
        self.assertEqual(result["answer_index"], 3)

    def test_tolerant_unwraps_top_level_array(self):
        client = _client('[{"answer_index": 2, "confidence": 0.5}]')
        result = client.strict_json("p", cache_version="t", tolerant=True)
        self.assertEqual(result["answer_index"], 2)

    def test_tolerant_raises_on_unrecoverable(self):
        client = _client("totally not json")
        with self.assertRaises(json.JSONDecodeError):
            client.strict_json("p", cache_version="t", tolerant=True)

    def test_strict_default_unchanged_still_raises(self):
        # The build-stage callers (kg/extraction/linking/validation/refinement) rely on the raise.
        client = _client("not json at all")
        with self.assertRaises(json.JSONDecodeError):
            client.strict_json("p", cache_version="t")  # tolerant defaults to False


class ChoiceDraftRecoveryTests(unittest.TestCase):
    """End-to-end: a malformed MCQ completion now yields llm_choice, not heuristic_overlap."""

    def _qa(self) -> QAInstance:
        return QAInstance(
            question_id="q", video_id="v", question="What color is the door?",
            options=["blue", "red", "green", "yellow"], answer_index=1,
        )

    def test_malformed_mcq_json_recovers_to_llm_choice(self):
        client = _client('{"answer_index": 1, "confidence": 0.8, "rationale": "the door is "red" here"}')
        prediction = answer_question(self._qa(), _packet("the door"), llm=client, verify=False)
        self.assertEqual(prediction.scoring_method, "llm_choice")
        self.assertEqual(prediction.predicted_index, 1)

    def test_array_wrapped_mcq_json_recovers_to_llm_choice(self):
        client = _client('[{"answer_index": 1, "confidence": 0.8}]')
        prediction = answer_question(self._qa(), _packet("the door"), llm=client, verify=False)
        self.assertEqual(prediction.scoring_method, "llm_choice")
        self.assertEqual(prediction.predicted_index, 1)

    def test_unrecoverable_mcq_json_still_falls_back(self):
        client = _client("no json here")
        prediction = answer_question(self._qa(), _packet("the door"), llm=client, verify=False)
        self.assertEqual(prediction.scoring_method, "heuristic_overlap")
        self.assertIsNotNone(prediction.predicted_index)  # never-abstain preserved
        fallbacks = [e["fallback"] for e in prediction.evidence_trace if "fallback" in e]
        self.assertEqual(len(fallbacks), 1)


class VisionCacheGateTests(unittest.TestCase):
    def test_unrepairable_json_vision_response_not_cacheable(self):
        self.assertFalse(_vision_response_cacheable("not json", {}, "json"))

    def test_repairable_truncated_vision_response_is_cacheable(self):
        text = '{"frames": [{"index":0,"description":"a cat"}, {"index":1, "descr'
        self.assertTrue(_vision_response_cacheable(text, {}, "json"))

    def test_blocked_response_not_cacheable(self):
        raw = {"choices": [{"finish_reason": "content_filter"}]}
        self.assertFalse(_vision_response_cacheable('{"frames": []}', raw, "json"))


if __name__ == "__main__":
    unittest.main()
