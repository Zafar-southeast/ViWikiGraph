import tempfile
import unittest
from pathlib import Path

from viwikigraph.datasets.adapters import KnowITAdapter
from viwikigraph.knowledge.corpus import build_knowledge_corpus
from viwikigraph.retrieval.index import EvidenceNeed, build_retrieval_index, retrieve_evidence

# Two KnowIT rows; row 0's gold reason mentions Sheldon (so the row-0 question would retrieve it
# unless the leakage guard fires).
_KNOWIT_TSV = (
    "answer1\tanswer2\tanswer3\tanswer4\tidxCorrect\tkg_type\tquestion\treason\tscene\tsubtitle\n"
    "A\tB\tC\tD\t1\tsame\tWhy did Sheldon leave the apartment?\t"
    "Sheldon left the apartment because he was angry about the schedule.\t"
    "s01e01_scene001_0001_0005\t<b>Sheldon</b>: Goodbye.\n"
    "A\tB\tC\tD\t2\tsame\tWho is Penny?\t"
    "Penny is the neighbor who lives across the hall.\t"
    "s01e02_scene001_0001_0005\t<b>Penny</b>: Hi there.\n"
)

_OWN_REASON = "Sheldon left the apartment because he was angry about the schedule."


class LeakageTests(unittest.TestCase):
    def _adapter(self, tmp: str) -> KnowITAdapter:
        ann = Path(tmp) / "knowit_train.csv"
        ann.write_text(_KNOWIT_TSV, encoding="utf-8")
        return KnowITAdapter({"train": ann}, video_root=Path(tmp) / "videos")

    def test_guard_removes_own_reason_but_not_without_guard(self):
        with tempfile.TemporaryDirectory() as tmp:
            adapter = self._adapter(tmp)
            corpus = build_knowledge_corpus(adapter, split="train")
            self.assertTrue(corpus.enabled)
            qa0 = list(adapter.iter_qa_instances("train"))[0]

            # Without the guard the row's own gold reason is retrievable (it matches its question)...
            unguarded = [r["text"] for r in corpus.retrieve(qa0.question, qa0.options, k=5)]
            self.assertIn(_OWN_REASON, unguarded)

            # ...and with exclude_scene it is suppressed.
            guarded = [r["text"] for r in corpus.retrieve(qa0.question, qa0.options, k=5, exclude_scene=qa0.video_id)]
            self.assertNotIn(_OWN_REASON, guarded)

    def test_retrieve_evidence_applies_leakage_guard(self):
        with tempfile.TemporaryDirectory() as tmp:
            adapter = self._adapter(tmp)
            corpus = build_knowledge_corpus(adapter, split="train")
            qa0 = list(adapter.iter_qa_instances("train"))[0]
            packet = retrieve_evidence(
                qa0,
                build_retrieval_index([], [], []),
                {"Bknow": 5},
                need=EvidenceNeed(needs_knowledge=True),
                knowledge=corpus,
            )
            self.assertNotIn(_OWN_REASON, [k["text"] for k in packet.knowledge])

    def test_non_knowit_corpus_is_disabled(self):
        with tempfile.TemporaryDirectory() as tmp:
            adapter = self._adapter(tmp)
            adapter.dataset = "tvqa"  # simulate a non-KnowIT adapter
            corpus = build_knowledge_corpus(adapter, split="train")
            self.assertFalse(corpus.enabled)
            self.assertEqual(corpus.retrieve("anything", [], 5), [])


if __name__ == "__main__":
    unittest.main()
