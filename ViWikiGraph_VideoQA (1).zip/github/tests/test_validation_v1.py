import unittest

from viwikigraph.core.schemas import CrossModalLink, EvidenceUnit, LinkType, Modality, WikiSection
from viwikigraph.knowledge.validation import support_score, validate_item, validate_link


def _unit(eid, **kw):
    return EvidenceUnit(evidence_id=eid, video_id="v1", modality=kw.pop("modality", Modality.SUBTITLE), **kw)


class FactLevelSupportTests(unittest.TestCase):
    def test_fact_support_credits_claim_matching_a_triple(self):
        # Unit text/entities are unrelated; only the structured fact matches the claim (eq. 10 supp_f).
        unit = _unit("ev1", text="unrelated chatter here", facts=[("Penny", "enters", "apartment")])
        score, supporting = support_score("Penny enters the apartment", [unit])
        self.assertGreater(score, 0.5)
        self.assertIn("ev1", supporting)

    def test_single_entity_overlap_does_not_over_credit_fact(self):
        # Only the head shares a token (<2 of h/r/o) -> fact contributes nothing.
        unit = _unit("ev1", text="", facts=[("Penny", "drinks", "coffee")])
        score, _ = support_score("Penny solves a difficult physics equation", [unit])
        self.assertLessEqual(score, 0.3)


class OcrConsistencyTests(unittest.TestCase):
    def test_ocr_numeric_contradiction_lowers_consistency(self):
        ocr = _unit("ocr1", modality=Modality.OCR, text="The price is 10 dollars")
        result = validate_item("c1", "claim", "The price is 5 dollars", [ocr])
        self.assertEqual(result.consistency, 0.3)
        self.assertIn("OCR", result.notes)


class LinkValidationTests(unittest.TestCase):
    def test_validate_item_link_defaults_to_one_without_links(self):
        unit = _unit("ev1", text="Penny enters the apartment", entities=["Penny"])
        result = validate_item("c1", "claim", "Penny enters the apartment", [unit])
        self.assertEqual(result.link, 1.0)
        self.assertIn("e_text", result.support_signals)

    def test_incident_low_quality_link_lowers_link_dimension(self):
        unit = _unit("ev1", text="Penny enters the apartment", entities=["Penny"])
        weak_link = CrossModalLink(
            link_id="link_1",
            video_id="v1",
            source_id="c1",
            target_id="ev1",
            link_type=LinkType.CLAIM_TEXT,
            confidence=0.0,
            provenance={},  # no provenance + zero confidence -> low self-quality
        )
        result = validate_item("c1", "claim", "Penny enters the apartment", [unit], links=[weak_link])
        self.assertLess(result.link, 1.0)

    def test_validate_link_rewards_aligned_provenanced_link(self):
        section = WikiSection(
            section_id="scene_1", video_id="v1", section_type="scene", heading="S1",
            content="Penny enters the apartment", start=1.0, end=3.0,
        )
        unit = _unit("ev1", text="Penny enters the apartment", start=1.0, end=3.0)
        good = CrossModalLink(
            link_id="link_1", video_id="v1", source_id="scene_1", target_id="ev1",
            link_type=LinkType.CLAIM_TEXT, start=1.0, end=3.0, confidence=0.9,
            provenance={"rule": "section_evidence"},
        )
        bad = CrossModalLink(
            link_id="link_2", video_id="v1", source_id="scene_1", target_id="ev1",
            link_type=LinkType.CLAIM_TEXT, start=100.0, end=120.0, confidence=0.2, provenance={},
        )
        items = {"scene_1": section}
        evid = {"ev1": unit}
        good_res = validate_link(good, items, evid)
        bad_res = validate_link(bad, items, evid)
        self.assertGreater(good_res.link, bad_res.link)
        self.assertEqual(good_res.item_type, "cross_modal_link")


if __name__ == "__main__":
    unittest.main()
