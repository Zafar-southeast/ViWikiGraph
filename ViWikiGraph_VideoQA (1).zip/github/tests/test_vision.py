"""VLM visual-evidence extraction (the opt-in video-LLM stream)."""

import tempfile
import unittest
from pathlib import Path

from tests._stubs import StubLLM
from viwikigraph.core.schemas import Modality, VideoRecord
from viwikigraph.knowledge.vision import extract_visual_evidence


_VISION_JSON = {
    "frames": [
        {"index": 0, "description": "A woman walks into an apartment.",
         "objects": ["couch", "lamp"], "entities": ["Penny"], "actions": ["walking"],
         "events": ["entering the apartment"], "ocr": "APT 4A"},
        {"index": 1, "description": "A man waves from the sofa.",
         "objects": ["sofa"], "entities": ["Leonard"], "actions": ["waving"], "events": [], "ocr": ""},
    ]
}


def _record(video_path: str):
    return VideoRecord(dataset="nextqa", split="val", video_id="v1", video_path=video_path)


def _fake_sampler(_video_path, output_dir, num_frames):
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    frames = []
    for i in range(min(num_frames, 2)):
        p = out / f"frame_{i + 1:04d}.jpg"
        p.write_bytes(b"\xff\xd8\xff")  # minimal fake jpeg bytes
        frames.append((float(i) * 2.0, p))
    return frames


def _fake_sampler_many(_video_path, output_dir, num_frames):
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    frames = []
    for i in range(num_frames):
        p = out / f"frame_{i + 1:04d}.jpg"
        p.write_bytes(b"\xff\xd8\xff")
        frames.append((float(i), p))
    return frames


class ChunkLimitedVisionLLM:
    available = True

    def __init__(self, *, fail_on_call: int | None = None, fail_stems: set[str] | None = None):
        self.calls: list[list[str]] = []
        self.fail_on_call = fail_on_call
        self.fail_stems = fail_stems or set()

    def strict_json_vision(self, _prompt, image_paths, *, cache_version="v1", max_tokens=None):
        self.calls.append([str(path) for path in image_paths])
        if len(image_paths) > 4:
            raise RuntimeError("too many frames in one request")
        if self.fail_on_call is not None and len(self.calls) == self.fail_on_call:
            raise RuntimeError("malformed json")
        if any(Path(path).stem in self.fail_stems for path in image_paths):
            raise RuntimeError("malformed json")
        return {
            "frames": [
                {
                    "index": index,
                    "description": f"Frame {Path(path).stem}",
                    "objects": [f"object_{index}"],
                    "entities": [],
                    "actions": ["visible action"],
                    "events": [],
                    "ocr": "",
                }
                for index, path in enumerate(image_paths)
            ]
        }


class VisionExtractionTests(unittest.TestCase):
    def test_extracts_caption_and_ocr_units_from_frames(self):
        with tempfile.TemporaryDirectory() as tmp:
            llm = StubLLM(json_response=_VISION_JSON)
            units = extract_visual_evidence(
                _record("x.mp4"), llm, num_frames=2, output_dir=tmp, sampler=_fake_sampler
            )
            captions = [u for u in units if u.modality == Modality.CAPTION]
            ocr = [u for u in units if u.modality == Modality.OCR]
            self.assertEqual(len(captions), 2)
            self.assertEqual(len(ocr), 1)  # only frame 0 had OCR text
            first = captions[0]
            self.assertIn("Penny", first.entities)
            self.assertIn("couch", first.objects)
            self.assertEqual(first.start, 0.0)
            self.assertTrue(first.media_paths and first.media_paths[0].endswith(".jpg"))
            self.assertEqual(first.provenance["source"], "vlm")
            self.assertEqual(ocr[0].text, "APT 4A")

    def test_ok_records_vision_status(self):
        with tempfile.TemporaryDirectory() as tmp:
            record = _record("x.mp4")
            llm = StubLLM(json_response=_VISION_JSON)
            extract_visual_evidence(record, llm, num_frames=2, output_dir=tmp, sampler=_fake_sampler)
            self.assertEqual(record.metadata["vision_status"], "ok")
            self.assertEqual(record.metadata["frames_sampled"], 2)
            self.assertEqual(record.metadata["frames_described"], 2)

    def test_large_frame_budget_is_chunked_into_four_frame_vision_calls(self):
        with tempfile.TemporaryDirectory() as tmp:
            record = _record("x.mp4")
            llm = ChunkLimitedVisionLLM()

            units = extract_visual_evidence(
                record, llm, num_frames=8, output_dir=tmp, sampler=_fake_sampler_many
            )

            captions = [unit for unit in units if unit.modality == Modality.CAPTION]
            self.assertEqual([len(call) for call in llm.calls], [4, 4])
            self.assertEqual(len(captions), 8)
            self.assertEqual(len({unit.evidence_id for unit in units}), len(units))
            self.assertEqual(record.metadata["vision_status"], "ok")
            self.assertEqual(record.metadata["frames_sampled"], 8)
            self.assertEqual(record.metadata["frames_described"], 8)
            self.assertEqual([unit.provenance["frame_index"] for unit in captions], list(range(8)))

    def test_failed_vision_chunk_retries_individual_frames(self):
        with tempfile.TemporaryDirectory() as tmp:
            record = _record("x.mp4")
            llm = ChunkLimitedVisionLLM(fail_on_call=1)

            units = extract_visual_evidence(
                record, llm, num_frames=4, output_dir=tmp, sampler=_fake_sampler_many
            )

            captions = [unit for unit in units if unit.modality == Modality.CAPTION]
            self.assertEqual([len(call) for call in llm.calls], [4, 1, 1, 1, 1])
            self.assertEqual(len(captions), 4)
            self.assertEqual(record.metadata["vision_status"], "ok")
            self.assertEqual(record.metadata["frames_sampled"], 4)
            self.assertEqual(record.metadata["frames_described"], 4)

    def test_failed_vision_chunk_preserves_successful_chunk_evidence(self):
        with tempfile.TemporaryDirectory() as tmp:
            record = _record("x.mp4")
            llm = ChunkLimitedVisionLLM(
                fail_on_call=2,
                fail_stems={"frame_0005", "frame_0006", "frame_0007", "frame_0008"},
            )

            units = extract_visual_evidence(
                record, llm, num_frames=8, output_dir=tmp, sampler=_fake_sampler_many
            )

            captions = [unit for unit in units if unit.modality == Modality.CAPTION]
            self.assertEqual([len(call) for call in llm.calls], [4, 4, 1, 1, 1, 1])
            self.assertEqual(len(captions), 4)
            self.assertEqual(record.metadata["vision_status"], "partial")
            self.assertEqual(record.metadata["frames_sampled"], 8)
            self.assertEqual(record.metadata["frames_described"], 4)
            self.assertIn("malformed json", record.metadata["vision_detail"])

    def test_empty_response_records_status_empty(self):
        # Frames sampled + a parseable response, but no usable per-frame facts — the silent failure that
        # produced 10/20 evidence-free packages. Must be flagged "empty", not look like "no video".
        with tempfile.TemporaryDirectory() as tmp:
            record = _record("x.mp4")
            llm = StubLLM(json_response={"frames": []})
            units = extract_visual_evidence(
                record, llm, num_frames=2, output_dir=tmp, sampler=_fake_sampler
            )
            self.assertEqual(units, [])
            self.assertEqual(record.metadata["vision_status"], "empty")
            self.assertEqual(record.metadata["frames_sampled"], 2)

    def test_vision_call_error_records_status_error(self):
        def _boom(_prompt):
            raise RuntimeError("blocked by safety")

        with tempfile.TemporaryDirectory() as tmp:
            record = _record("x.mp4")
            llm = StubLLM(json_response=_boom)
            units = extract_visual_evidence(
                record, llm, num_frames=2, output_dir=tmp, sampler=_fake_sampler
            )
            self.assertEqual(units, [])
            self.assertEqual(record.metadata["vision_status"], "error")
            self.assertIn("RuntimeError", record.metadata["vision_detail"])

    def test_no_llm_is_noop(self):
        with tempfile.TemporaryDirectory() as tmp:
            record = _record("x.mp4")
            self.assertEqual(
                extract_visual_evidence(record, None, output_dir=tmp, sampler=_fake_sampler), []
            )
            self.assertEqual(record.metadata["vision_status"], "no_llm")

    def test_no_frames_is_noop(self):
        with tempfile.TemporaryDirectory() as tmp:
            llm = StubLLM(json_response=_VISION_JSON)
            units = extract_visual_evidence(
                _record("x.mp4"), llm, output_dir=tmp, sampler=lambda *a, **k: []
            )
            self.assertEqual(units, [])

    def test_real_sampler_skips_without_ffmpeg_or_video(self):
        # Default sampler returns [] when the video file is absent (no ffmpeg call) — offline-safe.
        with tempfile.TemporaryDirectory() as tmp:
            llm = StubLLM(json_response=_VISION_JSON)
            units = extract_visual_evidence(_record(str(Path(tmp) / "missing.mp4")), llm, output_dir=tmp)
            self.assertEqual(units, [])


class ChatVisionPayloadTests(unittest.TestCase):
    def test_chat_vision_builds_image_url_parts(self):
        from viwikigraph.llm.client import LLMClient

        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            img = tmp / "f.jpg"
            img.write_bytes(b"\xff\xd8\xffhello")
            client = LLMClient(api_key="test-key", cache_dir=tmp / "cache")

            captured = {}

            def fake_post(payload, *, path=None):
                captured["payload"] = payload
                return {"choices": [{"message": {"content": '{"frames": []}'}}]}

            client._post = fake_post  # type: ignore[assignment]
            client.strict_json_vision("describe", [img], cache_version="t")

            content = captured["payload"]["messages"][0]["content"]
            self.assertEqual(content[0]["type"], "text")
            self.assertEqual(content[1]["type"], "image_url")
            self.assertTrue(content[1]["image_url"]["url"].startswith("data:image/jpeg;base64,"))

    def test_chat_vision_is_cached(self):
        from viwikigraph.llm.client import LLMClient

        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            img = tmp / "f.jpg"
            img.write_bytes(b"\xff\xd8\xffhello")
            client = LLMClient(api_key="test-key", cache_dir=tmp / "cache")
            calls = {"n": 0}

            def fake_post(payload, *, path=None):
                calls["n"] += 1
                return {"choices": [{"message": {"content": "ok"}}]}

            client._post = fake_post  # type: ignore[assignment]
            client.chat_vision("p", [img])
            client.chat_vision("p", [img])  # identical → served from cache
            self.assertEqual(calls["n"], 1)

    def test_blocked_vision_response_is_not_cached(self):
        # A content-filtered / empty completion must NOT poison the cache — otherwise a transient
        # refusal becomes permanent until cache_version is bumped. It should re-issue on the next call.
        from viwikigraph.llm.client import LLMClient

        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            img = tmp / "f.jpg"
            img.write_bytes(b"\xff\xd8\xffhello")
            client = LLMClient(api_key="test-key", cache_dir=tmp / "cache")
            calls = {"n": 0}

            def fake_post(payload, *, path=None):
                calls["n"] += 1
                return {"choices": [{"message": {"content": ""}, "finish_reason": "content_filter"}]}

            client._post = fake_post  # type: ignore[assignment]
            client.chat_vision("p", [img])
            client.chat_vision("p", [img])  # refusal not cached → re-issued
            self.assertEqual(calls["n"], 2)

    def test_unparseable_json_vision_response_is_not_cached(self):
        from viwikigraph.llm.client import LLMClient

        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            img = tmp / "f.jpg"
            img.write_bytes(b"\xff\xd8\xffhello")
            client = LLMClient(api_key="test-key", cache_dir=tmp / "cache")
            calls = {"n": 0}

            def fake_post(payload, *, path=None):
                calls["n"] += 1
                return {"choices": [{"message": {"content": "I cannot describe these images."}}]}

            client._post = fake_post  # type: ignore[assignment]
            client.chat_vision("p", [img], response_format="json")
            client.chat_vision("p", [img], response_format="json")  # prose, not JSON → not cached
            self.assertEqual(calls["n"], 2)


if __name__ == "__main__":
    unittest.main()
