import unittest

from tests._stubs import StubLLM
from viwikigraph.llm.prompts import mcq_prompt
from viwikigraph.qa.answering import answer_question
from viwikigraph.core.schemas import EvidencePacket, QAInstance, WikiSection


def _packet(content: str) -> EvidencePacket:
    return EvidencePacket(
        question_id="q",
        video_id="v",
        narrative_sections=[
            WikiSection(
                section_id="scene_1",
                video_id="v",
                section_type="scene",
                heading="Scene 1",
                content=content,
                confidence=0.9,
            )
        ],
    )


class QAScoringTests(unittest.TestCase):
    def test_choice_scorer_maps_index_to_option(self):
        qa = QAInstance(
            question_id="q",
            video_id="v",
            question="What color is the door?",
            options=["blue", "red", "green", "yellow"],
            answer_index=1,
        )
        llm = StubLLM(
            json_response={
                "answer_index": 1,
                "answer": "red",
                "confidence": 0.9,
                "evidence_ids": ["scene_1"],
                "rationale": "the door is red",
            }
        )
        prediction = answer_question(qa, _packet("the door is red"), llm=llm, verify=False)

        self.assertEqual(prediction.predicted_index, 1)
        self.assertEqual(prediction.answer, "red")
        self.assertEqual(prediction.scoring_method, "llm_choice")

    def test_mcq_abstention_falls_back_to_a_guess(self):
        qa = QAInstance(
            question_id="q",
            video_id="v",
            question="What color is the door?",
            options=["blue door", "red door", "green wall", "yellow car"],
            answer_index=1,
        )
        # Model declines to commit (answer_index is null). Forced-choice MCQ has no abstain slot, so
        # the answer must still resolve to an option — here the red-door evidence overlap.
        llm = StubLLM(json_response={"answer_index": None, "answer": "I cannot tell", "confidence": 0.9})
        prediction = answer_question(qa, _packet("the door is red and clearly red"), llm=llm, verify=False)

        self.assertEqual(prediction.predicted_index, 1)
        self.assertEqual(prediction.scoring_method, "llm_choice_guess")
        self.assertLessEqual(prediction.confidence, 0.2)

    def test_verification_keeps_mcq_option_text_not_prose(self):
        # When verification fires on an MCQ, the verifier's free-text "revised_answer" must NOT replace
        # the committed option — eval keys on predicted_index, so a prose answer on a committed index is
        # incoherent and reads as an abstention. Verification only adjusts confidence on MCQ.
        qa = QAInstance(
            question_id="q",
            video_id="v",
            question="What color is the door?",
            options=["blue door", "red door", "green wall", "yellow car"],
            answer_index=1,
        )

        def respond(prompt: str) -> dict:
            if "Verify a draft answer" in prompt:
                return {
                    "claims": [{"claim": "the door is red", "verdict": "unsup", "evidence_ids": []}],
                    "revised_answer": "There is no evidence to determine the color.",
                    "confidence": 0.1,
                }
            return {
                "answer_index": 1, "answer": "red door", "confidence": 0.9,
                "evidence_ids": ["scene_1"], "rationale": "the door is red",
            }

        llm = StubLLM(json_response=respond)
        prediction = answer_question(
            qa, _packet("the door is red"), llm=llm, verify=True, risk_threshold=0.0
        )

        self.assertEqual(prediction.predicted_index, 1)        # commitment preserved
        self.assertEqual(prediction.answer, "red door")        # option text, not the verifier prose
        self.assertTrue(prediction.scoring_method.endswith("+verified"))

    def test_mcq_never_abstains_on_garbage_response(self):
        # Even a totally empty model response (no answer_index key at all) must resolve to a committed
        # option on MCQ — there is no abstain slot, so a null index is a guaranteed miss.
        qa = QAInstance(
            question_id="q",
            video_id="v",
            question="What color is the door?",
            options=["blue door", "red door", "green wall", "yellow car"],
            answer_index=1,
        )
        llm = StubLLM(json_response={})
        prediction = answer_question(qa, _packet("the door is red"), llm=llm, verify=False)

        self.assertIsNotNone(prediction.predicted_index)
        self.assertEqual(prediction.scoring_method, "llm_choice_guess")

    def test_forced_guess_tiebreak_is_not_always_index_zero(self):
        # On empty/unrelated context every option ties at 0 overlap. The forced pick must vary by
        # question (stable hash) rather than collapsing to index 0 every time — a fixed-index bias is
        # worse than chance on NExT-QA, whose gold index is ~uniform.
        options = ["alpha", "bravo", "charlie", "delta", "echo"]
        picks = set()
        for i in range(40):
            qa = QAInstance(
                question_id=f"q{i}", video_id="v", question="unrelated?",
                options=options, answer_index=0,
            )
            pred = answer_question(qa, _packet("totally different evidence"), llm=None)
            self.assertEqual(pred.scoring_method, "heuristic_overlap")
            self.assertIsNotNone(pred.predicted_index)
            picks.add(pred.predicted_index)
        self.assertGreater(len(picks), 1)  # not collapsed onto a single index

        # ...and the pick is deterministic for a given question_id (run-independent hash).
        qa = QAInstance(
            question_id="q7", video_id="v", question="unrelated?", options=options, answer_index=0,
        )
        a = answer_question(qa, _packet("totally different evidence"), llm=None).predicted_index
        b = answer_question(qa, _packet("totally different evidence"), llm=None).predicted_index
        self.assertEqual(a, b)

    def test_deterministic_fallback_without_llm(self):
        qa = QAInstance(
            question_id="q",
            video_id="v",
            question="What color is the door?",
            options=["blue door", "red door", "green wall", "yellow car"],
            answer_index=1,
        )
        prediction = answer_question(qa, _packet("the door is red and clearly red"), llm=None)

        self.assertEqual(prediction.scoring_method, "heuristic_overlap")
        self.assertEqual(prediction.predicted_index, 1)  # "red door" overlaps the red-door evidence

    def test_llm_failure_records_fallback_reason_in_trace(self):
        qa = QAInstance(
            question_id="q",
            video_id="v",
            question="What color is the door?",
            options=["blue door", "red door", "green wall", "yellow car"],
            answer_index=1,
        )

        def fail(_prompt: str) -> dict:
            raise RuntimeError("malformed qa json")

        prediction = answer_question(
            qa,
            _packet("the door is red and clearly red"),
            llm=StubLLM(json_response=fail),
            verify=False,
        )

        self.assertEqual(prediction.scoring_method, "heuristic_overlap")
        fallback_entries = [entry["fallback"] for entry in prediction.evidence_trace if "fallback" in entry]
        self.assertEqual(len(fallback_entries), 1)
        self.assertEqual(fallback_entries[0]["from"], "llm_choice")
        self.assertIn("RuntimeError", fallback_entries[0]["error_type"])
        self.assertIn("malformed qa json", fallback_entries[0]["error"])

    def test_mcq_prompt_discourages_lexical_option_matches(self):
        prompt = mcq_prompt(
            "Why are there four pieces of food left?",
            ["girl ate one", "one falls off the table"],
            "Evidence: girl brings food to her mouth while pieces remain on the tray.",
        )

        self.assertIn("Do not choose an option just because its words appear in the evidence", prompt)
        self.assertIn("full meaning of the option", prompt)

    def test_logprob_scorer_picks_highest_likelihood(self):
        qa = QAInstance(
            question_id="q",
            video_id="v",
            question="What color is the door?",
            options=["blue", "red", "green"],
            answer_index=1,
        )
        # Higher (less negative) normalized logprob for "red".
        scores = {"blue": -3.0, "red": -0.5, "green": -2.0}
        llm = StubLLM(logprob=lambda prefix, option: scores[option])
        prediction = answer_question(qa, _packet("the door is red"), llm=llm, scorer="logprob", verify=False)

        self.assertEqual(prediction.predicted_index, 1)
        self.assertEqual(prediction.scoring_method, "llm_logprob")


if __name__ == "__main__":
    unittest.main()
