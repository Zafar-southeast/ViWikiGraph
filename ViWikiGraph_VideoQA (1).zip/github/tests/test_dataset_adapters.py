import json
import pickle
import tempfile
import unittest
from pathlib import Path

from viwikigraph.datasets.adapters import (
    KnowITAdapter,
    NextQAAdapter,
    TVQAAdapter,
    clean_html_subtitle,
    parse_knowit_scene_id,
)


class DatasetAdapterTests(unittest.TestCase):
    def test_clean_html_subtitle_converts_speaker_markup(self):
        raw = "<b>Howard</b>: Hi.<br /><b>Penny</b>: Let's go."

        self.assertEqual(clean_html_subtitle(raw), "Howard: Hi. Penny: Let's go.")

    def test_parse_knowit_scene_id_extracts_temporal_range(self):
        parsed = parse_knowit_scene_id("s01e16_scene002_0450_0470")

        self.assertEqual(parsed["show_id"], "s01e16")
        self.assertEqual(parsed["scene_id"], "scene002")
        self.assertEqual(parsed["start"], 450.0)
        self.assertEqual(parsed["end"], 470.0)

    def test_knowit_adapter_reads_tsv_without_leaking_reason_into_video_metadata(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            ann = root / "knowit_train.csv"
            ann.write_text(
                "answer1\tanswer2\tanswer3\tanswer4\tidxCorrect\tkg_type\tquestion\treason\tscene\tsubtitle\n"
                "A1\tA2\tA3\tA4\t2\tsame\tWhy?\tGold reason\t"
                "s01e16_scene002_0450_0470\t<b>Howard</b>: Hi.<br /><b>Penny</b>: OK.\n",
                encoding="utf-8",
            )

            adapter = KnowITAdapter({"train": ann}, video_root=root / "videos")
            records = list(adapter.iter_video_records("train"))
            qas = list(adapter.iter_qa_instances("train"))

            self.assertEqual(records[0].video_id, "s01e16_scene002_0450_0470")
            self.assertEqual(records[0].subtitles[0]["text"], "Howard: Hi. Penny: OK.")
            self.assertNotIn("reason", records[0].metadata)
            # KnowIT idxCorrect is 1-based in the TSV; the adapter normalizes it to a 0-based
            # answer_index so it aligns with the 0-based LLM/option indexing and evaluation.
            self.assertEqual(qas[0].answer_index, 1)  # idxCorrect=2 (1-based) -> 1 (0-based)
            self.assertEqual(qas[0].metadata["reason"], "Gold reason")

    def test_tvqa_adapter_reads_annotations_subtitles_and_visual_concepts(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            ann = root / "tvqa_val.json"
            subs = root / "subs.json"
            concepts = root / "concepts.pkl"
            ann.write_text(
                json.dumps(
                    [
                        {
                            "qid": 10,
                            "vid_name": "clip_1",
                            "q": "What happens?",
                            "a0": "A",
                            "a1": "B",
                            "a2": "C",
                            "a3": "D",
                            "a4": "E",
                            "answer_idx": "4",
                            "ts": [1.0, 2.0],
                            "bbox": {"1": [{"label": "Penny", "img_id": 1}]},
                        }
                    ]
                ),
                encoding="utf-8",
            )
            subs.write_text(
                json.dumps({"clip_1": {"sub_text": "Penny : Hello <eos> Leonard : Hi", "sub_time": [0.5, 1.5]}}),
                encoding="utf-8",
            )
            with concepts.open("wb") as handle:
                pickle.dump({"clip_1": ["woman , room", "man , door"]}, handle)

            adapter = TVQAAdapter({"val": ann}, subs, concepts, video_root=root / "videos")
            record = next(adapter.iter_video_records("val"))
            qa = next(adapter.iter_qa_instances("val"))

            self.assertEqual(record.subtitles[0]["text"], "Penny : Hello")
            self.assertEqual(record.metadata["visual_concepts"][0], "woman , room")
            self.assertEqual(qa.options[4], "E")
            self.assertEqual(qa.metadata["bbox"]["1"][0]["label"], "Penny")

    def test_nextqa_adapter_reads_csv_and_vidor_map(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            ann = root / "train.csv"
            mapping = root / "map_vid_vidorID.json"
            ann.write_text(
                "video,question,a0,a1,a2,a3,a4,answer,type\n"
                "123,Why does he run?,to jump,to hide,to win,to sleep,to eat,2,CW\n",
                encoding="utf-8",
            )
            # Real map values are "<group>/<id>" and NExTVideo lays videos out the same way.
            mapping.write_text(json.dumps({"123": "0101/123"}), encoding="utf-8")

            adapter = NextQAAdapter({"train": ann}, mapping, video_root=root / "videos")
            record = next(adapter.iter_video_records("train"))
            qa = next(adapter.iter_qa_instances("train"))

            self.assertEqual(record.video_id, "123")
            self.assertEqual(record.metadata["vidor_id"], "0101/123")
            # video_path must resolve into the VidOR subfolder layout, not flat <id>.mp4.
            self.assertTrue(record.video_path.endswith("videos/0101/123.mp4"))
            self.assertEqual(qa.answer_index, 2)
            self.assertEqual(qa.metadata["question_type"], "CW")

    def test_nextqa_unmapped_video_falls_back_to_flat_path(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            ann = root / "train.csv"
            ann.write_text(
                "video,question,a0,a1,a2,a3,a4,answer,type\n"
                "999,Q?,a,b,c,d,e,0,CW\n",
                encoding="utf-8",
            )
            mapping = root / "map_vid_vidorID.json"
            mapping.write_text(json.dumps({"123": "0101/123"}), encoding="utf-8")  # 999 not mapped
            adapter = NextQAAdapter({"train": ann}, mapping, video_root=root / "videos")
            record = next(adapter.iter_video_records("train"))
            self.assertTrue(record.video_path.endswith("videos/999.mp4"))
            self.assertIsNone(record.metadata["vidor_id"])


if __name__ == "__main__":
    unittest.main()
