"""P1: evaluation rigor — Wilson CIs, per-question-type breakdown, and the fallback-rate health metric.

At n=50 a bare point accuracy hid that exp5/6/7 (.76/.78/.76) were statistically indistinguishable and
that 26% of answers came from the near-chance token-overlap fallback. These metrics surface both.
"""

import unittest

from viwikigraph.qa.evaluation import evaluate_predictions, wilson_interval
from viwikigraph.core.schemas import QAInstance, QAPrediction


def _qa(qid: str, gold: int, qtype: str) -> QAInstance:
    return QAInstance(
        question_id=qid, video_id=qid.split("_")[0], question="?",
        options=["a", "b", "c", "d", "e"], answer_index=gold, metadata={"question_type": qtype},
    )


def _pred(qid: str, pred: int, method: str) -> QAPrediction:
    return QAPrediction(question_id=qid, video_id=qid.split("_")[0], answer="x",
                        predicted_index=pred, scoring_method=method)


class WilsonIntervalTests(unittest.TestCase):
    def test_known_interval_for_38_of_50(self):
        low, high = wilson_interval(38, 50)
        self.assertAlmostEqual(low, 0.626, places=2)
        self.assertAlmostEqual(high, 0.857, places=2)

    def test_empty_sample_is_zero_width(self):
        self.assertEqual(wilson_interval(0, 0), (0.0, 0.0))

    def test_bounds_are_clamped(self):
        low, high = wilson_interval(50, 50)
        self.assertGreaterEqual(low, 0.0)
        self.assertLessEqual(high, 1.0)


class EvaluateMetricsTests(unittest.TestCase):
    def _data(self):
        qas = [
            _qa("v1_0", 0, "TN"), _qa("v2_0", 1, "TN"),  # TN: 1 right (llm), 1 wrong (fallback)
            _qa("v3_0", 2, "CH"),                          # CH: 1 right (llm)
            _qa("v4_0", 3, "DL"),                          # DL: 1 wrong (fallback)
        ]
        preds = [
            _pred("v1_0", 0, "llm_choice"),
            _pred("v2_0", 4, "heuristic_overlap"),
            _pred("v3_0", 2, "llm_choice"),
            _pred("v4_0", 0, "heuristic_overlap"),
        ]
        return qas, preds

    def test_adds_ci_fallback_and_method_counts(self):
        qas, preds = self._data()
        metrics, _ = evaluate_predictions(qas, preds)
        self.assertEqual(metrics["count"], 4)
        self.assertEqual(metrics["accuracy"], 0.5)
        self.assertIn("accuracy_ci_low", metrics)
        self.assertIn("accuracy_ci_high", metrics)
        self.assertLess(metrics["accuracy_ci_low"], 0.5)
        self.assertGreater(metrics["accuracy_ci_high"], 0.5)
        self.assertEqual(metrics["fallback_rate"], 0.5)  # 2 of 4 heuristic_overlap
        self.assertEqual(metrics["method_counts"], {"heuristic_overlap": 2, "llm_choice": 2})

    def test_per_question_type_breakdown(self):
        qas, preds = self._data()
        metrics, _ = evaluate_predictions(qas, preds)
        by_type = metrics["by_question_type"]
        self.assertEqual(by_type["TN"]["count"], 2)
        self.assertEqual(by_type["TN"]["correct"], 1)
        self.assertEqual(by_type["TN"]["accuracy"], 0.5)
        self.assertEqual(by_type["CH"]["accuracy"], 1.0)
        self.assertEqual(by_type["DL"]["accuracy"], 0.0)
        for cell in by_type.values():
            self.assertIn("accuracy_ci_low", cell)
            self.assertIn("accuracy_ci_high", cell)

    def test_metrics_are_deterministic(self):
        qas, preds = self._data()
        a, _ = evaluate_predictions(qas, preds)
        b, _ = evaluate_predictions(qas, preds)
        self.assertEqual(a, b)


if __name__ == "__main__":
    unittest.main()
