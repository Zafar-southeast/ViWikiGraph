import tempfile
import unittest
import json
from pathlib import Path

from viwikigraph.pipeline import build_video_package
from viwikigraph.core.schemas import QAInstance, VideoRecord


class PackageBuilderTests(unittest.TestCase):
    def test_dry_run_build_writes_expected_package_shape(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            record = VideoRecord(
                dataset="fixture",
                split="val",
                video_id="clip_1",
                video_path=str(root / "missing.mp4"),
                subtitles=[{"text": "Penny opens the red door.", "start": 0.0, "end": 2.0}],
                metadata={"visual_concepts": ["red door , woman"]},
            )
            qa = QAInstance(
                question_id="q1",
                video_id="clip_1",
                question="What color is the door?",
                options=["blue", "red", "green", "yellow"],
                answer_index=1,
            )

            package = build_video_package(
                record=record,
                qa_instances=[qa],
                output_root=root / "outputs",
                budgets={"Bimg": 2, "keyframes": 2, "clips": 1},
                experiment_id="exp1",
                dry_run=True,
            )

            self.assertTrue((package.root / "evidence" / "evidence_units.jsonl").exists())
            self.assertTrue((package.root / "wiki" / "narrative_wiki.md").exists())
            self.assertTrue((package.root / "wiki" / "kg_wiki.md").exists())
            self.assertTrue((package.root / "index" / "retrieval_index.json").exists())
            self.assertTrue((package.root / "validation" / "claim_support.jsonl").exists())
            # Package lives under outputs/{experiment_id}/{dataset}/{split}/packages/{video_id}/.
            self.assertEqual(package.root.parent.parent.name, "val")
            self.assertIn("exp1", package.root.parts)
            manifest_path = package.root / "manifest.json"
            self.assertTrue(manifest_path.exists())
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            self.assertEqual(manifest["pipeline_mode"], "rag_only")
            self.assertFalse(manifest["training_enabled"])
            self.assertEqual(manifest["experiment_id"], "exp1")

    def test_manifest_persists_vision_failure_detail(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            record = VideoRecord(
                dataset="fixture",
                split="val",
                video_id="clip_1",
                video_path=str(root / "missing.mp4"),
                metadata={
                    "vision_status": "error",
                    "vision_detail": "RuntimeError: blocked by safety",
                    "frames_sampled": 4,
                    "frames_described": 0,
                },
            )

            package = build_video_package(
                record=record,
                qa_instances=[],
                output_root=root / "outputs",
                budgets={"Bimg": 2},
                experiment_id="exp1",
                dry_run=True,
            )

            manifest = json.loads((package.root / "manifest.json").read_text(encoding="utf-8"))
            self.assertEqual(manifest["vision_status"], "error")
            self.assertEqual(manifest["vision_detail"], "RuntimeError: blocked by safety")
            self.assertEqual(manifest["frames_sampled"], 4)
            self.assertEqual(manifest["frames_described"], 0)

    def test_no_pre_storage_validation_ablation_is_persisted(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            record = VideoRecord(
                dataset="fixture",
                split="val",
                video_id="clip_ablation",
                video_path=str(root / "missing.mp4"),
                subtitles=[{"text": "A person opens a door.", "start": 0.0, "end": 1.0}],
            )

            package = build_video_package(
                record=record,
                qa_instances=[],
                output_root=root / "outputs",
                budgets={"Bimg": 1},
                experiment_id="no_validation",
                dry_run=True,
                validate_before_storage=False,
            )

            manifest = json.loads((package.root / "manifest.json").read_text(encoding="utf-8"))
            self.assertFalse(manifest["pre_storage_validation"])
            self.assertEqual(manifest["validation_results"], 0)
            self.assertEqual(package.validations, [])
            self.assertEqual(
                (package.root / "validation" / "claim_support.jsonl").read_text(encoding="utf-8"),
                "",
            )
            # The generated package and retrieval index still exist; only validation is bypassed.
            self.assertTrue((package.root / "wiki" / "narrative_sections.jsonl").exists())
            self.assertTrue((package.root / "index" / "retrieval_index.json").exists())


if __name__ == "__main__":
    unittest.main()
