import unittest

from viwikigraph.retrieval.index import build_retrieval_index, retrieve_evidence, route_query
from viwikigraph.core.schemas import EvidenceUnit, Modality, QAInstance, WikiSection


class RouterTests(unittest.TestCase):
    def test_router_flags_temporal_and_visual(self):
        self.assertTrue(route_query("What happens after Penny opens the door?", ["a", "b"]).needs_temporal)
        self.assertTrue(route_query("What color is the door?", []).needs_visual)
        self.assertTrue(route_query("Why did Sheldon leave?", []).needs_knowledge)


class RetrievalTests(unittest.TestCase):
    def _index(self):
        sections = [
            WikiSection(
                section_id=f"scene_{i}",
                video_id="v",
                section_type="scene",
                heading=f"Scene {i}",
                content=f"content {i} about the door",
                confidence=0.9,
            )
            for i in range(6)
        ]
        subs = [
            EvidenceUnit(
                evidence_id=f"sub_{i}",
                video_id="v",
                modality=Modality.SUBTITLE,
                text=f"line {i} mentions a door",
                start=float(i),
                end=float(i) + 1.0,
            )
            for i in range(6)
        ]
        return build_retrieval_index(sections, [], [], subs)

    def test_budget_enforced(self):
        qa = QAInstance(question_id="q", video_id="v", question="where is the door", options=[])
        packet = retrieve_evidence(qa, self._index(), {"Bnar": 2, "Bsub": 3})
        self.assertLessEqual(len(packet.narrative_sections), 2)
        self.assertLessEqual(len(packet.subtitle_spans), 3)
        self.assertGreater(len(packet.subtitle_spans), 0)

    def test_subtitle_spans_respect_ts_window(self):
        qa = QAInstance(
            question_id="q",
            video_id="v",
            question="what about the door",
            options=[],
            metadata={"ts": [2.0, 3.5]},
        )
        packet = retrieve_evidence(qa, self._index(), {"Bsub": 6})
        # Window [2.0, 3.5] overlaps sub_1 (1-2), sub_2 (2-3), sub_3 (3-4); sub_0/4/5 are outside.
        ids = {span.evidence_id for span in packet.subtitle_spans}
        self.assertTrue(ids.issubset({"sub_1", "sub_2", "sub_3"}))
        self.assertIn("sub_2", ids)


if __name__ == "__main__":
    unittest.main()
