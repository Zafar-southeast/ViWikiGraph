import unittest

from tests._stubs import StubLLM
from viwikigraph.qa.answering import answer_question
from viwikigraph.core.schemas import EvidencePacket, KGItem, QAInstance, WikiSection


def _qa() -> QAInstance:
    return QAInstance(
        question_id="q",
        video_id="v",
        question="What color is the door?",
        options=["blue", "red", "green", "yellow"],
        answer_index=1,
    )


def _section() -> WikiSection:
    return WikiSection(
        section_id="scene_1", video_id="v", section_type="scene", heading="S",
        content="the door is red", confidence=0.9,
    )


def _routing_llm(mcq: dict, verify: dict | None = None) -> StubLLM:
    """StubLLM returning the mcq response normally and a verification response for verify prompts."""
    def handler(prompt: str) -> dict:
        if "Verify a draft answer" in prompt:
            return verify or {}
        return mcq
    return StubLLM(json_response=handler)


class ConditionalVerificationTests(unittest.TestCase):
    def test_high_risk_triggers_verification_and_applies_contradiction_penalty(self):
        # Low draft confidence + a contradiction link → risk above threshold → verify fires.
        packet = EvidencePacket(
            question_id="q", video_id="v",
            narrative_sections=[_section()],
            kg_items=[KGItem(item_id="c1", video_id="v", item_type="contradiction_link", label="A CONTRADICTS B")],
        )
        llm = _routing_llm(
            mcq={"answer_index": 1, "answer": "red", "confidence": 0.1, "evidence_ids": ["scene_1"], "rationale": "r"},
            verify={"claims": [{"claim": "the door is red", "verdict": "contr", "evidence_ids": ["scene_1"]}],
                    "revised_answer": "blue", "confidence": 0.2},
        )
        pred = answer_question(_qa(), packet, llm=llm, verify=True, risk_threshold=0.3)

        self.assertTrue(pred.scoring_method.endswith("+verified"))
        # On MCQ, verification calibrates confidence but does NOT swap the committed option for the
        # verifier's free-text "revised_answer" — eval keys on predicted_index, so the answer string
        # must stay consistent with the chosen option ("red" at index 1), not become "blue".
        self.assertEqual(pred.predicted_index, 1)
        self.assertEqual(pred.answer, "red")
        self.assertLessEqual(pred.confidence, 0.1)  # contradiction still halves confidence
        self.assertTrue(any("verification" in entry for entry in pred.evidence_trace))

    def test_low_risk_does_not_trigger_verification(self):
        packet = EvidencePacket(question_id="q", video_id="v", narrative_sections=[_section()])
        llm = _routing_llm(
            mcq={"answer_index": 1, "answer": "red", "confidence": 0.95, "evidence_ids": ["scene_1"], "rationale": "r"},
        )
        pred = answer_question(_qa(), packet, llm=llm, verify=True)  # default threshold 0.5

        self.assertEqual(pred.scoring_method, "llm_choice")
        verification_entries = [e for e in pred.evidence_trace if "verification" in e]
        self.assertTrue(verification_entries)
        self.assertFalse(verification_entries[0]["verification"]["triggered"])

    def test_verify_flag_off_skips_verification(self):
        packet = EvidencePacket(question_id="q", video_id="v", narrative_sections=[_section()])
        llm = _routing_llm(mcq={"answer_index": 1, "answer": "red", "confidence": 0.1, "evidence_ids": [], "rationale": "r"})
        pred = answer_question(_qa(), packet, llm=llm, verify=False)

        self.assertEqual(pred.scoring_method, "llm_choice")
        self.assertFalse(any("verification" in e for e in pred.evidence_trace))

    def test_no_llm_never_verifies(self):
        packet = EvidencePacket(question_id="q", video_id="v", narrative_sections=[_section()])
        pred = answer_question(_qa(), packet, llm=None, verify=True)

        self.assertEqual(pred.scoring_method, "heuristic_overlap")
        self.assertFalse(any("verification" in e for e in pred.evidence_trace))


if __name__ == "__main__":
    unittest.main()
