import json
import unittest

from viwikigraph.core.schemas import (
    ClaimTrace,
    CrossModalLink,
    EvidencePacket,
    EvidenceUnit,
    LinkType,
    MediaItem,
    Modality,
    QAInstance,
    QAPrediction,
    ValidationResult,
    VideoRecord,
    WikiPatch,
)


class SchemaTests(unittest.TestCase):
    def test_evidence_unit_round_trips_json(self):
        unit = EvidenceUnit(
            evidence_id="ev1",
            video_id="clip_1",
            modality=Modality.SUBTITLE,
            text="Penny enters the room.",
            start=1.25,
            end=3.5,
            confidence=0.9,
            provenance={"subtitle_index": 2, "source": "fixture"},
            entities=["Penny"],
            actions=["enters"],
            facts=[("Penny", "enters", "room")],
        )

        decoded = EvidenceUnit.from_dict(json.loads(unit.to_json()))

        self.assertEqual(decoded.evidence_id, "ev1")
        self.assertEqual(decoded.modality, Modality.SUBTITLE)
        self.assertEqual(decoded.facts, [("Penny", "enters", "room")])
        self.assertEqual(decoded.provenance["subtitle_index"], 2)

    def test_qa_prediction_keeps_trace_and_scoring_method(self):
        prediction = QAPrediction(
            question_id="q1",
            video_id="clip_1",
            answer="A",
            confidence=0.7,
            evidence_trace=[{"claim": "Penny enters", "evidence_ids": ["ev1"]}],
            scoring_method="constrained_option",
        )

        encoded = prediction.to_dict()

        self.assertEqual(encoded["scoring_method"], "constrained_option")
        self.assertEqual(encoded["evidence_trace"][0]["evidence_ids"], ["ev1"])

    def test_packet_validation_and_video_records_are_serializable(self):
        record = VideoRecord(
            dataset="knowit",
            split="train",
            video_id="s01e16_scene002_0450_0470",
            video_path="/videos/s01e16_scene002_0450_0470.mp4",
            subtitles=[],
            metadata={"season": "01"},
        )
        qa = QAInstance(
            question_id="q1",
            video_id=record.video_id,
            question="Why?",
            options=["a", "b", "c", "d"],
            answer_index=2,
            metadata={"reason": "held out"},
        )
        media = MediaItem(
            media_id="m1",
            video_id=record.video_id,
            media_type="snapshot",
            path="media/snapshots/0001.jpg",
            start=4.5,
            end=4.5,
            linked_item_id="scene_1",
            confidence=0.8,
            provenance={"frame": 1},
        )
        validation = ValidationResult(
            item_id="claim_1",
            item_type="claim",
            support=0.8,
            provenance=1.0,
            consistency=1.0,
            coverage=0.5,
            media=1.0,
            decision="keep",
            evidence_ids=["ev1"],
        )
        packet = EvidencePacket(
            question_id=qa.question_id,
            video_id=record.video_id,
            narrative_sections=[],
            kg_items=[],
            media_items=[media],
            subtitle_spans=[],
        )

        self.assertEqual(VideoRecord.from_dict(record.to_dict()).video_id, record.video_id)
        self.assertEqual(QAInstance.from_dict(qa.to_dict()).answer_index, 2)
        self.assertEqual(MediaItem.from_dict(media.to_dict()).media_type, "snapshot")
        # 6-dim weights (eq. 23) with q_link defaulting to 1.0:
        # 0.35*0.8 + 0.20*1.0 + 0.18*1.0 + 0.12*0.5 + 0.08*1.0 + 0.07*1.0 = 0.87.
        self.assertEqual(ValidationResult.from_dict(validation.to_dict()).score, 0.87)
        self.assertEqual(EvidencePacket.from_dict(packet.to_dict()).media_items[0].media_id, "m1")

    def test_validation_result_link_dimension_and_signals_round_trip(self):
        # Default link is 1.0 (vacuously satisfied) and is the 9th positional arg (after decision).
        kept = ValidationResult("c1", "claim", 0.9, 1.0, 1.0, 1.0, 1.0, "keep")
        self.assertEqual(kept.link, 1.0)

        result = ValidationResult(
            item_id="c2",
            item_type="claim",
            support=0.8,
            provenance=1.0,
            consistency=1.0,
            coverage=0.5,
            media=1.0,
            decision="keep",
            link=0.0,
            support_signals={"e_text": 0.8, "e_ent": 0.4, "e_time": 1.0, "e_vis": 0.0, "e_ocr": 1.0},
            unsupported_span="the unsupported clause",
        )
        # link=0.0 must lower the score relative to the link=1.0 default (0.87 -> 0.80).
        self.assertLess(result.score, 0.87)
        decoded = ValidationResult.from_dict(result.to_dict())
        self.assertEqual(decoded.link, 0.0)
        self.assertEqual(decoded.support_signals["e_ocr"], 1.0)
        self.assertEqual(decoded.unsupported_span, "the unsupported clause")

    def test_cross_modal_link_round_trips(self):
        link = CrossModalLink(
            link_id="link_1",
            video_id="clip_1",
            source_id="scene_1",
            target_id="sub_2",
            link_type=LinkType.CLAIM_TEXT,
            start=1.0,
            end=3.5,
            confidence=0.9,
            provenance={"rule": "shared_evidence"},
        )
        decoded = CrossModalLink.from_dict(json.loads(link.to_json()))
        self.assertEqual(decoded.link_type, LinkType.CLAIM_TEXT)
        self.assertEqual(decoded.source_id, "scene_1")
        self.assertEqual(decoded.end, 3.5)

    def test_evidence_packet_carries_cross_modal_links(self):
        packet = EvidencePacket(
            question_id="q1",
            video_id="clip_1",
            cross_modal_links=[
                CrossModalLink(
                    link_id="link_1",
                    video_id="clip_1",
                    source_id="triple_1",
                    target_id="sub_1",
                    link_type=LinkType.TRIPLE_EVIDENCE,
                )
            ],
        )
        decoded = EvidencePacket.from_dict(packet.to_dict())
        self.assertEqual(decoded.cross_modal_links[0].link_id, "link_1")
        self.assertEqual(decoded.cross_modal_links[0].link_type, LinkType.TRIPLE_EVIDENCE)

    def test_claim_trace_round_trips_with_tuples(self):
        trace = ClaimTrace(
            claim="Penny enters the room.",
            section_ids=["scene_1"],
            triple_ids=["triple_1"],
            subtitle_ids=["sub_1"],
            timestamps=[(1.0, 3.5)],
            link_ids=["link_1"],
            provenance=["sub_1"],
            label="sup",
        )
        decoded = ClaimTrace.from_dict(json.loads(trace.to_json()))
        self.assertEqual(decoded.timestamps, [(1.0, 3.5)])
        self.assertEqual(decoded.label, "sup")
        self.assertEqual(decoded.link_ids, ["link_1"])

    def test_wiki_patch_round_trips_with_nested_validation(self):
        patch = WikiPatch(
            patch_id="patch_1",
            video_id="clip_1",
            op="add",
            target_type="provenance",
            target_id="scene_1",
            content={"timestamp": [1.0, 3.5]},
            evidence_ids=["sub_1"],
            validation=ValidationResult("scene_1", "section", 0.9, 1.0, 1.0, 1.0, 1.0, "keep"),
            accepted=True,
        )
        decoded = WikiPatch.from_dict(json.loads(patch.to_json()))
        self.assertTrue(decoded.accepted)
        self.assertEqual(decoded.validation.decision, "keep")
        self.assertEqual(decoded.evidence_ids, ["sub_1"])


if __name__ == "__main__":
    unittest.main()
