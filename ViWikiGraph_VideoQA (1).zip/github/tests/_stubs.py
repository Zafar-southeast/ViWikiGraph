"""Offline test doubles. ``_stubs`` (leading underscore) is not collected as a test module."""

from __future__ import annotations

import json
from types import SimpleNamespace
from typing import Any


class StubLLM:
    """In-memory stand-in for :class:`viwikigraph.llm.client.LLMClient` (no network, no API key).

    ``json_response`` may be a dict (returned for every call) or a ``callable(prompt) -> dict`` to
    vary the canned response by prompt. ``logprob`` similarly may be a float or
    ``callable(prefix, continuation) -> float|None``.
    """

    def __init__(self, *, json_response: Any = None, logprob: Any = None, available: bool = True):
        self._json = json_response if json_response is not None else {}
        self._logprob = logprob
        self._available = available
        self.model = "stub-model"

    @property
    def available(self) -> bool:
        return self._available

    def _resolve_json(self, prompt: str) -> dict:
        return self._json(prompt) if callable(self._json) else dict(self._json)

    def chat(self, prompt: str, *, response_format: str = "text", cache_version: str = "v1", response_schema=None):
        return SimpleNamespace(text=json.dumps(self._resolve_json(prompt)), raw={}, cached=False)

    def strict_json(self, prompt: str, *, cache_version: str = "v1", tolerant: bool = False, response_schema=None) -> dict:
        return self._resolve_json(prompt)

    def chat_vision(self, prompt: str, image_paths, *, response_format: str = "text", cache_version: str = "v1", detail: str = "low", max_tokens=None):
        return SimpleNamespace(text=json.dumps(self._resolve_json(prompt)), raw={}, cached=False)

    def strict_json_vision(self, prompt: str, image_paths, *, cache_version: str = "v1", max_tokens=None) -> dict:
        return self._resolve_json(prompt)

    def normalized_logprob(self, prompt: str, continuation: str, *, cache_version: str = "v1"):
        return self._logprob(prompt, continuation) if callable(self._logprob) else self._logprob
