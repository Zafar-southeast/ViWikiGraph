import tempfile
import unittest
from pathlib import Path

from viwikigraph.config import load_config


class RAGOnlyTests(unittest.TestCase):
    def test_default_config_declares_rag_only_mode(self):
        config = load_config("configs/datasets.yaml")

        self.assertEqual(config.mode, "rag_only")
        self.assertFalse(config.training_enabled)

    def test_config_rejects_training_enabled(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "datasets.yaml"
            path.write_text(
                """
mode: rag_only
training:
  enabled: true
datasets: {}
""".strip(),
                encoding="utf-8",
            )

            with self.assertRaisesRegex(ValueError, "RAG-only"):
                load_config(path)

    def test_config_rejects_non_rag_mode(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "datasets.yaml"
            path.write_text(
                """
mode: trainable_heads
training:
  enabled: false
datasets: {}
""".strip(),
                encoding="utf-8",
            )

            with self.assertRaisesRegex(ValueError, "rag_only"):
                load_config(path)


if __name__ == "__main__":
    unittest.main()
