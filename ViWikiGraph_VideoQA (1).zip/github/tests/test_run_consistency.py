import argparse
import contextlib
import io
import json
import tempfile
import unittest
from types import SimpleNamespace
from pathlib import Path

import viwikigraph.cli as cli
from viwikigraph.cli import command_build, command_eval, command_qa, command_report
from viwikigraph.config import AppConfig, DatasetConfig
from viwikigraph.core.io import ensure_dir, write_json, write_jsonl
from viwikigraph.core.schemas import QAPrediction


def _write_nextqa_csv(path: Path) -> None:
    path.write_text(
        "video,frame_count,width,height,question,answer,qid,type,a0,a1,a2,a3,a4\n"
        "100,10,320,240,what color is it,0,1,DC,red,blue,green,yellow,white\n"
        "200,10,320,240,what happens next,1,2,TC,jump,run,sit,fall,stand\n",
        encoding="utf-8",
    )


def _config(tmp: Path) -> AppConfig:
    ann = tmp / "val.csv"
    _write_nextqa_csv(ann)
    dataset = DatasetConfig(
        name="nextqa",
        video_root=tmp / "videos",
        output_root=tmp / "outputs",
        annotations={"val": ann},
    )
    return AppConfig(
        raw={"datasets": {"nextqa": {"annotations": {"val": str(ann)}}}},
        datasets={"nextqa": dataset},
        budgets={"Bnar": 1, "Bkg": 1, "Bmedia": 1, "Bsub": 1, "Blink": 1},
        llm={},
    )


def _args(**overrides):
    values = {
        "dataset": "nextqa",
        "split": "val",
        "experiment_id": "exp",
        "limit": None,
        "sample_seed": 13,
        "stratify_by": None,
        "config": "test-config",
        "use_llm": False,
        "no_llm": True,
        "mode": "mcq",
        "scorer": "choice",
        "no_verify": True,
        "require_llm": False,
        "refine": False,
        "refine_dry_run": True,
        "no_link_validation": False,
        "dry_run": False,
        "resume": False,
        "use_vlm": False,
        "frame_budget": None,
        "retry_failed_vision": False,
    }
    values.update(overrides)
    return argparse.Namespace(**values)


class RunConsistencyTests(unittest.TestCase):
    def test_build_frame_budget_override_writes_vision_health(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _config(Path(tmpdir))
            built: list[tuple[str, int]] = []
            original = cli.build_video_package

            def fake_build_video_package(**kwargs):
                record = kwargs["record"]
                built.append((record.video_id, kwargs["budgets"]["Bframes"]))
                root = cli.package_root(
                    kwargs["output_root"],
                    kwargs["experiment_id"],
                    record.dataset,
                    record.split,
                    record.video_id,
                )
                ensure_dir(root)
                write_json(
                    root / "manifest.json",
                    {
                        "video_id": record.video_id,
                        "vision_status": "ok",
                        "frames_sampled": kwargs["budgets"]["Bframes"],
                        "frames_described": kwargs["budgets"]["Bframes"],
                    },
                )
                record.metadata["vision_status"] = "ok"
                return SimpleNamespace(root=root, evidence_units=[], media_items=[], validations=[])

            try:
                cli.build_video_package = fake_build_video_package
                command_build(config, _args(limit=2, frame_budget=8, use_vlm=True, no_llm=True))
            finally:
                cli.build_video_package = original

            self.assertEqual(built, [("100", 8), ("200", 8)])
            health = json.loads(
                (Path(tmpdir) / "outputs" / "exp" / "nextqa" / "val" / "vision_health.json").read_text(
                    encoding="utf-8"
                )
            )
            self.assertEqual(health["summary"]["total"], 2)
            self.assertEqual(health["summary"]["ok"], 2)
            self.assertEqual(health["summary"]["failed"], 0)
            self.assertEqual({row["video_id"] for row in health["records"]}, {"100", "200"})
            build_manifest = json.loads(
                (Path(tmpdir) / "outputs" / "exp" / "nextqa" / "val" / "build_manifest.json").read_text(
                    encoding="utf-8"
                )
            )
            self.assertEqual(build_manifest["budgets"]["Bframes"], 8)
            self.assertEqual(build_manifest["sampling"]["limit"], 2)

    def test_retry_failed_vision_builds_only_non_ok_packages(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _config(Path(tmpdir))
            split_dir = Path(tmpdir) / "outputs" / "exp" / "nextqa" / "val"
            ok_root = split_dir / "packages" / "100"
            failed_root = split_dir / "packages" / "200"
            write_json(ok_root / "manifest.json", {"video_id": "100", "vision_status": "ok"})
            write_json(
                failed_root / "manifest.json",
                {"video_id": "200", "vision_status": "error", "vision_detail": "RuntimeError: blocked"},
            )
            built: list[str] = []
            original = cli.build_video_package

            def fake_build_video_package(**kwargs):
                record = kwargs["record"]
                built.append(record.video_id)
                root = cli.package_root(
                    kwargs["output_root"],
                    kwargs["experiment_id"],
                    record.dataset,
                    record.split,
                    record.video_id,
                )
                write_json(
                    root / "manifest.json",
                    {
                        "video_id": record.video_id,
                        "vision_status": "ok",
                        "frames_sampled": kwargs["budgets"]["Bframes"],
                        "frames_described": kwargs["budgets"]["Bframes"],
                    },
                )
                record.metadata["vision_status"] = "ok"
                return SimpleNamespace(root=root, evidence_units=[], media_items=[], validations=[])

            try:
                cli.build_video_package = fake_build_video_package
                command_build(
                    config,
                    _args(limit=2, frame_budget=8, use_vlm=True, no_llm=True, retry_failed_vision=True),
                )
            finally:
                cli.build_video_package = original

            self.assertEqual(built, ["200"])
            health = json.loads((split_dir / "vision_health.json").read_text(encoding="utf-8"))
            self.assertEqual(health["summary"]["total"], 2)
            self.assertEqual(health["summary"]["ok"], 2)
            self.assertEqual(health["summary"]["failed"], 0)

    def test_qa_writes_selected_question_manifest(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _config(Path(tmpdir))

            command_qa(config, _args(limit=1))

            manifest = Path(tmpdir) / "outputs" / "exp" / "nextqa" / "val" / "qa" / "run_manifest.json"
            self.assertTrue(manifest.exists())
            data = json.loads(manifest.read_text(encoding="utf-8"))
            self.assertEqual(data["question_count"], 1)
            self.assertEqual(len(data["question_ids"]), 1)

    def test_qa_prints_per_question_progress_to_stderr(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _config(Path(tmpdir))
            stdout = io.StringIO()
            stderr = io.StringIO()

            with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
                command_qa(config, _args(limit=2))

            self.assertIn("qa_predictions=2 experiment=exp", stdout.getvalue())
            progress = stderr.getvalue()
            self.assertIn("[1/2] 100_1 video=100", progress)
            self.assertIn("[2/2] 200_2 video=200", progress)
            self.assertIn("retrieve=", progress)
            self.assertIn("answer=", progress)
            self.assertIn("done=", progress)
            self.assertIn("method=heuristic_overlap", progress)

    def test_eval_reuses_saved_qa_manifest_when_limit_is_omitted(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _config(Path(tmpdir))
            qa_dir = Path(tmpdir) / "outputs" / "exp" / "nextqa" / "val" / "qa"
            write_jsonl(
                qa_dir / "predictions.jsonl",
                [QAPrediction("100_1", "100", "red", 1.0, predicted_index=0)],
            )
            (qa_dir / "run_manifest.json").write_text(
                json.dumps(
                    {
                        "dataset": "nextqa",
                        "split": "val",
                        "experiment_id": "exp",
                        "question_count": 1,
                        "question_ids": ["100_1"],
                        "video_ids": ["100"],
                        "sampling": {"limit": 1, "sample_seed": 13, "stratify_by": None},
                    }
                ),
                encoding="utf-8",
            )

            command_eval(config, _args())

            metrics = json.loads(
                (Path(tmpdir) / "outputs" / "exp" / "nextqa" / "val" / "eval" / "metrics.json").read_text(
                    encoding="utf-8"
                )
            )
            self.assertEqual(metrics["count"], 1)
            self.assertEqual(metrics["answered"], 1)
            self.assertEqual(metrics["accuracy"], 1.0)

    def test_eval_without_manifest_infers_saved_prediction_ids(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _config(Path(tmpdir))
            qa_dir = Path(tmpdir) / "outputs" / "exp" / "nextqa" / "val" / "qa"
            write_jsonl(
                qa_dir / "predictions.jsonl",
                [QAPrediction("100_1", "100", "red", 1.0, predicted_index=0)],
            )

            command_eval(config, _args())

            metrics = json.loads(
                (Path(tmpdir) / "outputs" / "exp" / "nextqa" / "val" / "eval" / "metrics.json").read_text(
                    encoding="utf-8"
                )
            )
            self.assertEqual(metrics["count"], 1)
            self.assertEqual(metrics["accuracy"], 1.0)

    def test_report_reuses_saved_qa_manifest_when_limit_is_omitted(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _config(Path(tmpdir))
            qa_dir = Path(tmpdir) / "outputs" / "exp" / "nextqa" / "val" / "qa"
            write_jsonl(
                qa_dir / "predictions.jsonl",
                [QAPrediction("100_1", "100", "red", 1.0, predicted_index=0)],
            )
            (qa_dir / "run_manifest.json").write_text(
                json.dumps(
                    {
                        "dataset": "nextqa",
                        "split": "val",
                        "experiment_id": "exp",
                        "question_count": 1,
                        "question_ids": ["100_1"],
                        "video_ids": ["100"],
                        "sampling": {"limit": 1, "sample_seed": 13, "stratify_by": None},
                    }
                ),
                encoding="utf-8",
            )

            command_report(config, _args())

            run_config = json.loads(
                (Path(tmpdir) / "outputs" / "exp" / "nextqa" / "val" / "run_config.json").read_text(
                    encoding="utf-8"
                )
            )
            self.assertEqual(run_config["sampling"]["sample_size"], 1)
            self.assertEqual(run_config["sampling"]["limit"], 1)
            self.assertEqual(run_config["metrics"]["accuracy"], 1.0)

    def test_report_uses_build_manifest_effective_budgets(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _config(Path(tmpdir))
            split_dir = Path(tmpdir) / "outputs" / "exp" / "nextqa" / "val"
            qa_dir = split_dir / "qa"
            write_jsonl(
                qa_dir / "predictions.jsonl",
                [QAPrediction("100_1", "100", "red", 1.0, predicted_index=0)],
            )
            write_json(
                qa_dir / "run_manifest.json",
                {
                    "dataset": "nextqa",
                    "split": "val",
                    "experiment_id": "exp",
                    "question_count": 1,
                    "question_ids": ["100_1"],
                    "video_ids": ["100"],
                    "sampling": {"limit": 1, "sample_seed": 13, "stratify_by": None},
                },
            )
            write_json(
                split_dir / "build_manifest.json",
                {
                    "dataset": "nextqa",
                    "split": "val",
                    "experiment_id": "exp",
                    "budgets": {"Bnar": 1, "Bkg": 1, "Bmedia": 1, "Bsub": 1, "Blink": 1, "Bframes": 8},
                },
            )

            command_report(config, _args())

            run_config = json.loads((split_dir / "run_config.json").read_text(encoding="utf-8"))
            self.assertEqual(run_config["budgets"]["Bframes"], 8)

    def test_report_infers_llm_model_from_saved_llm_predictions(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _config(Path(tmpdir))
            split_dir = Path(tmpdir) / "outputs" / "exp" / "nextqa" / "val"
            qa_dir = split_dir / "qa"
            write_jsonl(
                qa_dir / "predictions.jsonl",
                [QAPrediction("100_1", "100", "red", 1.0, scoring_method="llm_choice", predicted_index=0)],
            )
            write_json(
                qa_dir / "run_manifest.json",
                {
                    "dataset": "nextqa",
                    "split": "val",
                    "experiment_id": "exp",
                    "question_count": 1,
                    "question_ids": ["100_1"],
                    "video_ids": ["100"],
                    "sampling": {"limit": 1, "sample_seed": 13, "stratify_by": None},
                },
            )
            write_json(
                split_dir / "packages" / "100" / "manifest.json",
                {"models": {"llm": "gemini-test"}},
            )

            command_report(config, _args())

            run_config = json.loads((split_dir / "run_config.json").read_text(encoding="utf-8"))
            report = (split_dir / "report.md").read_text(encoding="utf-8")
            self.assertEqual(run_config["model"], "gemini-test")
            self.assertIn("- Model: `gemini-test`", report)

    def test_report_resolves_relocated_package_media_paths(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config = _config(Path(tmpdir))
            split_dir = Path(tmpdir) / "outputs" / "exp" / "nextqa" / "val"
            qa_dir = split_dir / "qa"
            write_jsonl(
                qa_dir / "predictions.jsonl",
                [QAPrediction("100_1", "100", "red", 1.0, predicted_index=0)],
            )
            (qa_dir / "run_manifest.json").write_text(
                json.dumps(
                    {
                        "dataset": "nextqa",
                        "split": "val",
                        "experiment_id": "exp",
                        "question_count": 1,
                        "question_ids": ["100_1"],
                        "video_ids": ["100"],
                        "sampling": {"limit": 1, "sample_seed": 13, "stratify_by": None},
                    }
                ),
                encoding="utf-8",
            )
            package = split_dir / "packages" / "100"
            (package / "media" / "frames").mkdir(parents=True)
            (package / "media" / "frames" / "frame_0001.jpg").write_bytes(b"jpg")
            (package / "manifest.json").write_text("{}", encoding="utf-8")
            write_jsonl(
                package / "validation" / "media_links.jsonl",
                [
                    {
                        "path": "/old/machine/project/outputs/exp/nextqa/val/packages/100/media/frames/frame_0001.jpg"
                    }
                ],
            )

            command_report(config, _args())

            run_config = json.loads((split_dir / "run_config.json").read_text(encoding="utf-8"))
            self.assertEqual(run_config["package_stats"]["media_total"], 1)
            self.assertEqual(run_config["package_stats"]["media_present"], 1)
            self.assertEqual(run_config["package_stats"]["media_correctness"], 1.0)


if __name__ == "__main__":
    unittest.main()
