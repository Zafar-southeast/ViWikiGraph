import json
import tempfile
import unittest
from pathlib import Path

from viwikigraph.qa.reporting import collect_package_stats, write_report
from viwikigraph.core.schemas import KGItem, QAInstance, QAPrediction, ValidationResult, WikiSection


class ReportingTests(unittest.TestCase):
    def test_report_and_run_config_written(self):
        with tempfile.TemporaryDirectory() as tmp:
            split_dir = Path(tmp) / "exp1" / "knowit" / "val"
            qas = [
                QAInstance(
                    question_id="val_0",
                    video_id="s01",
                    question="Why did he leave?",
                    options=["a", "b", "c", "d"],
                    answer_index=1,
                    metadata={"question_type": "knowledge"},
                )
            ]
            predictions = [
                QAPrediction(
                    question_id="val_0",
                    video_id="s01",
                    answer="b",
                    confidence=0.8,
                    predicted_index=1,
                    scoring_method="llm_choice",
                    evidence_trace=[{"claim": "b", "section_ids": ["summary"]}],
                )
            ]
            report_path = write_report(
                split_dir,
                experiment_id="exp1",
                dataset="knowit",
                split="val",
                model="claude-test",
                sample_info={"limit": 1, "sample_seed": 13, "stratify_by": "question_type"},
                qas=qas,
                predictions=predictions,
            )

            self.assertTrue(report_path.exists())
            self.assertEqual(report_path.name, "report.md")
            self.assertTrue((split_dir / "run_config.json").exists())

            text = report_path.read_text(encoding="utf-8")
            self.assertIn("QA Accuracy", text)
            self.assertIn("knowledge", text)  # per-question-type row

            config = json.loads((split_dir / "run_config.json").read_text(encoding="utf-8"))
            self.assertEqual(config["experiment_id"], "exp1")
            self.assertEqual(config["mode"], "rag_only")
            self.assertEqual(config["metrics"]["accuracy"], 1.0)

    def test_collect_package_stats_narrative_support_rate(self):
        sections = [
            WikiSection(
                section_id="summary",
                video_id="v",
                section_type="summary",
                heading="S",
                content="c",
                claims=["a", "b"],
                provenance={"source": "llm"},
            )
        ]
        kg_items = [
            KGItem(item_id="e1", video_id="v", item_type="entity", label="Penny", provenance={"x": 1}),
            KGItem(item_id="t1", video_id="v", item_type="temporal_link", label="a BEFORE b"),
        ]
        validations = [
            ValidationResult("summary", "summary", 0.9, 1.0, 1.0, 1.0, 1.0, "keep"),
        ]
        stats = collect_package_stats(sections, kg_items, validations, video_count=1)

        self.assertEqual(stats.total_claims, 2)
        self.assertEqual(stats.kept_claims, 2)  # summary section kept → its 2 claims count
        self.assertEqual(stats.narrative_support_rate, 1.0)
        self.assertEqual(stats.num_entities, 1)
        self.assertEqual(stats.num_temporal, 1)


if __name__ == "__main__":
    unittest.main()
