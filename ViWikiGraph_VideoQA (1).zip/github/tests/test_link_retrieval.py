import unittest

from viwikigraph.core.schemas import (
    CrossModalLink,
    EvidenceUnit,
    KGItem,
    LinkType,
    Modality,
    QAInstance,
    WikiSection,
)
from viwikigraph.retrieval.index import EvidenceNeed, build_retrieval_index, retrieve_evidence


def _index_with_link():
    section = WikiSection(
        section_id="scene_1", video_id="v1", section_type="scene", heading="Scene 1",
        content="Penny enters the apartment and greets Leonard.", evidence_ids=["sub_1"],
        start=1.0, end=3.0,
    )
    kg = KGItem(item_id="triple_1", video_id="v1", item_type="triple", label="Penny enters apartment",
                evidence_ids=["sub_1"], start=1.0, end=3.0)
    units = [
        EvidenceUnit(evidence_id="sub_1", video_id="v1", modality=Modality.SUBTITLE,
                     text="Penny enters the apartment.", start=1.0, end=3.0),
        EvidenceUnit(evidence_id="sub_2", video_id="v1", modality=Modality.SUBTITLE,
                     text="Leonard waves back at her.", start=3.0, end=5.0),
    ]
    link = CrossModalLink(
        link_id="link_1", video_id="v1", source_id="scene_1", target_id="sub_2",
        link_type=LinkType.CLAIM_TEXT, start=3.0, end=5.0, confidence=0.9,
        provenance={"rule": "section_evidence"},
    )
    return build_retrieval_index([section], [kg], [], units, [link])


class LinkExpansionTests(unittest.TestCase):
    def test_retrieval_surfaces_links_incident_on_retrieved_items(self):
        index = _index_with_link()
        qa = QAInstance(question_id="q1", video_id="v1", question="What does Penny do?", options=[])
        packet = retrieve_evidence(qa, index, {"Bnar": 4, "Bkg": 4, "Bsub": 1, "Blink": 4},
                                   need=EvidenceNeed())
        self.assertTrue(any(l.link_id == "link_1" for l in packet.cross_modal_links))

    def test_link_expansion_augments_linked_subtitle_within_budget(self):
        index = _index_with_link()
        qa = QAInstance(question_id="q1", video_id="v1", question="What does Penny do?", options=[])
        # Bsub=2 leaves room for the link-referenced sub_2 to be pulled in.
        packet = retrieve_evidence(qa, index, {"Bnar": 4, "Bkg": 4, "Bsub": 2, "Blink": 4},
                                   need=EvidenceNeed())
        self.assertIn("sub_2", {u.evidence_id for u in packet.subtitle_spans})

    def test_visual_only_link_dropped_when_need_not_visual(self):
        section = WikiSection(section_id="scene_1", video_id="v1", section_type="scene",
                              heading="S1", content="x", evidence_ids=[], start=1.0, end=3.0)
        link = CrossModalLink(link_id="link_v", video_id="v1", source_id="scene_1", target_id="media_1",
                              link_type=LinkType.ENTITY_IMAGE, confidence=0.9, provenance={"rule": "x"})
        index = build_retrieval_index([section], [], [], [], [link])
        qa = QAInstance(question_id="q1", video_id="v1", question="Summarize the scene", options=[])
        need = EvidenceNeed(needs_visual=False, needs_temporal=False)
        packet = retrieve_evidence(qa, index, {"Blink": 4}, need=need)
        self.assertEqual(packet.cross_modal_links, [])


if __name__ == "__main__":
    unittest.main()
