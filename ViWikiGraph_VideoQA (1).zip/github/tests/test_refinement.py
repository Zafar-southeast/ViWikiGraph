import json
import tempfile
import unittest
from pathlib import Path

from viwikigraph.core.io import ensure_dir, write_json, write_jsonl
from viwikigraph.core.schemas import (
    EvidencePacket,
    EvidenceUnit,
    Modality,
    QAInstance,
    QAPrediction,
    WikiSection,
)
from viwikigraph.knowledge.refinement import detect_evidence_gaps, refine_after_qa


def _write_package(root: Path):
    ensure_dir(root / "wiki")
    ensure_dir(root / "evidence")
    ensure_dir(root / "validation")
    ensure_dir(root / "index")
    section = WikiSection(
        section_id="scene_1", video_id="v", section_type="scene", heading="Scene 1",
        content="Penny enters the apartment", evidence_ids=["sub_1"], confidence=0.9,
    )  # no start/end -> a verified-timestamp patch can strengthen it
    unit = EvidenceUnit(
        evidence_id="sub_1", video_id="v", modality=Modality.SUBTITLE,
        text="Penny enters the apartment", start=1.0, end=3.0, provenance={"source": "subtitle"},
    )
    write_jsonl(root / "wiki" / "narrative_sections.jsonl", [section])
    write_jsonl(root / "wiki" / "kg_items.jsonl", [])
    write_jsonl(root / "evidence" / "evidence_units.jsonl", [unit])
    write_json(root / "manifest.json", {"video_id": "v", "dataset": "test", "split": "val"})
    return section, unit


def _packet():
    return EvidencePacket(
        question_id="q", video_id="v",
        narrative_sections=[WikiSection(section_id="scene_1", video_id="v", section_type="scene",
                                        heading="Scene 1", content="Penny enters the apartment",
                                        evidence_ids=["sub_1"], confidence=0.9)],
        subtitle_spans=[EvidenceUnit(evidence_id="sub_1", video_id="v", modality=Modality.SUBTITLE,
                                     text="Penny enters the apartment", start=1.0, end=3.0)],
    )


def _prediction(label: str):
    return QAPrediction(
        question_id="q", video_id="v", answer="Penny enters the apartment", confidence=0.4,
        evidence_trace=[
            {"claim": "Penny enters the apartment", "section_ids": ["scene_1"],
             "subtitle_ids": ["sub_1"], "provenance": ["sub_1"], "label": label},
            {"verification": {"triggered": True, "applied": True, "risk": 0.7}},
        ],
        scoring_method="llm_choice+verified",
    )


class RefinementTests(unittest.TestCase):
    def test_no_gap_yields_no_patches(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            _write_package(root)
            qa = QAInstance(question_id="q", video_id="v", question="What does Penny do?")
            result = refine_after_qa(qa, _packet(), _prediction(label="sup"), root)
            self.assertEqual(result.applied, 0)
            self.assertEqual(result.patches, [])

    def test_weak_gap_proposes_validates_and_applies_patch(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            _write_package(root)
            qa = QAInstance(question_id="q", video_id="v", question="What does Penny do?")
            result = refine_after_qa(qa, _packet(), _prediction(label="unsup"), root)

            self.assertEqual(len(result.patches), 1)
            patch = result.patches[0]
            self.assertTrue(patch.accepted)
            self.assertEqual(result.applied, 1)
            # Write-back attached the verified timestamp to the section.
            sections = [json.loads(line) for line in
                        (root / "wiki" / "narrative_sections.jsonl").read_text().splitlines()]
            self.assertEqual(sections[0]["start"], 1.0)
            self.assertEqual(sections[0]["end"], 3.0)

    def test_idempotent_second_run_applies_nothing(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            _write_package(root)
            qa = QAInstance(question_id="q", video_id="v", question="What does Penny do?")
            refine_after_qa(qa, _packet(), _prediction(label="unsup"), root)
            second = refine_after_qa(qa, _packet(), _prediction(label="unsup"), root)
            self.assertEqual(second.applied, 0)

    def test_dry_run_writes_nothing(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            _write_package(root)
            qa = QAInstance(question_id="q", video_id="v", question="What does Penny do?")
            result = refine_after_qa(qa, _packet(), _prediction(label="unsup"), root, dry_run=True)
            self.assertEqual(result.applied, 0)
            sections = [json.loads(line) for line in
                        (root / "wiki" / "narrative_sections.jsonl").read_text().splitlines()]
            self.assertIsNone(sections[0]["start"])  # unchanged

    def test_patch_evidence_ids_are_subset_of_verified_pool(self):
        # Leakage guard: a gap that cites an unknown id must not survive into a proposed patch.
        packet = _packet()
        prediction = _prediction(label="unsup")
        # Inject an unverified id into the trace; detection filters to the verified pool.
        prediction.evidence_trace[0]["subtitle_ids"].append("gold_leak_id")
        gaps = detect_evidence_gaps(QAInstance(question_id="q", video_id="v", question="?"),
                                    packet, prediction)
        for gap in gaps:
            self.assertNotIn("gold_leak_id", gap["evidence_ids"])


if __name__ == "__main__":
    unittest.main()
