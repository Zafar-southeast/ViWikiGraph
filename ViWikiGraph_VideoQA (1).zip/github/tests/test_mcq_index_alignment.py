import tempfile
import unittest
from pathlib import Path

from viwikigraph.datasets.adapters import KnowITAdapter
from viwikigraph.qa.evaluation import evaluate_predictions
from viwikigraph.core.schemas import QAPrediction

# idxCorrect=2 is 1-based in the TSV → the adapter must expose answer_index=1 (0-based) so a
# 0-based predicted_index aligns with evaluation.
_TSV = (
    "answer1\tanswer2\tanswer3\tanswer4\tidxCorrect\tkg_type\tquestion\treason\tscene\tsubtitle\n"
    "Apple\tBanana\tCherry\tDate\t2\tsame\tWhich fruit?\tgold reason\t"
    "s01e01_scene001_0001_0005\t<b>X</b>: hi\n"
)


class MCQIndexAlignmentTests(unittest.TestCase):
    def _qa(self, tmp: str):
        ann = Path(tmp) / "knowit_val.csv"
        ann.write_text(_TSV, encoding="utf-8")
        adapter = KnowITAdapter({"val": ann}, video_root=Path(tmp) / "videos")
        return list(adapter.iter_qa_instances("val"))[0]

    def test_knowit_answer_index_is_zero_based(self):
        with tempfile.TemporaryDirectory() as tmp:
            qa = self._qa(tmp)
            self.assertEqual(qa.answer_index, 1)  # idxCorrect=2 → 0-based 1 → "Banana"
            self.assertEqual(qa.options[qa.answer_index], "Banana")

    def test_correct_prediction_scores_one(self):
        with tempfile.TemporaryDirectory() as tmp:
            qa = self._qa(tmp)
            correct = QAPrediction(question_id=qa.question_id, video_id=qa.video_id, answer="Banana", predicted_index=1)
            wrong = QAPrediction(question_id=qa.question_id, video_id=qa.video_id, answer="Apple", predicted_index=0)

            metrics_ok, _ = evaluate_predictions([qa], [correct])
            metrics_bad, _ = evaluate_predictions([qa], [wrong])

            self.assertEqual(metrics_ok["accuracy"], 1.0)
            self.assertEqual(metrics_bad["accuracy"], 0.0)


if __name__ == "__main__":
    unittest.main()
