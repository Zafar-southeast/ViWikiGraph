import unittest

from tests._stubs import StubLLM
from viwikigraph.core.schemas import (
    CrossModalLink,
    EvidencePacket,
    EvidenceUnit,
    KGItem,
    LinkType,
    Modality,
    QAInstance,
    RelationTriple,
    WikiSection,
)
from viwikigraph.qa.answering import answer_question


def _packet() -> EvidencePacket:
    return EvidencePacket(
        question_id="q",
        video_id="v",
        narrative_sections=[
            WikiSection(section_id="scene_1", video_id="v", section_type="scene", heading="S",
                        content="the door is red", evidence_ids=["sub_1"], start=1.0, end=3.0,
                        confidence=0.9)
        ],
        kg_items=[
            KGItem(item_id="triple_1", video_id="v", item_type="triple", label="door has_color red",
                   triples=[RelationTriple(subject="door", relation="has_color", object="red",
                                           evidence_ids=["sub_1"])], evidence_ids=["sub_1"])
        ],
        subtitle_spans=[
            EvidenceUnit(evidence_id="sub_1", video_id="v", modality=Modality.SUBTITLE,
                         text="the door is red", start=1.0, end=3.0)
        ],
        cross_modal_links=[
            CrossModalLink(link_id="link_1", video_id="v", source_id="scene_1", target_id="sub_1",
                           link_type=LinkType.CLAIM_TEXT, start=1.0, end=3.0, confidence=0.9,
                           provenance={"rule": "section_evidence"})
        ],
    )


class ClaimTraceTests(unittest.TestCase):
    def test_trace_is_claim_level_and_links_all_evidence_kinds(self):
        qa = QAInstance(question_id="q", video_id="v", question="What color is the door?",
                        options=["blue", "red"], answer_index=1)
        llm = StubLLM(json_response={"answer_index": 1, "answer": "red", "confidence": 0.9,
                                     "evidence_ids": ["scene_1", "sub_1", "triple_1"],
                                     "rationale": "the door is red"})
        pred = answer_question(qa, _packet(), llm=llm, verify=False)

        traces = pred.claim_traces()
        self.assertTrue(traces)
        first = traces[0]
        self.assertIn("scene_1", first.section_ids)
        self.assertIn("triple_1", first.kg_item_ids)
        self.assertIn("triple_1", first.triple_ids)
        self.assertIn("sub_1", first.subtitle_ids)
        self.assertIn("link_1", first.link_ids)
        self.assertIn((1.0, 3.0), first.timestamps)

    def test_deterministic_trace_without_llm(self):
        qa = QAInstance(question_id="q", video_id="v", question="What color is the door?",
                        options=["blue door", "red door"], answer_index=1)
        pred = answer_question(qa, _packet(), llm=None)
        # No citations -> support sets fall back to token-overlap with the claim.
        traces = pred.claim_traces()
        self.assertTrue(traces)
        self.assertIn("scene_1", traces[0].section_ids)


if __name__ == "__main__":
    unittest.main()
