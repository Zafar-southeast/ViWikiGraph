import unittest

from viwikigraph.core.schemas import (
    CrossModalLink,
    EvidenceUnit,
    KGItem,
    LinkType,
    MediaItem,
    Modality,
    RelationTriple,
    WikiSection,
)
from viwikigraph.knowledge.linking import build_cross_modal_links, render_links_section


def _evidence():
    return [
        EvidenceUnit(
            evidence_id="sub_1",
            video_id="v1",
            modality=Modality.SUBTITLE,
            text="Penny enters the apartment.",
            start=1.0,
            end=3.0,
            entities=["Penny"],
        ),
        EvidenceUnit(
            evidence_id="vc_1",
            video_id="v1",
            modality=Modality.VISUAL_CONCEPT,
            text="couch , lamp",
            objects=["couch", "lamp"],
        ),
    ]


def _sections():
    return [
        WikiSection(
            section_id="scene_1",
            video_id="v1",
            section_type="scene",
            heading="Scene 1",
            content="Penny enters the apartment.",
            claims=["Penny enters the apartment."],
            evidence_ids=["sub_1", "vc_1"],
            start=1.0,
            end=3.0,
            provenance={"media_paths": ["media/snapshots/0001.jpg"]},
        )
    ]


def _kg_items():
    triple = RelationTriple(subject="Penny", relation="enters", object="apartment", evidence_ids=["sub_1"])
    return [
        KGItem(
            item_id="entity_1",
            video_id="v1",
            item_type="entity",
            label="Penny",
            evidence_ids=["sub_1"],
            start=1.0,
            end=3.0,
        ),
        KGItem(
            item_id="triple_1",
            video_id="v1",
            item_type="triple",
            label="Penny enters apartment",
            triples=[triple],
            evidence_ids=["sub_1"],
            start=1.0,
            end=3.0,
        ),
    ]


def _media():
    return [
        MediaItem(
            media_id="media_1",
            video_id="v1",
            media_type="snapshot",
            path="media/snapshots/0001.jpg",
            start=1.0,
            end=3.0,
            linked_item_id="scene_1",
            provenance={"evidence_ids": ["sub_1"]},
        )
    ]


class CrossModalLinkingTests(unittest.TestCase):
    def setUp(self):
        self.links = build_cross_modal_links("v1", _sections(), _kg_items(), _media(), _evidence())

    def _types(self):
        return {link.link_type for link in self.links}

    def test_claim_text_link_connects_section_to_subtitle(self):
        match = [l for l in self.links if l.link_type == LinkType.CLAIM_TEXT]
        self.assertTrue(any(l.source_id == "scene_1" and l.target_id == "sub_1" for l in match))

    def test_triple_evidence_link_present(self):
        match = [l for l in self.links if l.link_type == LinkType.TRIPLE_EVIDENCE]
        self.assertTrue(any(l.source_id == "triple_1" and l.target_id == "sub_1" for l in match))

    def test_section_triple_and_claim_media_links_present(self):
        self.assertIn(LinkType.SECTION_TRIPLE, self._types())
        self.assertIn(LinkType.CLAIM_MEDIA, self._types())

    def test_entity_image_link_via_shared_evidence(self):
        match = [l for l in self.links if l.link_type == LinkType.ENTITY_IMAGE]
        self.assertTrue(any(l.source_id == "entity_1" and l.target_id == "media_1" for l in match))

    def test_links_have_unique_ids_and_shared_span(self):
        ids = [l.link_id for l in self.links]
        self.assertEqual(len(ids), len(set(ids)))
        claim_text = next(l for l in self.links if l.link_type == LinkType.CLAIM_TEXT)
        self.assertEqual((claim_text.start, claim_text.end), (1.0, 3.0))

    def test_no_duplicate_typed_pairs(self):
        keys = [(l.source_id, l.target_id, l.link_type.value) for l in self.links]
        self.assertEqual(len(keys), len(set(keys)))

    def test_render_links_section_is_markdown_table(self):
        md = "\n".join(render_links_section(self.links))
        self.assertIn("## Cross-Modal Evidence Links", md)
        self.assertIn("claim_text", md)

    def test_empty_inputs_yield_no_links(self):
        self.assertEqual(build_cross_modal_links("v1", [], [], [], []), [])


if __name__ == "__main__":
    unittest.main()
