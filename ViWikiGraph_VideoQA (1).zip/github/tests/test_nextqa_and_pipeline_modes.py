import json
import tempfile
import unittest
from pathlib import Path

from viwikigraph.datasets.adapters import NextQAAdapter
from viwikigraph.pipeline import build_video_package
from viwikigraph.core.schemas import QAInstance, VideoRecord

_CSV = (
    "video,frame_count,width,height,question,answer,qid,type,a0,a1,a2,a3,a4\n"
    # a1 is empty — options must stay 5-wide so answer=2 still points at 'Y'.
    "123,10,1,1,what fruit,2,6,DC,X,,Y,Z,W\n"
)


class NextQACaptionTests(unittest.TestCase):
    def _adapter(self, tmp: str, captions_path=None) -> NextQAAdapter:
        ann = Path(tmp) / "train.csv"
        ann.write_text(_CSV, encoding="utf-8")
        return NextQAAdapter({"train": ann}, None, Path(tmp) / "videos", captions_path=captions_path)

    def test_option_filtering_does_not_shift_answer_index(self):
        with tempfile.TemporaryDirectory() as tmp:
            qa = next(self._adapter(tmp).iter_qa_instances("train"))
            self.assertEqual(len(qa.options), 5)
            self.assertEqual(qa.answer_index, 2)
            self.assertEqual(qa.options[qa.answer_index], "Y")

    def test_question_id_is_namespaced_by_video(self):
        # NExT-QA ``qid`` is per-video, so two videos can share qid '6'. The adapter must namespace it
        # by ``video_id`` to stay split-unique (else predictions collide and corrupt evaluation).
        csv = (
            "video,frame_count,width,height,question,answer,qid,type,a0,a1,a2,a3,a4\n"
            "100,10,1,1,q one,0,6,DC,a,b,c,d,e\n"
            "200,10,1,1,q two,1,6,DC,a,b,c,d,e\n"
        )
        with tempfile.TemporaryDirectory() as tmp:
            ann = Path(tmp) / "train.csv"
            ann.write_text(csv, encoding="utf-8")
            qas = list(NextQAAdapter({"train": ann}, None, Path(tmp) / "videos").iter_qa_instances("train"))
            ids = [qa.question_id for qa in qas]
            self.assertEqual(ids, ["100_6", "200_6"])
            self.assertEqual(len(set(ids)), len(ids))

    def test_caption_sidecar_record_form(self):
        with tempfile.TemporaryDirectory() as tmp:
            sidecar = Path(tmp) / "caps.jsonl"
            sidecar.write_text(
                json.dumps({"video_id": "123", "captions": [{"text": "a man runs", "start": 0.0, "end": 2.0}]}),
                encoding="utf-8",
            )
            record = next(self._adapter(tmp, captions_path=sidecar).iter_video_records("train"))
            self.assertEqual(len(record.subtitles), 1)
            self.assertEqual(record.subtitles[0]["text"], "a man runs")
            self.assertEqual(record.subtitles[0]["source"], "nextqa_caption")

    def test_caption_sidecar_mapping_form(self):
        with tempfile.TemporaryDirectory() as tmp:
            sidecar = Path(tmp) / "caps.json"
            sidecar.write_text(json.dumps({"123": [{"text": "a dog barks"}]}), encoding="utf-8")
            record = next(self._adapter(tmp, captions_path=sidecar).iter_video_records("train"))
            self.assertEqual(record.subtitles[0]["text"], "a dog barks")

    def test_no_sidecar_means_no_subtitles(self):
        with tempfile.TemporaryDirectory() as tmp:
            record = next(self._adapter(tmp).iter_video_records("train"))
            self.assertEqual(record.subtitles, [])


class _BoomLLM:
    """LLM stub that fails loudly if any generation method is called (used to prove dry_run is offline)."""

    available = True

    def chat(self, *args, **kwargs):  # noqa: D401 - test stub
        raise AssertionError("LLM.chat called during dry_run")

    def strict_json(self, *args, **kwargs):
        raise AssertionError("LLM.strict_json called during dry_run")


class PipelineModeTests(unittest.TestCase):
    def _record(self) -> VideoRecord:
        return VideoRecord(
            dataset="tvqa", split="val", video_id="clip_1", video_path="/missing.mp4",
            subtitles=[{"text": "Penny opens the door.", "start": 0.0, "end": 2.0, "source": "subtitle"}],
        )

    def test_dry_run_disables_llm(self):
        with tempfile.TemporaryDirectory() as tmp:
            # dry_run must force the deterministic path even when an LLM is supplied.
            package = build_video_package(
                self._record(), [], Path(tmp) / "outputs", {"Bimg": 1},
                experiment_id="e", llm=_BoomLLM(), dry_run=True,
            )
            self.assertTrue((package.root / "manifest.json").exists())
            self.assertTrue(package.evidence_units)  # built via regex fallback, no exception

    def test_resume_short_circuits_existing_package(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp) / "outputs"
            qa = QAInstance(question_id="q", video_id="clip_1", question="?", options=["a", "b"], answer_index=0)
            build_video_package(self._record(), [qa], out, {"Bimg": 1}, experiment_id="e", dry_run=True)
            again = build_video_package(self._record(), [qa], out, {"Bimg": 1}, experiment_id="e", resume=True)
            self.assertEqual(again.evidence_units, [])  # early return, nothing rebuilt


if __name__ == "__main__":
    unittest.main()
